"""Endpoints for ai-cloud.html: the agent list, chat (streamed), small tasks, services, web search and fetch, and Boss AIs.

/chat answers in the same line-by-line format the page already reads ({"message": {...}, "done": ...}), whatever service
sits behind the agent. API keys never leave the server.
"""
from __future__ import annotations

import html
import json
import logging
import re
import time
import uuid
from types import MappingProxyType
from typing import Any
from urllib.parse import parse_qs, quote, urlparse

import aiohttp
from aiohttp import web

from homeassistant.config_entries import ConfigSubentry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .authz import AuthedView
from .const import (
    API, BUILTIN_HA_AGENT, CONF_BRAVE_KEY, CONF_DESCRIPTION, CONF_ENTRY_TYPE, CONF_HA_AGENT, CONF_MAX_HOPS, CONF_MAX_TOKENS, CONF_PRESET,
    CONF_PRIMARY, CONF_PRIMARY_PROMPT, CONF_PROMPT, CONF_REASONING, CONF_SEARCH, CONF_SEARXNG_URL, CONF_SECONDARY, CONF_SECONDARY_PROMPT,
    CONF_SHOW_STEPS, CONF_TALK_BACK, CONF_TEMPERATURE, CONF_TOOL_GROUPS, CONF_TOOLS, CONF_TOP_P, CONF_VISION, DOMAIN, ENTRY_SERVICE, PRESETS,
    SUB_AI_TASK, SUB_BOSS, SUB_CONVERSATION,
)
from .llm_bridge import agent_params, boss_delegate
from .providers import ProviderError, base_url_for, image_part
from .runtime import AgentRef, Runtime

_LOGGER = logging.getLogger(__name__)
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


# ---------------------------------------------------------------------- shapes for the page
def agent_view(hass: HomeAssistant, rt: Runtime, a: AgentRef) -> dict:
    d = a.data
    if a.kind == SUB_BOSS:
        names = {k: (rt.resolve_agent(d.get(k)).name if rt.resolve_agent(d.get(k)) else d.get(k)) for k in (CONF_PRIMARY, CONF_SECONDARY)}
        ha = hass.states.get(d.get(CONF_HA_AGENT) or BUILTIN_HA_AGENT)
        chain = {"primary": names[CONF_PRIMARY], "secondary": names[CONF_SECONDARY], "ha": ha.name if ha else d.get(CONF_HA_AGENT)}
        return {"kind": "boss", "boss": True, "entity_id": a.entity_id, "name": a.name, "service": "Boss AI", "model": f"{chain['primary']} to {chain['secondary']}",
                "caps": ["tools"], "description": f"{chain['primary']} → {chain['secondary']} → {chain['ha']}", "chain": chain}
    thinking = (d.get(CONF_REASONING) or "none") != "none"
    caps = [c for c, on in (("vision", d.get(CONF_VISION)), ("tools", a.kind == SUB_CONVERSATION and d.get(CONF_TOOLS, True)), ("thinking", thinking)) if on]
    return {"kind": "conversation" if a.kind == SUB_CONVERSATION else "task", "entity_id": a.entity_id, "name": a.name, "service": a.service,
            "model": d.get("model"), "caps": caps, "think": ["low", "medium", "high"] if thinking else None, "description": d.get(CONF_DESCRIPTION) or "",
            "system": d.get(CONF_PROMPT) or "", "params": {k: v for k, v in (("temperature", d.get(CONF_TEMPERATURE)), ("top_p", d.get(CONF_TOP_P)), ("num_predict", d.get(CONF_MAX_TOKENS))) if v not in (None, "")},
            "tools": list(d.get(CONF_TOOL_GROUPS) or [])}


def page_messages(messages: list[dict], vision: bool) -> list[dict]:
    """The page's messages (Ollama style) -> OpenAI style, pairing tool results with their calls."""
    out: list[dict] = []
    pending: list[tuple[str, str]] = []
    for m in messages:
        role = m.get("role")
        if role == "system":
            out.append({"role": "system", "content": str(m.get("content") or "")})
        elif role == "user":
            imgs = m.get("images") or []
            text = str(m.get("content") or "")
            if imgs and vision:
                out.append({"role": "user", "content": [{"type": "text", "text": text}] + [image_part(str(i)) for i in imgs]})
            else:
                out.append({"role": "user", "content": text + (f"\n\n[{len(imgs)} image(s) attached, but this model cannot see images.]" if imgs else "")})
        elif role == "assistant":
            msg: dict[str, Any] = {"role": "assistant", "content": str(m.get("content") or "")}
            calls = []
            for tc in m.get("tool_calls") or []:
                fn = tc.get("function") or {}
                cid = tc.get("id") or "call_" + uuid.uuid4().hex[:12]
                args = fn.get("arguments")
                calls.append({"id": cid, "type": "function", "function": {"name": fn.get("name") or "", "arguments": args if isinstance(args, str) else json.dumps(args or {})}})
                pending.append((cid, fn.get("name") or ""))
            if calls:
                msg["tool_calls"] = calls
            out.append(msg)
        elif role == "tool":
            name = m.get("tool_name") or m.get("name") or ""
            idx = next((i for i, (_c, n) in enumerate(pending) if n == name), 0 if pending else None)
            cid = pending.pop(idx)[0] if idx is not None else "call_" + uuid.uuid4().hex[:12]
            out.append({"role": "tool", "tool_call_id": cid, "content": str(m.get("content") or "")})
    # merge several system messages into one at the top (some services accept only one)
    sys = [m["content"] for m in out if m["role"] == "system"]
    rest = [m for m in out if m["role"] != "system"]
    return ([{"role": "system", "content": "\n\n".join(sys)}] if sys else []) + rest


def _think(value: Any) -> Any:
    if value in (None, "", "auto"):
        return None
    if value in (False, "off", "none"):
        return "none"
    if value is True or value == "on":
        return "medium"
    return str(value)


class _V(AuthedView):
    def admin_only(self, request):
        if not self.who(request).is_admin:
            return self.json({"error": "Only an administrator can do that."}, status_code=403)
        return None


# ---------------------------------------------------------------------- agents and services
class AgentsListView(_V):
    url = API + "/ai_agents"
    name = "api:artificial_intelligence:ai_agents"

    async def get(self, request):
        return self.json({"agents": [agent_view(self.hass, self.rt, a) for a in self.rt.list_agents()]})


class AgentEditView(_V):
    url = API + "/ai_agents/{entity_id}"
    name = "api:artificial_intelligence:ai_agent"

    async def put(self, request, entity_id):
        if (r := self.admin_only(request)) is not None:
            return r
        a = self.rt.resolve_agent(entity_id)
        if not a or a.kind == SUB_BOSS:
            return self.json({"error": "No such agent."}, status_code=404)
        b = await request.json()
        data = dict(a.subentry.data)
        if "description" in b:
            data[CONF_DESCRIPTION] = str(b["description"])[:300]
        if "system" in b:
            data[CONF_PROMPT] = str(b["system"])
        params = b.get("params") or {}
        for key, conf in (("temperature", CONF_TEMPERATURE), ("top_p", CONF_TOP_P), ("num_predict", CONF_MAX_TOKENS)):
            if key in params and params[key] not in (None, ""):
                data[conf] = float(params[key]) if conf != CONF_MAX_TOKENS else int(params[key])
            elif "params" in b:
                data.pop(conf, None)
        if isinstance(b.get("tools"), list):
            data[CONF_TOOL_GROUPS] = [str(t) for t in b["tools"]]
        title = str(b.get("name") or a.name).strip()[:80] or a.name
        self.hass.config_entries.async_update_subentry(a.entry, a.subentry, data=data, title=title)
        return self.json({"ok": True})


class ServicesView(_V):
    url = API + "/services"
    name = "api:artificial_intelligence:services"

    async def get(self, request):
        out = []
        agents = self.rt.list_agents()
        for entry in self.hass.config_entries.async_entries(DOMAIN):
            if entry.data.get(CONF_ENTRY_TYPE) != ENTRY_SERVICE:
                continue
            c = self.rt.providers.get(entry.entry_id)
            st = c.stats if c else None
            out.append({"id": entry.entry_id, "name": entry.title, "type": PRESETS.get(entry.data.get(CONF_PRESET, "custom"), ("OpenAI-compatible",))[0],
                        "url": urlparse(base_url_for(dict(entry.data))).netloc, "connected": bool(st and st.connected is not False and c),
                        "requests_today": st.requests if st else 0, "tokens_today": st.tokens if st else 0, "last_error": (st.last_error if st else "Not loaded") or None,
                        "models": len(st.models) if st else 0,
                        "agents": [{"entity_id": a.entity_id, "name": a.name, "kind": "task" if a.kind == SUB_AI_TASK else "conversation", "model": a.data.get("model")}
                                   for a in agents if a.entry.entry_id == entry.entry_id]})
        return self.json({"services": out})


# ---------------------------------------------------------------------- chat
def _target(rt: Runtime, ref: AgentRef) -> tuple[Any, str, dict, str]:
    """(client, model, settings, extra system prompt) for an agent; a Boss AI talks through its primary."""
    if ref.kind == SUB_BOSS:
        pri = rt.resolve_agent(ref.data.get(CONF_PRIMARY))
        if not pri or not pri.client:
            raise ProviderError("This Boss AI's primary agent is missing. Edit the Boss AI.", 404)
        extra = "\n\n".join(x for x in (ref.data.get(CONF_PRIMARY_PROMPT), "Use ask_secondary for practical work, especially anything in the home. Check its answer before replying.") if x)
        return pri.client, pri.data.get("model"), pri.data, extra
    if not ref.client:
        raise ProviderError(f"The service for {ref.name} is not loaded.", 503)
    return ref.client, ref.data.get("model"), ref.data, ref.data.get("prompt") or ""


class ChatView(_V):
    url = API + "/chat"
    name = "api:artificial_intelligence:chat"

    async def post(self, request):
        b = await request.json()
        ref = self.rt.resolve_agent(b.get("agent"))
        if not ref or ref.kind == SUB_AI_TASK:
            return self.json({"error": "That agent no longer exists. Pick another model."}, status_code=404)
        try:
            client, model, data, extra = _target(self.rt, ref)
        except ProviderError as err:
            return self.json({"error": str(err)}, status_code=err.status or 502)
        msgs = page_messages(b.get("messages") or [], bool(data.get(CONF_VISION)))
        if extra:
            if msgs and msgs[0]["role"] == "system":
                msgs[0]["content"] = extra + "\n\n" + msgs[0]["content"]
            else:
                msgs.insert(0, {"role": "system", "content": extra})
        params = agent_params(data, _think(b.get("think")) if (data.get(CONF_REASONING) or "none") != "none" else None)
        if b.get("format"):
            params["json"] = True
        tools = b.get("tools") if (ref.kind == SUB_BOSS or data.get(CONF_TOOLS, True)) else None
        started = time.monotonic()
        gen = client.stream(model, msgs, tools or None, params)
        try:
            first = await gen.__anext__()
        except StopAsyncIteration:
            first = None
        except ProviderError as err:
            return self.json({"error": str(err)}, status_code=err.status if err.status >= 400 else 502)
        resp = web.StreamResponse(headers={"Content-Type": "application/x-ndjson", "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        await resp.prepare(request)
        chars = 0

        async def send(obj: dict) -> None:
            await resp.write((json.dumps(obj) + "\n").encode())

        async def handle(piece: dict) -> None:
            nonlocal chars
            if piece.get("content"):
                chars += len(piece["content"])
                await send({"message": {"role": "assistant", "content": piece["content"]}, "done": False})
            if piece.get("reasoning"):
                await send({"message": {"role": "assistant", "content": "", "thinking": piece["reasoning"]}, "done": False})
            if "tool_calls" in piece:
                if piece["tool_calls"]:
                    await send({"message": {"role": "assistant", "content": "", "tool_calls": [{"function": {"name": c["name"], "arguments": c["arguments"]}} for c in piece["tool_calls"]]}, "done": False})
                usage = piece.get("usage") or {}
                ns = int((time.monotonic() - started) * 1e9)
                await send({"done": True, "done_reason": piece.get("finish_reason") or "stop", "eval_count": usage.get("completion_tokens") or chars // 4,
                            "prompt_eval_count": usage.get("prompt_tokens") or 0, "eval_duration": ns, "total_duration": ns})

        try:
            if first is not None:
                await handle(first)
            async for piece in gen:
                await handle(piece)
        except ProviderError as err:
            await send({"error": str(err)})
        except (ConnectionResetError, aiohttp.ClientError):
            await gen.aclose()
            return resp
        try:
            await resp.write_eof()
        except ConnectionResetError:
            pass
        return resp


class TaskView(_V):
    """Small jobs for the page (titles, tags, follow-ups): the AI task agent chosen in Settings, or the chat agent."""

    url = API + "/ai_task"
    name = "api:artificial_intelligence:ai_task_small"

    async def post(self, request):
        b = await request.json()
        ref = self.rt.resolve_agent(b.get("task_agent")) or self.rt.resolve_agent(b.get("agent"))
        if not ref:
            ref = next((a for a in self.rt.list_agents() if a.kind == SUB_AI_TASK), None) or next((a for a in self.rt.list_agents() if a.kind == SUB_CONVERSATION), None)
        if not ref:
            return self.json({"error": "No agents are set up."}, status_code=404)
        try:
            client, model, data, extra = _target(self.rt, ref)
            msgs = [{"role": "system", "content": "\n\n".join(x for x in (extra, b.get("system")) if x) or "Be brief."}, {"role": "user", "content": str(b.get("prompt") or "")}]
            reply = await client.complete(model, msgs, None, {**agent_params(data), "temperature": 0.3})
        except ProviderError as err:
            return self.json({"error": str(err)}, status_code=err.status if err.status >= 400 else 502)
        return self.json({"text": reply["content"]})


# ---------------------------------------------------------------------- web search and fetch (replace Ollama's web tools)
def _strip(s: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", s or "")).strip()


async def web_search(hass: HomeAssistant, rt: Runtime, query: str, n: int) -> list[dict]:
    backend = rt.backend_entry()
    opts = dict(backend.options) if backend else {}
    session = async_get_clientsession(hass)
    timeout = aiohttp.ClientTimeout(total=20)
    kind = opts.get(CONF_SEARCH, "duckduckgo")
    if kind == "searxng" and opts.get(CONF_SEARXNG_URL):
        async with session.get(opts[CONF_SEARXNG_URL].rstrip("/") + "/search", params={"q": query, "format": "json"}, timeout=timeout) as r:
            data = await r.json(content_type=None)
        return [{"title": x.get("title", ""), "url": x.get("url", ""), "content": x.get("content", "")} for x in (data.get("results") or [])[:n]]
    if kind == "brave" and opts.get(CONF_BRAVE_KEY):
        async with session.get("https://api.search.brave.com/res/v1/web/search", params={"q": query, "count": n},
                               headers={"X-Subscription-Token": opts[CONF_BRAVE_KEY], "Accept": "application/json"}, timeout=timeout) as r:
            data = await r.json(content_type=None)
        return [{"title": x.get("title", ""), "url": x.get("url", ""), "content": _strip(x.get("description", ""))} for x in ((data.get("web") or {}).get("results") or [])[:n]]
    async with session.post("https://html.duckduckgo.com/html/", data={"q": query}, headers={"User-Agent": UA}, timeout=timeout) as r:
        page = await r.text()
    out = []
    links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', page, re.S)
    snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</(?:a|div)>', page, re.S)
    for i, (href, title) in enumerate(links[:n]):
        href = html.unescape(href)
        if "uddg=" in href:
            href = parse_qs(urlparse(href if href.startswith("http") else "https:" + href).query).get("uddg", [href])[0]
        out.append({"title": _strip(title), "url": href, "content": _strip(snippets[i]) if i < len(snippets) else ""})
    return out


class WebSearchView(_V):
    url = API + "/tools/web_search"
    name = "api:artificial_intelligence:web_search"

    async def post(self, request):
        b = await request.json()
        q = str(b.get("query") or "").strip()
        if not q:
            return self.json({"error": "query required"}, status_code=400)
        try:
            res = await web_search(self.hass, self.rt, q, max(1, min(10, int(b.get("max_results") or 5))))
        except (aiohttp.ClientError, TimeoutError, ValueError) as err:
            return self.json({"error": f"Web search failed: {err}"}, status_code=502)
        return self.json({"results": res})


class WebFetchView(_V):
    url = API + "/tools/web_fetch"
    name = "api:artificial_intelligence:web_fetch"

    async def post(self, request):
        from .projects import _HTMLText  # noqa: PLC0415

        b = await request.json()
        url = str(b.get("url") or "").strip()
        if not re.match(r"^https?://", url):
            return self.json({"error": "The address must start with http:// or https://"}, status_code=400)
        try:
            async with async_get_clientsession(self.hass).get(url, headers={"User-Agent": UA}, timeout=aiohttp.ClientTimeout(total=25), allow_redirects=True) as r:
                raw = await r.content.read(3_000_000)
                ctype = r.headers.get("Content-Type", "")
                status = r.status
        except (aiohttp.ClientError, TimeoutError) as err:
            return self.json({"error": f"Could not fetch {url}: {err}"}, status_code=502)
        text = raw.decode("utf-8", "replace")
        title = ""
        if "html" in ctype or text.lstrip().lower().startswith(("<!doctype", "<html")):
            m = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
            title = _strip(m.group(1)) if m else ""
            p = _HTMLText()
            p.feed(text)
            text = re.sub(r"\n{3,}", "\n\n", re.sub(r"[ \t\r\f\v]+", " ", "".join(p.out))).strip()
        return self.json({"title": title or url, "content": text[:60000], "status": status})


# ---------------------------------------------------------------------- Boss AIs
def boss_view(rt: Runtime, a: AgentRef) -> dict:
    d = a.data
    return {"id": a.subentry.subentry_id, "name": a.name, "entity_id": a.entity_id, "primary": d.get(CONF_PRIMARY), "secondary": d.get(CONF_SECONDARY),
            "ha": d.get(CONF_HA_AGENT) or BUILTIN_HA_AGENT, "primary_prompt": d.get(CONF_PRIMARY_PROMPT, ""), "secondary_prompt": d.get(CONF_SECONDARY_PROMPT, ""),
            "max_hops": int(d.get(CONF_MAX_HOPS) or 4), "talk_back": bool(d.get(CONF_TALK_BACK, True)), "show_steps": bool(d.get(CONF_SHOW_STEPS, True))}


def _boss_data(b: dict) -> dict:
    return {CONF_PRIMARY: str(b.get("primary") or ""), CONF_SECONDARY: str(b.get("secondary") or ""), CONF_HA_AGENT: str(b.get("ha") or BUILTIN_HA_AGENT),
            CONF_PRIMARY_PROMPT: str(b.get("primary_prompt") or ""), CONF_SECONDARY_PROMPT: str(b.get("secondary_prompt") or ""),
            CONF_MAX_HOPS: max(1, min(8, int(b.get("max_hops") or 4))), CONF_TALK_BACK: bool(b.get("talk_back", True)), CONF_SHOW_STEPS: bool(b.get("show_steps", True))}


class BossListView(_V):
    url = API + "/boss_agents"
    name = "api:artificial_intelligence:boss_agents"

    async def get(self, request):
        bosses = [boss_view(self.rt, a) for a in self.rt.list_agents() if a.kind == SUB_BOSS]
        has = [{"entity_id": s.entity_id, "name": s.name} for s in self.hass.states.async_all("conversation")]
        if not any(h["entity_id"] == BUILTIN_HA_AGENT for h in has):
            has.insert(0, {"entity_id": BUILTIN_HA_AGENT, "name": "Home Assistant (built-in)"})
        return self.json({"bosses": bosses, "ha_agents": has})

    async def post(self, request):
        if (r := self.admin_only(request)) is not None:
            return r
        b = await request.json()
        backend = self.rt.backend_entry()
        if backend is None:
            return self.json({"error": "The Artificial Intelligence backend entry is missing."}, status_code=500)
        data = _boss_data(b)
        if data[CONF_PRIMARY] == data[CONF_SECONDARY]:
            return self.json({"error": "Pick two different models for primary and secondary."}, status_code=400)
        sub = ConfigSubentry(data=MappingProxyType(data), subentry_type=SUB_BOSS, title=str(b.get("name") or "Boss AI").strip()[:80], unique_id=None)
        self.hass.config_entries.async_add_subentry(backend, sub)
        return self.json({"id": sub.subentry_id, "ok": True})


class BossItemView(_V):
    url = API + "/boss_agents/{sid}"
    name = "api:artificial_intelligence:boss_agent"

    def _find(self, sid):
        backend = self.rt.backend_entry()
        sub = (backend.subentries or {}).get(sid) if backend else None
        return backend, sub

    async def put(self, request, sid):
        if (r := self.admin_only(request)) is not None:
            return r
        backend, sub = self._find(sid)
        if not sub:
            return self.json({"error": "No such Boss AI."}, status_code=404)
        b = await request.json()
        data = _boss_data(b)
        if data[CONF_PRIMARY] == data[CONF_SECONDARY]:
            return self.json({"error": "Pick two different models for primary and secondary."}, status_code=400)
        self.hass.config_entries.async_update_subentry(backend, sub, data=data, title=str(b.get("name") or sub.title).strip()[:80])
        return self.json({"ok": True})

    async def delete(self, request, sid):
        if (r := self.admin_only(request)) is not None:
            return r
        backend, sub = self._find(sid)
        if not sub:
            return self.json({"error": "No such Boss AI."}, status_code=404)
        self.hass.config_entries.async_remove_subentry(backend, sid)
        return self.json({"ok": True})


class BossDelegateView(_V):
    url = API + "/boss/{entity_id}/delegate"
    name = "api:artificial_intelligence:boss_delegate"

    async def post(self, request, entity_id):
        ref = self.rt.resolve_agent(entity_id)
        if not ref or ref.kind != SUB_BOSS:
            return self.json({"error": "No such Boss AI."}, status_code=404)
        b = await request.json()
        try:
            answer, trace = await boss_delegate(self.hass, self.rt, ref.data, str(b.get("task") or ""))
        except ProviderError as err:
            return self.json({"error": str(err)}, status_code=502)
        return self.json({"text": "\n".join(trace) or answer, "answer": answer, "trace": trace})


VIEWS = (AgentsListView, AgentEditView, ServicesView, ChatView, TaskView, WebSearchView, WebFetchView, BossListView, BossItemView, BossDelegateView)


def setup_chat_api(hass: HomeAssistant, rt: Runtime) -> None:
    for view in VIEWS:
        hass.http.register_view(view(hass, rt))
