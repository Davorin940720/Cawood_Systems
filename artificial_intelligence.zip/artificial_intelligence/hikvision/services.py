"""Services: artificial_intelligence.cai_hikvision_analyze and artificial_intelligence.cai_hikvision_get_events."""
from __future__ import annotations

import re

import voluptuous as vol

from homeassistant.core import HomeAssistant, ServiceCall, ServiceResponse, SupportsResponse
from homeassistant.exceptions import HomeAssistantError, ServiceValidationError
from homeassistant.helpers import config_validation as cv, entity_registry as er

from ..const import DOMAIN
from ..runtime import Runtime
from .const import NAME
from .hub import CaiHikvisionHub, get_hub, public
from .isapi import IsapiError
from .vision import VisionError

SERVICE_ANALYZE = "cai_hikvision_analyze"
SERVICE_EVENTS = "cai_hikvision_get_events"

_BASE = {
    vol.Optional("camera"): cv.entity_id,
    vol.Optional("channel"): vol.Coerce(int),
    vol.Optional("dvr"): cv.string,
}
ANALYZE_SCHEMA = vol.Schema(
    {
        **_BASE,
        vol.Optional("question"): cv.string,
        vol.Optional("frames"): vol.All(vol.Coerce(int), vol.Range(min=1, max=5)),
        vol.Optional("notify", default=False): cv.boolean,
    }
)
EVENTS_SCHEMA = vol.Schema(
    {
        **_BASE,
        vol.Optional("limit", default=20): vol.All(vol.Coerce(int), vol.Range(min=1, max=100)),
        vol.Optional("since_hours"): vol.Coerce(float),
    }
)


def _resolve(hass: HomeAssistant, rt: Runtime, data: dict, require_channel: bool) -> tuple[CaiHikvisionHub, int | None]:
    try:
        if cam := data.get("camera"):
            ent = er.async_get(hass).async_get(cam)
            match = re.search(r"_ch(\d+)_camera$", ent.unique_id or "") if ent else None
            if not ent or ent.platform != DOMAIN or not match:
                raise ServiceValidationError(f"{cam} is not a {NAME} camera")
            hub = rt.hubs.get(ent.config_entry_id)
            if hub is None:
                raise ServiceValidationError(f"Recorder for {cam} is not loaded")
            return hub, int(match.group(1))
        hub = get_hub(rt, data.get("dvr"))
        channel = hub.resolve_channel(data.get("channel")) if data.get("channel") is not None else None
    except (LookupError, ValueError) as err:
        raise ServiceValidationError(str(err)) from err
    if require_channel and channel is None:
        raise ServiceValidationError("Provide 'camera' or 'channel'")
    return hub, channel


def async_register_services(hass: HomeAssistant, rt: Runtime) -> None:
    if hass.services.has_service(DOMAIN, SERVICE_ANALYZE):
        return

    async def _analyze(call: ServiceCall) -> ServiceResponse:
        hub, channel = _resolve(hass, rt, call.data, True)
        try:
            rec = await hub.async_analyse(
                channel,
                question=call.data.get("question"),
                trigger="service",
                frames=call.data.get("frames"),
                notify=call.data["notify"],
            )
        except ValueError as err:
            raise ServiceValidationError(str(err)) from err
        except (IsapiError, VisionError) as err:
            raise HomeAssistantError(str(err)) from err
        return public(rec) if call.return_response else None

    async def _get_events(call: ServiceCall) -> ServiceResponse:
        hub, channel = _resolve(hass, rt, call.data, False)
        return hub.query_events(channel, call.data["limit"], call.data.get("since_hours"))

    hass.services.async_register(DOMAIN, SERVICE_ANALYZE, _analyze, schema=ANALYZE_SCHEMA, supports_response=SupportsResponse.OPTIONAL)
    hass.services.async_register(DOMAIN, SERVICE_EVENTS, _get_events, schema=EVENTS_SCHEMA, supports_response=SupportsResponse.ONLY)
