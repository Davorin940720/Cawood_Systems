"""Runtime hub for one Hikvision recorder: events, snapshots, AI analysis and teaching."""
from __future__ import annotations

import asyncio
import copy
from collections import deque
import logging
from functools import partial
import os
import re
import time
from typing import TYPE_CHECKING, Any
import uuid

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_PASSWORD, CONF_PORT, CONF_USERNAME
from homeassistant.core import CALLBACK_TYPE, HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.dispatcher import async_dispatcher_send
from homeassistant.helpers.event import async_call_later
from homeassistant.helpers.httpx_client import get_async_client
from homeassistant.helpers.storage import Store
from homeassistant.util import dt as dt_util

from ..const import DOMAIN
from .const import (
    CHANNEL_KINDS,
    CONF_ALARM_ENTITY,
    CONF_ANALYSE_EVENTS,
    CONF_ANALYSIS_CHANNELS,
    CONF_ASK_QUESTIONS,
    CONF_AUTH_TYPE,
    CONF_COOLDOWN,
    CONF_FRAME_INTERVAL,
    CONF_FRAMES,
    CONF_IDENTITY_CONFIDENCE,
    CONF_KEEP_EVENTS,
    CONF_KEEP_IMAGES,
    CONF_MAX_REFERENCES,
    CONF_MOTION_TIMEOUT,
    CONF_VISION_AGENT,
    CONF_NOTIFY_MIN_THREAT,
    CONF_NOTIFY_SERVICES,
    CONF_ONLY_WHEN_ARMED,
    CONF_PROMPT,
    CONF_RTSP_PORT,
    CONF_THREAT_FLOOR,
    CONF_USE_SSL,
    CONF_VERIFY_SSL,
    DEFAULT_OPTIONS,
    DETECTIONS_MAX,
    EVENT_ANALYSIS,
    EVENT_RAW,
    MEDIA_SUBDIR,
    OBJECT_KINDS,
    THREAT_LEVELS,
)
from .isapi import Channel, DeviceInfo as HikDeviceInfo, HikEvent, IsapiAuthError, IsapiClient, IsapiError
from .training import apply_threat, crop_image, finish_summary, resolve_identities, similarity
from .vision import ProviderVision, VisionError

if TYPE_CHECKING:  # pragma: no cover
    from ..runtime import Runtime

_HAS_VIA_ID = "via_device_id" in DeviceInfo.__annotations__
_LOGGER = logging.getLogger(__name__)
_LEGACY_STORE_PREFIX = "cai_hikvision."


def parse_notify_services(text: str | None) -> list[str]:
    return [s.strip() for s in re.split(r"[,\n;]", text or "") if s.strip()]


def get_hub(rt: "Runtime", dvr: str | None = None) -> "CaiHikvisionHub":
    hubs = rt.hubs
    if not hubs:
        raise LookupError("No Hikvision recorder is set up or loaded. Add one under Settings > Devices & services > Artificial Intelligence > Add entry > Hikvision DVR.")
    if dvr:
        key = str(dvr).strip().lower()
        for hub in hubs.values():
            if key in (hub.entry.entry_id.lower(), hub.name.lower(), str(hub.uid).lower()):
                return hub
        raise LookupError(f"Unknown recorder '{dvr}'. Loaded: {', '.join(h.name for h in hubs.values())}")
    return next(iter(hubs.values()))


def find_event(rt: "Runtime", event_id: str) -> tuple["CaiHikvisionHub", dict[str, Any]] | None:
    for hub in rt.hubs.values():
        rec = hub.event(event_id)
        if rec is not None:
            return hub, rec
    return None


def public(rec: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in rec.items() if k != "image_file"}


def _clean_name(answer: str) -> tuple[str, str]:
    """'Emma, my niece' -> ('Emma', 'Emma, my niece')."""
    text = (answer or "").strip()
    name = re.split(r"\s+[-–—]\s+|[,.;:(]", text, maxsplit=1)[0].strip()
    name = re.sub(r"^(?:it'?s|that'?s|this is|that is|it is|he is|she is|they are|its)\s+", "", name, flags=re.I).strip()
    return (name or text)[:60], text


def _swap_description(summary: str, description: str, name: str) -> str:
    """Replace the visual description of an object in the summary by its name, if the wording is there."""
    desc = re.sub(r"^(?:an?|the)\s+", "", (description or "").strip(), flags=re.I).rstrip(".")
    if desc:
        pattern = re.compile(r"\b(?:an?\s+|the\s+)?" + re.escape(desc) + r"\b", re.I)
        if pattern.search(summary):
            return pattern.sub(name, summary, count=1)
    return summary


class CaiHikvisionHub:
    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, rt: "Runtime") -> None:
        self.hass = hass
        self.entry = entry
        self.rt = rt
        data = entry.data
        self.isapi = IsapiClient(
            get_async_client(hass, verify_ssl=data.get(CONF_VERIFY_SSL, False)),
            data[CONF_HOST],
            data[CONF_PORT],
            data[CONF_USERNAME],
            data[CONF_PASSWORD],
            use_ssl=data.get(CONF_USE_SSL, False),
            auth_type=data.get(CONF_AUTH_TYPE, "digest"),
        )
        self.rtsp_port: int = data.get(CONF_RTSP_PORT, 554)
        self.device: HikDeviceInfo | None = None
        self.channels: dict[int, Channel] = {}
        self.io_inputs: dict[int, str] = {}
        self.states: dict[str, bool] = {}
        self.stream_connected = False
        self.last_analysis: dict[int, dict[str, Any]] = {}
        self.history: list[dict[str, Any]] = []           # newest first; trained entries are never trimmed
        self.detections: deque[dict[str, Any]] = deque(maxlen=DETECTIONS_MAX)
        self.vision_status: dict[str, Any] = {"usable": True, "reason": "Not checked yet"}
        self._off_timers: dict[str, CALLBACK_TYPE] = {}
        self._last_trigger: dict[int, float] = {}
        self._locks: dict[int, asyncio.Lock] = {}
        self._store: Store | None = None
        self._stream_error_logged = False
        self.dvr_device_id: str | None = None

    # ------------------------------------------------------------ properties
    @property
    def opts(self) -> dict[str, Any]:
        return {**DEFAULT_OPTIONS, **self.entry.options}

    @property
    def uid(self) -> str:
        return self.entry.unique_id or self.entry.entry_id

    @property
    def name(self) -> str:
        return self.entry.title

    @property
    def signal_state(self) -> str:
        return f"{DOMAIN}_{self.entry.entry_id}_state"

    @property
    def signal_analysis(self) -> str:
        return f"{DOMAIN}_{self.entry.entry_id}_analysis"

    @property
    def signal_questions(self) -> str:
        return f"{DOMAIN}_questions"

    # ------------------------------------------------------------ lifecycle
    async def async_setup(self) -> None:
        """Raises IsapiAuthError / IsapiError on failure."""
        self.device = await self.isapi.device_info()
        self.channels = {c.id: c for c in await self.isapi.streaming_channels()}
        try:
            self.io_inputs = dict(await self.isapi.io_inputs())
        except IsapiError as err:
            _LOGGER.debug("%s: no alarm inputs (%s)", self.name, err)
        safe = re.sub(r"[^A-Za-z0-9_]", "_", self.uid)
        self._store = Store(self.hass, 1, f"{DOMAIN}.hikvision_{safe}")
        stored = await self._store.async_load()
        if stored is None:
            stored = await self._import_legacy()
        stored = stored or {}
        self.history = list(stored.get("history", []))
        self.detections.extend(stored.get("detections", [])[:DETECTIONS_MAX])
        for key, rec in stored.get("last_analysis", {}).items():
            try:
                self.last_analysis[int(key)] = rec
            except ValueError:
                continue
        for rec in self.history:  # events imported from the old integration used another image URL
            if str(rec.get("image_api", "")).startswith("/api/cai_hikvision/event_image/"):
                rec["image_api"] = f"/api/{DOMAIN}/hikvision/events/{rec['id']}/image" if rec.get("image_file") else ""
        # last_analysis must point at the same dict as the history entry so teaching updates both
        by_id = {r.get("id"): r for r in self.history}
        for ch, rec in list(self.last_analysis.items()):
            self.last_analysis[ch] = by_id.get(rec.get("id"), rec)
        _LOGGER.info(
            "%s (%s) ready: %d channels, %d alarm inputs, %d logged analyses",
            self.name, self.device.model, len(self.channels), len(self.io_inputs), len(self.history),
        )

    async def _import_legacy(self) -> dict[str, Any] | None:
        """Bring the event log of the old cai_hikvision integration across (one recorder only, once)."""
        folder = self.hass.config.path(".storage")

        def find() -> str | None:
            try:
                names = [n for n in os.listdir(folder) if n.startswith(_LEGACY_STORE_PREFIX)]
            except OSError:
                return None
            return names[0] if len(names) == 1 else None

        name = await self.hass.async_add_executor_job(find)
        if not name:
            return None
        legacy = Store(self.hass, 1, name)
        data = await legacy.async_load()
        if isinstance(data, dict) and data.get("history"):
            _LOGGER.info("%s: imported %d analyses from the old cai_hikvision integration", self.name, len(data["history"]))
            return data
        return None

    @callback
    def async_start(self) -> None:
        self.entry.async_create_background_task(self.hass, self._stream_loop(), f"{DOMAIN} alert stream {self.name}")
        self.entry.async_create_background_task(self.hass, self.async_check_vision(), f"{DOMAIN} vision check {self.name}")

    async def async_shutdown(self) -> None:
        for cancel in self._off_timers.values():
            cancel()
        self._off_timers.clear()
        if self._store:
            await self._store.async_save(self._store_data())

    # ------------------------------------------------------------ devices
    def dvr_device_info(self) -> DeviceInfo:
        dev = self.device
        return DeviceInfo(
            identifiers={(DOMAIN, self.uid)},
            name=self.name,
            manufacturer="Hikvision",
            model=dev.model if dev else None,
            sw_version=dev.firmware if dev else None,
            serial_number=dev.serial if dev else None,
            configuration_url=self.isapi.base,
        )

    def channel_device_info(self, ch: Channel) -> DeviceInfo:
        info = DeviceInfo(
            identifiers={(DOMAIN, f"{self.uid}_ch{ch.id}")},
            name=ch.name,
            manufacturer="Hikvision",
            model=f"Channel {ch.id}",
        )
        if _HAS_VIA_ID and self.dvr_device_id:
            info["via_device_id"] = self.dvr_device_id
        else:
            info["via_device"] = (DOMAIN, self.uid)
        return info

    # ------------------------------------------------------------ alert stream
    @callback
    def _on_stream_connect(self) -> None:
        if self._stream_error_logged:
            _LOGGER.info("%s: event stream reconnected", self.name)
        self._stream_error_logged = False
        self._set_connected(True)

    async def _stream_loop(self) -> None:
        backoff = 5
        while True:
            try:
                async for ev in self.isapi.alert_stream(on_connect=self._on_stream_connect):
                    backoff = 5
                    self._handle_event(ev)
                _LOGGER.debug("%s: event stream closed by recorder", self.name)
            except asyncio.CancelledError:
                raise
            except IsapiAuthError as err:
                _LOGGER.error("%s: event stream credentials rejected: %s", self.name, err)
                backoff = 600
            except IsapiError as err:
                if not self._stream_error_logged:
                    _LOGGER.warning("%s: event stream lost (%s), retrying", self.name, err)
                    self._stream_error_logged = True
                else:
                    _LOGGER.debug("%s: event stream retry failed: %s", self.name, err)
            except Exception:  # noqa: BLE001
                _LOGGER.exception("%s: unexpected event stream error", self.name)
            self._set_connected(False)
            await asyncio.sleep(backoff)
            backoff = backoff if backoff >= 600 else min(backoff * 2, 300)

    @callback
    def _set_connected(self, value: bool) -> None:
        if self.stream_connected != value:
            self.stream_connected = value
            async_dispatcher_send(self.hass, self.signal_state, "stream")

    @callback
    def _set_state(self, key: str, value: bool) -> None:
        if self.states.get(key, False) != value:
            self.states[key] = value
            async_dispatcher_send(self.hass, self.signal_state, key)

    @callback
    def _cancel_timer(self, key: str) -> None:
        if cancel := self._off_timers.pop(key, None):
            cancel()

    def _make_off(self, key: str):
        @callback
        def _off(_now) -> None:
            self._off_timers.pop(key, None)
            self._set_state(key, False)

        return _off

    def channel_allowed(self, channel: int) -> bool:
        allowed = {int(x) for x in re.findall(r"\d+", str(self.opts[CONF_ANALYSIS_CHANNELS] or ""))}
        return not allowed or channel in allowed

    @callback
    def _handle_event(self, ev: HikEvent) -> None:
        if ev.is_heartbeat:
            if ev.channel in self.channels:
                self._set_state(f"ch{ev.channel}_video_loss", False)
            return

        if ev.kind == "alarm_input" and ev.io_port is not None:
            key = f"io{ev.io_port}"
            on = ev.state != "inactive"
            was = self.states.get(key, False)
            self._set_state(key, on)
            if on != was:
                self._fire_raw(ev)
                if on:
                    self._log_detection(ev, None)
            return

        if ev.kind is None or ev.channel not in self.channels:
            _LOGGER.debug("%s: unhandled event %s", self.name, ev.raw)
            return

        key = f"ch{ev.channel}_{ev.kind}"
        if ev.state == "inactive":
            self._cancel_timer(key)
            if self.states.get(key):
                self._set_state(key, False)
                self._fire_raw(ev)
            return

        was = self.states.get(key, False)
        self._set_state(key, True)
        self._cancel_timer(key)
        self._off_timers[key] = async_call_later(self.hass, float(self.opts[CONF_MOTION_TIMEOUT]), self._make_off(key))
        if not was:
            self._fire_raw(ev)
            self._log_detection(ev, ev.channel)

        opts = self.opts
        if ev.kind in opts[CONF_ANALYSE_EVENTS] and self.channel_allowed(ev.channel):
            now = time.monotonic()
            if now - self._last_trigger.get(ev.channel, -1e9) >= float(opts[CONF_COOLDOWN]):
                self._last_trigger[ev.channel] = now
                self.entry.async_create_background_task(
                    self.hass, self._event_analysis(ev.channel, ev.kind), f"{DOMAIN} analysis {self.name} ch{ev.channel}"
                )

    @callback
    def _fire_raw(self, ev: HikEvent) -> None:
        ch = self.channels.get(ev.channel) if ev.channel else None
        self.hass.bus.async_fire(
            EVENT_RAW,
            {
                "dvr": self.name,
                "dvr_id": self.entry.entry_id,
                "channel": ev.channel,
                "camera": ch.name if ch else None,
                "io_port": ev.io_port,
                "kind": ev.kind,
                "event_type": ev.event_type,
                "state": ev.state,
                "description": ev.description,
                "time": dt_util.now().isoformat(),
            },
        )

    @callback
    def _log_detection(self, ev: HikEvent, channel: int | None) -> None:
        ch = self.channels.get(channel) if channel else None
        self.detections.appendleft(
            {
                "time": dt_util.now().isoformat(),
                "channel": channel,
                "camera": ch.name if ch else self.io_inputs.get(ev.io_port or -1),
                "kind": ev.kind,
                "event_type": ev.event_type,
            }
        )
        self._schedule_save()

    # ------------------------------------------------------------ AI analysis
    def _vision_ref(self):
        """The AI task agent chosen in the recorder options, or else the first one that can read images."""
        from ..const import CONF_VISION, SUB_AI_TASK  # noqa: PLC0415

        rt = self.rt
        ref = rt.resolve_agent(self.opts.get(CONF_VISION_AGENT))
        if ref is None or ref.kind != SUB_AI_TASK:
            ref = next((a for a in rt.list_agents() if a.kind == SUB_AI_TASK and a.data.get(CONF_VISION)), None)
        return ref

    async def _vision(self) -> ProviderVision:
        from ..const import CONF_PROMPT as AGENT_PROMPT, CONF_VISION  # noqa: PLC0415
        from ..llm_bridge import agent_params  # noqa: PLC0415

        ref = self._vision_ref()
        if ref is None or ref.client is None:
            raise VisionError("No AI task agent that can read images is set up. Add one under an AI service, then pick it in the recorder options or on cai_hik_config.html.")
        return ProviderVision(ref.client, ref.data.get("model"), ref.name, bool(ref.data.get(CONF_VISION)), ref.data.get(AGENT_PROMPT) or "", agent_params(ref.data))

    async def async_check_vision(self) -> None:
        try:
            v = await self._vision()
        except VisionError as err:
            self.vision_status = {"usable": False, "reason": str(err)}
        else:
            if v.can_see:
                self.vision_status = {"usable": True, "reason": "", "agent": v.name}
            else:
                self.vision_status = {"usable": False, "reason": f"The AI task agent '{v.name}' is not marked as able to read images. Turn on 'Reads images' on it, or pick another agent."}
        if not self.vision_status["usable"]:
            _LOGGER.warning("%s: AI vision unavailable: %s", self.name, self.vision_status["reason"])

    async def _event_analysis(self, channel: int, kind: str) -> None:
        try:
            await self.async_analyse(channel, trigger=kind, notify=True)
        except (IsapiError, VisionError) as err:
            _LOGGER.warning("%s: analysis for channel %s failed: %s", self.name, channel, err)
        except Exception:  # noqa: BLE001
            _LOGGER.exception("%s: analysis for channel %s crashed", self.name, channel)

    def _build_prompt(self, ch: Channel, trigger: str, question: str | None, frames: int, training: str, mid: int) -> str:
        if question:
            qblock = f'User question: {question}\nAnswer it directly in "answer".'
        else:
            qblock = 'There is no user question, leave "answer" empty.'
        template = str(self.opts[CONF_PROMPT])
        if "{training_block}" not in template:  # a prompt saved before teaching existed
            marker = "Reply with ONLY"
            template = template.replace(marker, "{training_block}\n" + marker, 1) if marker in template else template + "\n{training_block}"
        return (
            template.replace("{camera}", f"{ch.name} (channel {ch.id})")
            .replace("{trigger}", trigger.replace("_", " "))
            .replace("{time}", dt_util.now().strftime("%A %d %B %Y %H:%M"))
            .replace("{frames}", str(frames))
            .replace("{training_block}", training)
            .replace("{box_frame_label}", f"live frame {mid} (counting live frames only, oldest first)")
            .replace("{question_block}", qblock)
        )

    async def _grab_frames(self, ch: Channel, count: int, interval: float) -> list[bytes]:
        images: list[bytes] = []
        last_err: IsapiError | None = None
        for i in range(count):
            try:
                images.append(await self.isapi.snapshot(ch.stream_id))
            except IsapiError as err:
                last_err = err
            if i < count - 1:
                await asyncio.sleep(interval)
        if not images:
            raise last_err or IsapiError(f"No frames captured from {ch.name}")
        return images

    def _media_dir(self) -> str:
        base = self.hass.config.media_dirs.get("local") or self.hass.config.path("media")
        return os.path.join(base, MEDIA_SUBDIR)

    def _write_image(self, filename: str, data: bytes, keep: int, protected: set[str]) -> None:
        folder = self._media_dir()
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, filename), "wb") as fh:
            fh.write(data)
        prefix = f"{self.entry.entry_id[:8]}_"
        files = sorted(f for f in os.listdir(folder) if f.startswith(prefix) and f.endswith(".jpg") and f not in protected)
        for old in files[: max(0, len(files) - keep)]:
            try:
                os.remove(os.path.join(folder, old))
            except OSError:
                pass

    def image_path(self, event_id: str) -> str | None:
        rec = self.event(event_id)
        if rec and rec.get("image_file"):
            path = os.path.join(self._media_dir(), rec["image_file"])
            return path if os.path.isfile(path) else None
        return None

    def read_image(self, event_id: str) -> bytes | None:
        path = self.image_path(event_id)
        if not path:
            return None
        with open(path, "rb") as fh:
            return fh.read()

    def event(self, event_id: str) -> dict[str, Any] | None:
        for rec in self.history:
            if rec.get("id") == event_id:
                return rec
        return None

    def resolve_channel(self, number: int | str | None) -> int | None:
        """Accept a camera number (1) or a stream number (101) and return the camera number."""
        if number in (None, ""):
            return None
        n = int(number)
        if n in self.channels:
            return n
        for ch in self.channels.values():
            if ch.stream_id == n:
                return ch.id
        raise ValueError(f"Unknown channel {n}. Cameras: " + ", ".join(f"{c.id} ({c.name}, stream {c.stream_id})" for c in self.channels.values()))

    async def async_snapshot(self, channel: int) -> bytes:
        channel = self.resolve_channel(channel)  # type: ignore[assignment]
        ch = self.channels.get(channel)
        if ch is None:
            raise ValueError(f"Unknown channel {channel}. Available: {sorted(self.channels)}")
        return await self.isapi.snapshot(ch.stream_id)

    async def _run_vision(
        self, ch: Channel, images: list[bytes], trigger: str, question: str | None, store_refs: bool = True
    ) -> dict[str, Any]:
        """One model call with everything the owner has taught, then identity matching, rules and questions."""
        opts = self.opts
        training = self.rt.training
        block, refs = "", []
        if training is not None:
            block, refs = await self.hass.async_add_executor_job(training.training_block, ch.id, int(opts[CONF_MAX_REFERENCES]))
            entities = await self.hass.async_add_executor_job(training.entities)
            rules = await self.hass.async_add_executor_job(training.rules)
        else:
            entities, rules = {}, []
        mid = len(images) // 2 + 1
        prompt = self._build_prompt(ch, trigger, question, len(images), block, mid)
        analysis = await (await self._vision()).analyse([d for _n, d in refs] + images, prompt)
        analysis["references_used"] = [n for n, _d in refs]
        now = dt_util.now()
        resolve_identities(analysis, entities, float(opts[CONF_IDENTITY_CONFIDENCE]))
        analysis["trigger"] = trigger
        analysis["channel"] = ch.id
        apply_threat(analysis, rules, entities, now.hour * 60 + now.minute, str(opts[CONF_THREAT_FLOOR]))
        finish_summary(analysis)
        return analysis

    async def async_analyse(
        self,
        channel: int,
        question: str | None = None,
        trigger: str = "manual",
        frames: int | None = None,
        notify: bool = False,
    ) -> dict[str, Any]:
        channel = self.resolve_channel(channel)  # type: ignore[assignment]
        ch = self.channels.get(channel)
        if ch is None:
            raise ValueError(f"Unknown channel {channel}. Available: {sorted(self.channels)}")
        opts = self.opts
        count = max(1, min(5, int(frames or opts[CONF_FRAMES])))
        lock = self._locks.setdefault(channel, asyncio.Lock())
        async with lock:
            started = time.monotonic()
            images = await self._grab_frames(ch, count, float(opts[CONF_FRAME_INTERVAL]))
            analysis = await self._run_vision(ch, images, trigger, question)
            duration = round(time.monotonic() - started, 1)

        rid = uuid.uuid4().hex[:12]
        now = dt_util.now()
        filename = f"{self.entry.entry_id[:8]}_{now:%Y%m%d%H%M%S}_ch{channel:02d}_{rid}.jpg"
        protected = {r["image_file"] for r in self.history if r.get("trained") and r.get("image_file")}
        try:
            await self.hass.async_add_executor_job(
                self._write_image, filename, images[len(images) // 2], int(opts[CONF_KEEP_IMAGES]), protected
            )
        except OSError as err:
            _LOGGER.warning("%s: could not save event image: %s", self.name, err)
            filename = ""

        rec: dict[str, Any] = {
            "id": rid,
            "time": now.isoformat(),
            "dvr": self.name,
            "dvr_id": self.entry.entry_id,
            "channel": channel,
            "camera": ch.name,
            "question": question or "",
            **analysis,
            "frames": len(images),
            "duration_s": duration,
            "image_file": filename,
            "image_url": f"/media/local/{MEDIA_SUBDIR}/{filename}" if filename else "",
            "image_api": f"/api/{DOMAIN}/hikvision/events/{rid}/image" if filename else "",
            "trained": False,
        }
        self.last_analysis[channel] = rec
        self.history.insert(0, rec)
        self._trim_history()
        self._schedule_save()

        training = self.rt.training
        if training is not None:
            for obj in rec.get("objects", []):
                if obj.get("entity_id"):
                    await self.hass.async_add_executor_job(training.note_seen, obj["entity_id"], channel)
            if opts[CONF_ASK_QUESTIONS]:
                created = await self.hass.async_add_executor_job(training.add_questions, rec)
                if created:
                    rec["question_ids"] = [q["id"] for q in created]
                    async_dispatcher_send(self.hass, self.signal_questions)

        async_dispatcher_send(self.hass, self.signal_analysis, channel)
        self.hass.bus.async_fire(EVENT_ANALYSIS, public(rec))
        if notify:
            await self._maybe_notify(rec)
        return rec

    async def async_replay(self, event_id: str) -> dict[str, Any]:
        """Re-run the model on a saved event image with everything taught so far. Nothing is stored."""
        rec = self.event(event_id)
        if rec is None:
            raise ValueError("Event not found")
        data = await self.hass.async_add_executor_job(self.read_image, event_id)
        if data is None:
            raise ValueError("The image for this event is no longer on disk")
        ch = self.channels.get(rec["channel"])
        if ch is None:
            raise ValueError("That camera is not on this recorder any more")
        result = await self._run_vision(ch, [data], rec.get("trigger", "manual"), None)
        return {k: v for k, v in result.items() if k not in ("model",)}

    def _alarm_armed(self) -> bool | None:
        entity = self.opts[CONF_ALARM_ENTITY]
        if not entity:
            return None
        state = self.hass.states.get(entity)
        if state is None:
            return None
        return state.state.startswith("armed") or state.state in ("triggered", "pending", "arming")

    async def _maybe_notify(self, rec: dict[str, Any]) -> None:
        opts = self.opts
        services = parse_notify_services(opts[CONF_NOTIFY_SERVICES])
        if not services:
            return
        if THREAT_LEVELS.index(rec["threat_level"]) < THREAT_LEVELS.index(opts[CONF_NOTIFY_MIN_THREAT]):
            return
        if opts[CONF_ONLY_WHEN_ARMED] and self._alarm_armed() is False:
            return
        data: dict[str, Any] = {"tag": f"{DOMAIN}_{self.entry.entry_id[:8]}_{rec['channel']}", "group": DOMAIN}
        if rec["image_url"]:
            data.update({"image": rec["image_url"], "url": rec["image_url"], "clickAction": rec["image_url"]})
        if rec["threat_level"] == "high":
            data.update({"priority": "high", "ttl": 0, "push": {"interruption-level": "time-sensitive"}})
        payload = {
            "title": f"{rec['camera']}: {rec['threat_level']} threat ({rec['trigger'].replace('_', ' ')})",
            "message": rec["summary"],
            "data": data,
        }
        for svc in services:
            domain, _, name = svc.partition(".") if "." in svc else ("notify", "", svc)
            try:
                await self.hass.services.async_call(domain, name, payload, blocking=False)
            except HomeAssistantError as err:
                _LOGGER.warning("%s: notify %s failed: %s", self.name, svc, err)

    # ------------------------------------------------------------ teaching
    def _trim_history(self) -> None:
        keep, count, out = int(self.opts[CONF_KEEP_EVENTS]), 0, []
        for rec in self.history:
            if rec.get("trained"):
                out.append(rec)
                continue
            count += 1
            if count <= keep:
                out.append(rec)
        self.history = out

    async def _crop_for(self, rec: dict[str, Any], obj: dict[str, Any], entity_id: str) -> None:
        """Save the object's bounding box from the event image as a reference photo for the entity."""
        training = self.rt.training
        if training is None or not obj.get("box"):
            return
        data = await self.hass.async_add_executor_job(self.read_image, rec["id"])
        if not data:
            return
        crop = await self.hass.async_add_executor_job(crop_image, data, obj["box"])
        if crop:
            await self.hass.async_add_executor_job(training.add_crop, entity_id, crop)

    async def async_name_object(self, rec: dict[str, Any], obj: dict[str, Any], name: str, notes: str = "") -> dict[str, Any]:
        """Say who or what an object is: creates or extends a known entity (with a reference photo)."""
        training = self.rt.training
        name = name.strip()
        if training is None:
            raise ValueError("Teaching store is not running")
        if not name:
            obj["identity"], obj["entity_id"] = "", ""
            return obj
        payload = {"name": name, "kind": obj.get("kind", "person"), "description": obj.get("description", "")}
        if notes:
            payload["notes"] = notes
        ent = await self.hass.async_add_executor_job(training.save_entity, payload, None)
        old_desc = obj.get("description", "")
        obj["identity"], obj["entity_id"] = ent["name"], ent["id"]
        obj.pop("guess", None)
        await self._crop_for(rec, obj, ent["id"])
        await self.hass.async_add_executor_job(training.close_questions_for, rec["id"], obj["id"], name)
        rec["_swap"] = rec.get("_swap", []) + [(old_desc, ent["name"])]
        return obj

    async def async_teach_event(self, event_id: str, patch: dict[str, Any]) -> dict[str, Any]:
        """Apply the owner's corrections to a logged analysis and remember them as lessons."""
        rec = self.event(event_id)
        if rec is None:
            raise ValueError("Event not found")
        training = self.rt.training
        if training is None:
            raise ValueError("Teaching store is not running")
        if "original" not in rec:
            rec["original"] = {
                "summary": rec.get("summary", ""), "answer": rec.get("answer", ""), "threat_level": rec.get("threat_level", "low"),
                "objects": copy.deepcopy(rec.get("objects", [])),
            }
        rec.pop("_swap", None)
        explicit_summary = False
        if isinstance(patch.get("summary"), str) and patch["summary"].strip():
            rec["summary"] = patch["summary"].strip()[:1000]
            explicit_summary = True
        if isinstance(patch.get("answer"), str):
            rec["answer"] = patch["answer"].strip()[:1000]
        if isinstance(patch.get("note"), str):
            rec["note"] = patch["note"].strip()[:1000]
        if patch.get("threat_level") in THREAT_LEVELS:
            rec["threat_level"] = patch["threat_level"]
            rec["threat_source"] = "taught"
        objects: list[dict[str, Any]] = rec.setdefault("objects", [])
        for change in patch.get("objects", []) or []:
            if not isinstance(change, dict):
                continue
            obj = next((o for o in objects if o.get("id") == change.get("id")), None) if change.get("id") else None
            if obj is None:
                if change.get("delete"):
                    continue
                obj = {"id": uuid.uuid4().hex[:10], "kind": "person", "description": "", "identity": "", "entity_id": "",
                       "confidence": 1.0, "box": None, "manual": True}
                objects.append(obj)
            if change.get("delete"):
                objects.remove(obj)
                continue
            if change.get("kind") in OBJECT_KINDS:
                obj["kind"] = change["kind"]
            if isinstance(change.get("description"), str):
                obj["description"] = change["description"].strip()[:300]
            if isinstance(change.get("box"), list) and len(change["box"]) == 4:
                try:
                    box = [max(0, min(1000, int(v))) for v in change["box"]]
                    if box[2] > box[0] + 9 and box[3] > box[1] + 9:
                        obj["box"] = box
                except (TypeError, ValueError):
                    pass
            if "identity" in change:
                await self.async_name_object(rec, obj, str(change.get("identity") or ""), str(change.get("notes") or ""))
            elif obj.get("entity_id") and change.get("box"):
                await self._crop_for(rec, obj, obj["entity_id"])
        if not explicit_summary:
            for old_desc, name in rec.pop("_swap", []):
                rec["summary"] = _swap_description(rec.get("summary", ""), old_desc, name)
                rec["answer"] = _swap_description(rec.get("answer", ""), old_desc, name)
            finish_summary(rec)
        rec.pop("_swap", None)

        if patch.get("remember_threat") and rec.get("threat_level") in THREAT_LEVELS:
            await self._remember_threat(rec)

        rec["trained"] = True
        rec["edited"] = dt_util.now().isoformat()
        orig = rec["original"]
        if rec.get("summary") != orig["summary"] or rec.get("threat_level") != orig["threat_level"] or rec.get("note"):
            await self.hass.async_add_executor_job(
                training.add_lesson,
                {
                    "event_id": rec["id"], "channel": rec["channel"], "camera": rec["camera"], "trigger": rec.get("trigger"),
                    "original_summary": orig["summary"], "taught_summary": rec.get("summary", ""),
                    "original_threat": orig["threat_level"], "taught_threat": rec.get("threat_level"),
                    "note": rec.get("note", ""),
                },
            )
        self._schedule_save()
        async_dispatcher_send(self.hass, self.signal_analysis, rec["channel"])
        async_dispatcher_send(self.hass, self.signal_questions)
        return rec

    async def _remember_threat(self, rec: dict[str, Any]) -> None:
        """Turn a corrected threat level into a standing decision: per known entity, and a rule for unknown subjects."""
        training = self.rt.training
        assert training is not None
        level = rec["threat_level"]
        unknown = False
        for obj in rec.get("objects", []):
            if obj.get("entity_id"):
                await self.hass.async_add_executor_job(training.save_entity, {"name": obj["identity"], "threat": level}, obj["entity_id"])
            elif obj.get("kind") in ("person", "vehicle", "animal"):
                unknown = True
        if unknown and not any(o.get("entity_id") for o in rec.get("objects", [])):
            rules = await self.hass.async_add_executor_job(training.rules)
            if not any(r.get("who") == "unknown" and r.get("channels") == [rec["channel"]] and r.get("level") == level
                       and not r.get("time_from") for r in rules):
                await self.hass.async_add_executor_job(
                    training.save_rule,
                    {"label": f"Taught on {rec['camera']}", "kind": "any", "who": "unknown", "channels": [rec["channel"]], "level": level},
                    None,
                )

    async def async_answer_question(self, question_id: str, answer: str) -> dict[str, Any]:
        training = self.rt.training
        if training is None:
            raise ValueError("Teaching store is not running")
        qs = await self.hass.async_add_executor_job(training.questions)
        q = qs.get(question_id)
        if q is None:
            raise ValueError("Question not found")
        rec = self.event(q["event_id"])
        name, full = _clean_name(answer)
        if not name:
            raise ValueError("Type who or what it is")
        if rec is None:
            await self.hass.async_add_executor_job(partial(training.update_question, question_id, status="answered", answer=full))
            raise ValueError("The event this question was about has been removed, so it was closed")
        obj = next((o for o in rec.get("objects", []) if o.get("id") == q["object_id"]), None)
        if obj is None:
            await self.hass.async_add_executor_job(partial(training.update_question, question_id, status="answered", answer=full))
            raise ValueError("That object was removed from the event, so the question was closed")
        notes = full if full.lower() != name.lower() else ""
        rec = await self.async_teach_event(
            rec["id"], {"objects": [{"id": obj["id"], "identity": name, "notes": notes}]}
        )
        await self.hass.async_add_executor_job(partial(training.update_question, question_id, status="answered", answer=full))
        return rec

    # ------------------------------------------------------------ persistence
    def _store_data(self) -> dict[str, Any]:
        def clean(rec: dict[str, Any]) -> dict[str, Any]:
            return {k: v for k, v in rec.items() if not k.startswith("_")}

        return {
            "history": [clean(r) for r in self.history],
            "detections": list(self.detections),
            "last_analysis": {str(k): clean(v) for k, v in self.last_analysis.items()},
        }

    @callback
    def _schedule_save(self) -> None:
        if self._store:
            self._store.async_delay_save(self._store_data, 15)

    # ------------------------------------------------------------ AI tool views
    async def async_summary(self) -> dict[str, Any]:
        training = self.rt.training
        open_q = known = 0
        if training is not None:
            qs = await self.hass.async_add_executor_job(training.questions)
            open_q = sum(1 for q in qs.values() if q["status"] == "open")
            known = len(await self.hass.async_add_executor_job(training.entities))
        cams = []
        for ch in self.channels.values():
            last = self.last_analysis.get(ch.id)
            cams.append(
                {
                    "channel": ch.id,
                    "name": ch.name,
                    "detections_active": {k: self.states.get(f"ch{ch.id}_{k}", False) for k in CHANNEL_KINDS},
                    "ai_analysis_enabled": self.channel_allowed(ch.id),
                    "last_analysis": {k: last.get(k) for k in ("id", "time", "trigger", "summary", "threat_level")} if last else None,
                }
            )
        alarm = None
        if entity := self.opts[CONF_ALARM_ENTITY]:
            state = self.hass.states.get(entity)
            alarm = {"entity_id": entity, "state": state.state if state else "unknown"}
        return {
            "dvr": self.name,
            "dvr_id": self.entry.entry_id,
            "model": self.device.model if self.device else None,
            "event_stream_connected": self.stream_connected,
            "alarm": alarm,
            "alarm_inputs": [{"port": p, "name": n, "active": self.states.get(f"io{p}", False)} for p, n in self.io_inputs.items()],
            "cameras": cams,
            "vision": {"model": (self._vision_ref().name if self._vision_ref() else "none set"), **self.vision_status},
            "known_entities": known,
            "open_questions": open_q,
        }

    def query_events(self, channel: int | None = None, limit: int = 20, since_hours: float | None = None, offset: int = 0) -> dict[str, Any]:
        limit = max(1, min(500, int(limit)))
        cutoff = dt_util.now().timestamp() - since_hours * 3600 if since_hours else None

        def keep(rec: dict[str, Any]) -> bool:
            if channel is not None and rec.get("channel") != channel:
                return False
            if cutoff is not None:
                parsed = dt_util.parse_datetime(rec.get("time", ""))
                if parsed is None or parsed.timestamp() < cutoff:
                    return False
            return True

        matching = [r for r in self.history if keep(r)]
        analyses = [public(r) for r in matching[offset : offset + limit]]
        detections = [d for d in self.detections if keep(d)][: min(limit, 100) * 3]
        return {"dvr": self.name, "total": len(matching), "analyses": analyses, "detections": detections}
