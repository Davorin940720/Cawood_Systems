"""Teaching store for the camera AI: known people/vehicles/animals, reference crops, rules, lessons and questions.

The vision model is not fine-tuned. Instead everything the owner teaches is kept on disk and fed back into every analysis
(names with reference photos, corrected descriptions and threat levels), and a rule engine applies the owner's threat
decisions after the model answers. All methods are synchronous; call them from an executor.
"""
from __future__ import annotations

import io
import json
import logging
import os
import re
import tempfile
import threading
import time
import uuid
from typing import Any

from .const import MAX_OPEN_QUESTIONS, OBJECT_KINDS, THREAT_LEVELS

_LOGGER = logging.getLogger(__name__)
_ARTICLES = re.compile(r"^(?:an?|the|one|unknown)\s+", re.I)
_WORDS = re.compile(r"[a-z0-9]+")
MAX_CROPS = 6
CROP_SIDE = 384


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _id() -> str:
    return uuid.uuid4().hex[:10]


def _words(text: str) -> set[str]:
    return {w for w in _WORDS.findall((text or "").lower()) if len(w) > 2 and w not in {"the", "and", "with", "wearing", "in", "a"}}


def similarity(a: str, b: str) -> float:
    wa, wb = _words(a), _words(b)
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / len(wa | wb)


def level_index(level: str | None) -> int:
    return THREAT_LEVELS.index(level) if level in THREAT_LEVELS else -1


def max_level(*levels: str | None) -> str | None:
    best = None
    for lv in levels:
        if level_index(lv) > level_index(best):
            best = lv
    return best


def question_text(kind: str, description: str) -> str:
    desc = _ARTICLES.sub("", (description or "").strip().rstrip("."))
    if desc and not desc[:2].isupper():
        desc = desc[0].lower() + desc[1:]
    desc = desc or {"person": "person", "vehicle": "vehicle", "animal": "animal"}.get(kind, "object")
    if kind == "person":
        return f"Who is the unknown {desc}?"
    if kind == "vehicle":
        return f"Who does the unknown {desc} belong to?"
    if kind == "animal":
        return f"Whose pet or what animal is the unknown {desc}?"
    return f"What is the unknown {desc}?"


def crop_image(data: bytes, box: list[int] | None, pad: float = 0.12, side: int = CROP_SIDE) -> bytes | None:
    """Crop a 0-1000 normalised box (with padding) out of a JPEG. Returns None without Pillow or a usable box."""
    if not box or len(box) != 4:
        return None
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel
    except ImportError:
        _LOGGER.debug("Pillow is not installed, reference crops are disabled")
        return None
    try:
        with Image.open(io.BytesIO(data)) as im:
            im = im.convert("RGB")
            w, h = im.size
            x1, y1, x2, y2 = box
            bw, bh = (x2 - x1) / 1000 * w, (y2 - y1) / 1000 * h
            left = max(0, int(x1 / 1000 * w - bw * pad))
            top = max(0, int(y1 / 1000 * h - bh * pad))
            right = min(w, int(x2 / 1000 * w + bw * pad))
            bottom = min(h, int(y2 / 1000 * h + bh * pad))
            if right - left < 8 or bottom - top < 8:
                return None
            part = im.crop((left, top, right, bottom))
            part.thumbnail((side, side))
            out = io.BytesIO()
            part.save(out, "JPEG", quality=88)
            return out.getvalue()
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Crop failed: %s", err)
        return None


def normalise_upload(data: bytes, side: int = CROP_SIDE) -> bytes | None:
    """Turn an uploaded photo (any common format) into a small JPEG reference picture. None without Pillow or if unreadable."""
    try:
        from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel
    except ImportError:
        return None
    try:
        with Image.open(io.BytesIO(data)) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((side, side))
            out = io.BytesIO()
            im.save(out, "JPEG", quality=88)
            return out.getvalue()
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Upload not usable: %s", err)
        return None


class TrainingStore:
    def __init__(self, folder: str) -> None:
        self.folder = folder
        self.crops = os.path.join(folder, "crops")
        self.lock = threading.RLock()
        os.makedirs(self.crops, exist_ok=True)

    # ------------------------------------------------------------ file helpers
    def _path(self, name: str) -> str:
        return os.path.join(self.folder, name)

    def _read(self, name: str, default: Any) -> Any:
        try:
            with open(self._path(name), encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            return default
        except (OSError, ValueError) as err:
            _LOGGER.warning("Could not read %s: %s", name, err)
            return default

    def _write(self, name: str, data: Any) -> None:
        fd, tmp = tempfile.mkstemp(dir=self.folder, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=1)
            os.replace(tmp, self._path(name))
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise

    # ------------------------------------------------------------ entities
    def entities(self) -> dict[str, dict]:
        return self._read("entities.json", {})

    def find_entity(self, name: str) -> dict | None:
        key = (name or "").strip().lower()
        if not key:
            return None
        for ent in self.entities().values():
            if ent["name"].lower() == key or key in [a.lower() for a in ent.get("aliases", [])]:
                return ent
        return None

    def save_entity(self, data: dict, entity_id: str | None = None) -> dict:
        """Create or update a known entity. A new name that matches an existing entity updates that one."""
        with self.lock:
            ents = self.entities()
            name = str(data.get("name") or "").strip()[:80]
            ent = ents.get(entity_id) if entity_id else None
            if ent is None and name:
                ent = next((e for e in ents.values() if e["name"].lower() == name.lower()
                            or name.lower() in [a.lower() for a in e.get("aliases", [])]), None)
            if ent is None:
                if not name:
                    raise ValueError("A name is required")
                ent = {"id": _id(), "name": name, "kind": "person", "description": "", "descriptions": [], "aliases": [],
                       "threat": "", "notes": "", "crops": [], "channels": {}, "seen_count": 0, "last_seen": "",
                       "created": _now()}
            if name:
                ent["name"] = name
            if data.get("kind") in OBJECT_KINDS:
                ent["kind"] = data["kind"]
            if "threat" in data:
                ent["threat"] = data["threat"] if data["threat"] in THREAT_LEVELS else ""
            if "notes" in data:
                ent["notes"] = str(data["notes"] or "")[:1000]
            if "aliases" in data:
                raw = data["aliases"] if isinstance(data["aliases"], list) else re.split(r"[,;\n]", str(data["aliases"] or ""))
                ent["aliases"] = [str(a).strip()[:80] for a in raw if str(a).strip()][:10]
            desc = str(data.get("description") or "").strip()[:300]
            if desc:
                if not ent["description"]:
                    ent["description"] = desc
                elif desc != ent["description"] and desc not in ent["descriptions"]:
                    ent["descriptions"] = ([desc] + ent["descriptions"])[:8]
                if data.get("replace_description"):
                    ent["description"] = desc
            ent["updated"] = _now()
            ents[ent["id"]] = ent
            self._write("entities.json", ents)
            return ent

    def delete_entity(self, entity_id: str) -> bool:
        with self.lock:
            ents = self.entities()
            ent = ents.pop(entity_id, None)
            if ent is None:
                return False
            for fn in ent.get("crops", []):
                self._remove_crop(fn)
            self._write("entities.json", ents)
            return True

    def note_seen(self, entity_id: str, channel: int | None) -> None:
        with self.lock:
            ents = self.entities()
            ent = ents.get(entity_id)
            if not ent:
                return
            ent["seen_count"] = ent.get("seen_count", 0) + 1
            ent["last_seen"] = _now()
            if channel is not None:
                ent.setdefault("channels", {})
                ent["channels"][str(channel)] = ent["channels"].get(str(channel), 0) + 1
            self._write("entities.json", ents)

    # ------------------------------------------------------------ crops
    def add_crop(self, entity_id: str, jpeg: bytes) -> str | None:
        with self.lock:
            ents = self.entities()
            ent = ents.get(entity_id)
            if not ent:
                return None
            fn = f"{entity_id}_{_id()}.jpg"
            with open(os.path.join(self.crops, fn), "wb") as fh:
                fh.write(jpeg)
            ent["crops"] = (ent.get("crops", []) + [fn])[-MAX_CROPS:]
            keep = set(ent["crops"])
            for old in [f for f in os.listdir(self.crops) if f.startswith(entity_id + "_") and f not in keep]:
                self._remove_crop(old)
            ent["updated"] = _now()
            self._write("entities.json", ents)
            return fn

    def _remove_crop(self, fn: str) -> None:
        try:
            os.remove(os.path.join(self.crops, os.path.basename(fn)))
        except OSError:
            pass

    def remove_crop(self, entity_id: str, fn: str) -> bool:
        with self.lock:
            ents = self.entities()
            ent = ents.get(entity_id)
            if not ent or fn not in ent.get("crops", []):
                return False
            ent["crops"].remove(fn)
            self._remove_crop(fn)
            self._write("entities.json", ents)
            return True

    def crop_path(self, fn: str) -> str | None:
        path = os.path.join(self.crops, os.path.basename(fn))
        return path if os.path.isfile(path) else None

    def read_crop(self, fn: str) -> bytes | None:
        path = self.crop_path(fn)
        if not path:
            return None
        with open(path, "rb") as fh:
            return fh.read()

    # ------------------------------------------------------------ rules
    def rules(self) -> list[dict]:
        return self._read("rules.json", [])

    def save_rule(self, data: dict, rule_id: str | None = None) -> dict:
        level = data.get("level")
        if level not in THREAT_LEVELS:
            raise ValueError("level must be none, low, medium or high")
        with self.lock:
            rules = self.rules()
            rule = next((r for r in rules if r["id"] == rule_id), None) if rule_id else None
            if rule is None:
                rule = {"id": _id(), "created": _now()}
                rules.append(rule)
            channels = data.get("channels", rule.get("channels", []))
            if isinstance(channels, str):
                channels = [int(x) for x in re.findall(r"\d+", channels)]
            rule.update(
                {
                    "label": str(data.get("label", rule.get("label", "")) or "")[:120],
                    "kind": data.get("kind", rule.get("kind", "any")) if data.get("kind", rule.get("kind", "any")) in ("any", "scene", *OBJECT_KINDS) else "any",
                    "who": str(data.get("who", rule.get("who", "any")) or "any")[:40],  # any | unknown | known | entity id
                    "channels": [int(c) for c in channels][:64],
                    "time_from": str(data.get("time_from", rule.get("time_from", "")) or "")[:5],
                    "time_to": str(data.get("time_to", rule.get("time_to", "")) or "")[:5],
                    "triggers": [str(t) for t in data.get("triggers", rule.get("triggers", []))][:10],
                    "level": level,
                    "enabled": bool(data.get("enabled", rule.get("enabled", True))),
                    "updated": _now(),
                }
            )
            self._write("rules.json", rules)
            return rule

    def delete_rule(self, rule_id: str) -> bool:
        with self.lock:
            rules = self.rules()
            new = [r for r in rules if r["id"] != rule_id]
            if len(new) == len(rules):
                return False
            self._write("rules.json", new)
            return True

    # ------------------------------------------------------------ lessons
    def lessons(self) -> list[dict]:
        return self._read("lessons.json", [])

    def add_lesson(self, lesson: dict) -> dict:
        with self.lock:
            items = self.lessons()
            lesson = {"id": _id(), "created": _now(), **lesson}
            items = [x for x in items if x.get("event_id") != lesson.get("event_id")]  # one lesson per event, latest wins
            items.insert(0, lesson)
            self._write("lessons.json", items[:400])
            return lesson

    def delete_lesson(self, lesson_id: str) -> bool:
        with self.lock:
            items = self.lessons()
            new = [x for x in items if x["id"] != lesson_id]
            if len(new) == len(items):
                return False
            self._write("lessons.json", new)
            return True

    # ------------------------------------------------------------ questions
    def questions(self) -> dict[str, dict]:
        return self._read("questions.json", {})

    def add_questions(self, event: dict) -> list[dict]:
        """Create a question for each unidentified object of an analysis, skipping near-duplicates of open ones."""
        created: list[dict] = []
        with self.lock:
            qs = self.questions()
            open_qs = [q for q in qs.values() if q["status"] == "open"]
            for obj in event.get("objects", []):
                if obj.get("identity") or obj.get("entity_id") or not (obj.get("description") or obj.get("kind")):
                    continue
                if len(open_qs) + len(created) >= MAX_OPEN_QUESTIONS:
                    break
                if any(q["channel"] == event.get("channel") and q["kind"] == obj["kind"]
                       and similarity(q["description"], obj.get("description", "")) >= 0.6 for q in open_qs + created):
                    continue
                q = {
                    "id": _id(), "status": "open", "created": event.get("time") or _now(),
                    "event_id": event["id"], "object_id": obj["id"], "channel": event.get("channel"),
                    "camera": event.get("camera"), "dvr_id": event.get("dvr_id"), "kind": obj["kind"],
                    "description": obj.get("description", ""), "text": question_text(obj["kind"], obj.get("description", "")),
                    "answer": "",
                }
                qs[q["id"]] = q
                created.append(q)
            if created:
                self._write("questions.json", qs)
        return created

    def update_question(self, question_id: str, **fields: Any) -> dict | None:
        with self.lock:
            qs = self.questions()
            q = qs.get(question_id)
            if not q:
                return None
            q.update(fields)
            self._write("questions.json", qs)
            return q

    def close_questions_for(self, event_id: str, object_id: str, answer: str) -> None:
        with self.lock:
            qs = self.questions()
            changed = False
            for q in qs.values():
                if q["event_id"] == event_id and q["object_id"] == object_id and q["status"] == "open":
                    q.update(status="answered", answer=answer, answered=_now())
                    changed = True
            if changed:
                self._write("questions.json", qs)

    def delete_question(self, question_id: str) -> bool:
        with self.lock:
            qs = self.questions()
            if qs.pop(question_id, None) is None:
                return False
            self._write("questions.json", qs)
            return True

    # ------------------------------------------------------------ prompt
    def training_block(self, channel: int, max_refs: int, rules_text: bool = True) -> tuple[str, list[tuple[str, bytes]]]:
        """Text for the vision prompt and the reference crops to send before the live frames."""
        ents = list(self.entities().values())
        lines: list[str] = []
        refs: list[tuple[str, bytes]] = []
        if ents:
            def rank(e: dict) -> tuple:
                return (-(e.get("channels", {}).get(str(channel), 0) > 0), -e.get("seen_count", 0), e.get("name", ""))

            ents.sort(key=rank)
            lines.append("KNOWN list. When you recognise one of these, use its exact name in the summary, the answer and the object identity:")
            for e in ents[:40]:
                bits = [f'- {e["name"]} ({e["kind"]})']
                if e.get("description"):
                    bits.append(f': {e["description"]}')
                for alt in e.get("descriptions", [])[:2]:
                    bits.append(f'; also seen as {alt}')
                if e.get("aliases"):
                    bits.append(f'; also called {", ".join(e["aliases"])}')
                if e.get("threat"):
                    bits.append(f'; owner treats this as threat "{e["threat"]}"')
                if e.get("notes"):
                    bits.append(f'; note: {e["notes"][:200]}')
                lines.append("".join(bits))
            for e in ents:
                if len(refs) >= max(0, max_refs):
                    break
                if e.get("crops"):
                    data = self.read_crop(e["crops"][-1])
                    if data:
                        refs.append((e["name"], data))
            if refs:
                order = "; ".join(f"image {i + 1} is {n}" for i, (n, _d) in enumerate(refs))
                lines.append(f"The first {len(refs)} image(s) are reference photos only ({order}). They are not part of the live scene. The remaining images are the live camera frames.")
        lessons = [x for x in self.lessons() if x.get("taught_summary") or x.get("taught_threat")]
        same = [x for x in lessons if x.get("channel") == channel][:10]
        other = [x for x in lessons if x.get("channel") != channel][:4]
        picks = same + other
        if picks:
            lines.append("Corrections the owner taught you (apply them to the same people, objects and situations):")
            for x in picks:
                part = []
                if x.get("original_summary") and x.get("taught_summary") and x["original_summary"] != x["taught_summary"]:
                    part.append(f'when you described it as "{x["original_summary"][:240]}" the correct description is "{x["taught_summary"][:300]}"')
                elif x.get("taught_summary"):
                    part.append(f'correct description: "{x["taught_summary"][:300]}"')
                if x.get("taught_threat") and x.get("taught_threat") != x.get("original_threat"):
                    part.append(f'threat level should be {x["taught_threat"]} (you said {x.get("original_threat", "?")})')
                if x.get("note"):
                    part.append(f'note: {x["note"][:200]}')
                if part:
                    lines.append(f'- {x.get("camera") or "camera"}: ' + "; ".join(part))
        if rules_text:
            rules = [r for r in self.rules() if r.get("enabled", True) and (not r.get("channels") or channel in r["channels"])]
            if rules:
                lines.append("Owner threat rules (the system also enforces them after your answer):")
                ent_names = {e["id"]: e["name"] for e in ents}
                for r in rules[:20]:
                    lines.append("- " + describe_rule(r, ent_names))
        return "\n".join(lines), refs


# ---------------------------------------------------------------- rule engine
def describe_rule(rule: dict, ent_names: dict[str, str] | None = None) -> str:
    who = rule.get("who", "any")
    who_txt = {"any": "anyone", "unknown": "an unknown", "known": "a recognised"}.get(who) or (ent_names or {}).get(who, who)
    kind = rule.get("kind", "any")
    subj = {"any": "person, vehicle or animal", "scene": "any activity"}.get(kind, kind)
    text = f'{who_txt} {subj}' if kind != "scene" else "any activity"
    when = ""
    if rule.get("time_from") and rule.get("time_to"):
        when = f' between {rule["time_from"]} and {rule["time_to"]}'
    if rule.get("channels"):
        when += f' on channel {", ".join(str(c) for c in rule["channels"])}'
    if rule.get("triggers"):
        when += f' when triggered by {", ".join(t.replace("_", " ") for t in rule["triggers"])}'
    label = f' ({rule["label"]})' if rule.get("label") else ""
    return f'{text}{when} = threat {rule["level"]}{label}'


def _minutes(text: str) -> int | None:
    m = re.match(r"^(\d{1,2}):(\d{2})$", text or "")
    return int(m.group(1)) * 60 + int(m.group(2)) if m else None


def _in_window(rule: dict, now_minutes: int) -> bool:
    a, b = _minutes(rule.get("time_from", "")), _minutes(rule.get("time_to", ""))
    if a is None or b is None:
        return True
    return a <= now_minutes < b if a <= b else (now_minutes >= a or now_minutes < b)


def _rule_applies(rule: dict, rec: dict, now_minutes: int) -> bool:
    if not rule.get("enabled", True):
        return False
    if rule.get("channels") and rec.get("channel") not in rule["channels"]:
        return False
    if rule.get("triggers") and rec.get("trigger") not in rule["triggers"]:
        return False
    return _in_window(rule, now_minutes)


def _rule_matches_object(rule: dict, obj: dict) -> bool:
    if rule.get("kind") == "scene":
        return False
    if rule.get("kind", "any") not in ("any", obj.get("kind")):
        return False
    who = rule.get("who", "any")
    if who == "any":
        return True
    if who == "unknown":
        return not obj.get("entity_id")
    if who == "known":
        return bool(obj.get("entity_id"))
    return obj.get("entity_id") == who


def resolve_identities(rec: dict, entities: dict[str, dict], min_confidence: float) -> None:
    """Give each object an id and match its identity to a known entity. Unrecognised names become a guess, not an identity."""
    by_name: dict[str, dict] = {}
    for e in entities.values():
        by_name[e["name"].lower()] = e
        for a in e.get("aliases", []):
            by_name[a.lower()] = e
    for obj in rec.get("objects", []):
        obj.setdefault("id", _id())
        said = (obj.get("identity") or "").strip()
        obj["entity_id"] = ""
        obj["identity"] = ""
        if not said:
            continue
        ent = by_name.get(said.lower())
        if ent and obj.get("confidence", 0) >= min_confidence:
            obj["entity_id"], obj["identity"] = ent["id"], ent["name"]
        else:
            obj["guess"] = said


def apply_threat(rec: dict, rules: list[dict], entities: dict[str, dict], now_minutes: int, floor: str) -> None:
    """Final threat level: the owner's rules and per-entity threat beat the model; unknown subjects never rate below the floor."""
    model_level = rec.get("threat_level", "low")
    rec["model_threat_level"] = model_level
    live = [r for r in rules if _rule_applies(r, rec, now_minutes)]
    objects = rec.get("objects", [])
    levels: list[str | None] = []
    source = "model"
    for obj in objects:
        lv = None
        for r in live:
            if _rule_matches_object(r, obj):
                lv = max_level(lv, r["level"])
                obj["rule"] = r["id"]
        ent = entities.get(obj.get("entity_id", ""))
        if ent and ent.get("threat"):
            lv = max_level(lv, ent["threat"])
            obj["rule"] = obj.get("rule") or f"entity:{ent['id']}"
        obj["threat_level"] = lv or ""
        levels.append(lv)
    scene = [r for r in live if r.get("kind") == "scene"]
    final = model_level
    if objects and all(lv is not None for lv in levels):
        final = max_level(*levels) or model_level
        source = "rules"
    elif any(lv is not None for lv in levels):
        final = max_level(model_level, *levels) or model_level
        if final != model_level:
            source = "rules"
    for r in scene:
        raised = max_level(final, r["level"])
        if raised != final:
            final, source = raised, "rules"
    unknown = [o for o in objects if not o.get("entity_id") and o.get("kind") in ("person", "vehicle", "animal")]
    if unknown and level_index(final) < level_index(floor):
        final, source = floor, "floor"
    rec["threat_level"] = final
    rec["threat_source"] = source


def finish_summary(rec: dict) -> None:
    """Make sure the recognised names appear in the text the user reads."""
    names = [o["identity"] for o in rec.get("objects", []) if o.get("identity")]
    text = f'{rec.get("summary", "")} {rec.get("answer", "")}'.lower()
    missing = [n for n in dict.fromkeys(names) if n.lower() not in text]
    if missing:
        rec["summary"] = f'{rec.get("summary", "").rstrip(". ")}. Recognised: {", ".join(missing)}.'
