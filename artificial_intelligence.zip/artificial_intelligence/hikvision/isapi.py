"""Hikvision ISAPI client. No Home Assistant imports so it can be tested standalone."""
from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
import logging
from urllib.parse import quote
import xml.etree.ElementTree as ET

import httpx

from .const import EVENT_TYPE_MAP

_LOGGER = logging.getLogger(__name__)

ALERT_STREAM_PATH = "/ISAPI/Event/notification/alertStream"


class IsapiError(Exception):
    """General ISAPI failure."""


class IsapiAuthError(IsapiError):
    """Credentials rejected."""


@dataclass
class DeviceInfo:
    name: str
    model: str
    serial: str
    firmware: str
    mac: str
    device_type: str


@dataclass
class Channel:
    id: int
    name: str
    stream_id: int


@dataclass
class HikEvent:
    event_type: str
    kind: str | None
    state: str
    channel: int | None
    io_port: int | None
    description: str
    timestamp: str | None
    raw: dict[str, str] = field(default_factory=dict)

    @property
    def is_heartbeat(self) -> bool:
        """Hikvision sends 'videoloss inactive' every ~10s as a keep-alive."""
        return self.event_type == "videoloss" and self.state == "inactive"


# ---------------------------------------------------------------- parsing

def _strip_ns(root: ET.Element) -> ET.Element:
    for el in root.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def parse_xml(data: str | bytes) -> ET.Element:
    try:
        return _strip_ns(ET.fromstring(data))
    except ET.ParseError as err:
        raise IsapiError(f"Invalid XML from device: {err}") from err


def _child(el: ET.Element, tag: str) -> str | None:
    found = el.find(tag)
    if found is not None and found.text and found.text.strip():
        return found.text.strip()
    return None


def _int(value: str | None) -> int | None:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def parse_device_info(data: str | bytes) -> DeviceInfo:
    root = parse_xml(data)
    if root.tag != "DeviceInfo":
        raise IsapiError(f"Unexpected deviceInfo response root <{root.tag}>")
    return DeviceInfo(
        name=_child(root, "deviceName") or "Hikvision",
        model=_child(root, "model") or "Unknown",
        serial=_child(root, "serialNumber") or _child(root, "deviceID") or "",
        firmware=_child(root, "firmwareVersion") or "",
        mac=_child(root, "macAddress") or "",
        device_type=_child(root, "deviceType") or "",
    )


def parse_streaming_channels(data: str | bytes) -> list[Channel]:
    """Main streams end in 01 (101, 201, 3301...). Channel = id // 100."""
    root = parse_xml(data)
    chans: dict[int, Channel] = {}
    for sc in root.iter("StreamingChannel"):
        sid = _int(_child(sc, "id"))
        if sid is None or sid % 100 != 1:
            continue
        if (_child(sc, "enabled") or "true").lower() == "false":
            continue
        ch = sid // 100
        chans.setdefault(ch, Channel(ch, _child(sc, "channelName") or f"Camera {ch}", sid))
    return sorted(chans.values(), key=lambda c: c.id)


def parse_io_inputs(data: str | bytes) -> list[tuple[int, str]]:
    root = parse_xml(data)
    out: list[tuple[int, str]] = []
    for port in root.iter("IOInputPort"):
        pid = _int(_child(port, "id"))
        if pid is not None:
            out.append((pid, _child(port, "name") or f"Alarm input {pid}"))
    return out


def parse_event(data: str | bytes) -> HikEvent | None:
    root = parse_xml(data)
    if root.tag != "EventNotificationAlert":
        return None
    raw = {
        c.tag: c.text.strip()
        for c in root
        if isinstance(c.tag, str) and c.text and c.text.strip()
    }
    etype = (raw.get("eventType") or "").lower()
    channel = _int(raw.get("dynChannelID")) or _int(raw.get("channelID"))
    io_port = _int(raw.get("dynInputIOPortID")) or _int(raw.get("inputIOPortID"))
    return HikEvent(
        event_type=etype,
        kind=EVENT_TYPE_MAP.get(etype),
        state=(raw.get("eventState") or "active").lower(),
        channel=channel or None,
        io_port=io_port or None,
        description=raw.get("eventDescription", ""),
        timestamp=raw.get("dateTime"),
        raw=raw,
    )


_START = b"<EventNotificationAlert"
_END = b"</EventNotificationAlert>"


class AlertStreamParser:
    """Pulls EventNotificationAlert XML blocks out of the multipart alert stream.

    Works on bytes and ignores everything else (boundaries, headers, JPEG parts).
    """

    def __init__(self, max_buffer: int = 2_000_000) -> None:
        self._buf = bytearray()
        self._max = max_buffer

    def feed(self, data: bytes) -> list[HikEvent]:
        self._buf += data
        events: list[HikEvent] = []
        while True:
            start = self._buf.find(_START)
            if start == -1:
                keep = len(_START)
                if len(self._buf) > keep:
                    del self._buf[:-keep]
                break
            end = self._buf.find(_END, start)
            if end == -1:
                if start:
                    del self._buf[:start]
                if len(self._buf) > self._max:
                    _LOGGER.debug("Alert stream buffer overflow, discarding")
                    self._buf.clear()
                break
            end += len(_END)
            block = bytes(self._buf[start:end])
            del self._buf[:end]
            try:
                ev = parse_event(block)
            except IsapiError as err:
                _LOGGER.debug("Skipping unparsable event: %s", err)
                continue
            if ev is not None:
                events.append(ev)
        return events


# ---------------------------------------------------------------- client

class IsapiClient:
    def __init__(
        self,
        client: httpx.AsyncClient,
        host: str,
        port: int,
        username: str,
        password: str,
        use_ssl: bool = False,
        auth_type: str = "digest",
    ) -> None:
        self._client = client
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.base = f"{'https' if use_ssl else 'http'}://{host}:{port}"
        self.auth_type = auth_type

    def _auth(self) -> httpx.Auth:
        if self.auth_type == "basic":
            return httpx.BasicAuth(self.username, self.password)
        return httpx.DigestAuth(self.username, self.password)

    async def _get(self, path: str, timeout: float = 10.0) -> httpx.Response:
        try:
            resp = await self._client.get(self.base + path, auth=self._auth(), timeout=timeout)
        except httpx.HTTPError as err:
            raise IsapiError(f"{path}: {err!r}") from err
        if resp.status_code in (401, 403):
            raise IsapiAuthError(f"{path}: HTTP {resp.status_code} (credentials or permissions)")
        if resp.status_code >= 400:
            raise IsapiError(f"{path}: HTTP {resp.status_code}")
        return resp

    async def detect_auth(self) -> DeviceInfo:
        """Read the auth challenge without sending credentials, so no failed login is counted."""
        try:
            resp = await self._client.get(self.base + "/ISAPI/System/deviceInfo", timeout=10.0)
        except httpx.HTTPError as err:
            raise IsapiError(f"Cannot reach {self.base}: {err!r}") from err
        challenge = resp.headers.get("www-authenticate", "").lower()
        self.auth_type = "basic" if ("basic" in challenge and "digest" not in challenge) else "digest"
        return await self.device_info()

    async def device_info(self) -> DeviceInfo:
        return parse_device_info((await self._get("/ISAPI/System/deviceInfo")).content)

    async def streaming_channels(self) -> list[Channel]:
        return parse_streaming_channels((await self._get("/ISAPI/Streaming/channels")).content)

    async def io_inputs(self) -> list[tuple[int, str]]:
        return parse_io_inputs((await self._get("/ISAPI/System/IO/inputs")).content)

    async def snapshot(self, stream_id: int) -> bytes:
        resp = await self._get(f"/ISAPI/Streaming/channels/{stream_id}/picture", timeout=15.0)
        data = resp.content
        if not data.startswith(b"\xff\xd8"):
            ctype = resp.headers.get("content-type", "")
            if "image" not in ctype:
                raise IsapiError(f"Stream {stream_id} returned no image (camera offline or no signal)")
        return data

    def rtsp_url(self, stream_id: int, rtsp_port: int = 554) -> str:
        user = quote(self.username, safe="")
        pwd = quote(self.password, safe="")
        return f"rtsp://{user}:{pwd}@{self.host}:{rtsp_port}/Streaming/Channels/{stream_id}"

    async def alert_stream(
        self, on_connect: Callable[[], None] | None = None
    ) -> AsyncIterator[HikEvent]:
        parser = AlertStreamParser()
        timeout = httpx.Timeout(10.0, read=90.0)
        try:
            async with self._client.stream(
                "GET", self.base + ALERT_STREAM_PATH, auth=self._auth(), timeout=timeout
            ) as resp:
                if resp.status_code in (401, 403):
                    raise IsapiAuthError(f"Alert stream: HTTP {resp.status_code}")
                if resp.status_code >= 400:
                    raise IsapiError(f"Alert stream: HTTP {resp.status_code}")
                if on_connect:
                    on_connect()
                async for chunk in resp.aiter_bytes():
                    for ev in parser.feed(chunk):
                        yield ev
        except httpx.HTTPError as err:
            raise IsapiError(f"Alert stream: {err!r}") from err
