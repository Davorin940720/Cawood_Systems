"""HTTP API for the camera tools, cai_hik_config.html and ai-cloud.html. One prefix: /api/artificial_intelligence/hikvision."""
from __future__ import annotations

import base64
import logging
from functools import partial
from typing import Any

from aiohttp import web

from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr, entity_registry as er

from ..authz import AuthedView
from ..const import API, DOMAIN
from ..runtime import Runtime
from .const import (
    CONF_ALARM_ENTITY,
    CONF_ANALYSE_EVENTS,
    CONF_ANALYSIS_CHANNELS,
    CONF_ASK_QUESTIONS,
    CONF_COOLDOWN,
    CONF_FRAME_INTERVAL,
    CONF_FRAMES,
    CONF_IDENTITY_CONFIDENCE,
    CONF_KEEP_EVENTS,
    CONF_KEEP_IMAGES,
    CONF_MAX_REFERENCES,
    CONF_MOTION_TIMEOUT,
    CONF_VISION_AGENT,
    CONF_NOTIFY_MIN_THREAT,
    CONF_NOTIFY_SERVICES,
    CONF_ONLY_WHEN_ARMED,
    CONF_PROMPT,
    CONF_THREAT_FLOOR,
    DEFAULT_OPTIONS,
    DEFAULT_PROMPT,
    OBJECT_KINDS,
    THREAT_LEVELS,
)
from .hub import CaiHikvisionHub, find_event, get_hub, public
from .isapi import IsapiError
from .training import crop_image, normalise_upload
from .vision import VisionError

_LOGGER = logging.getLogger(__name__)
HIK = API + "/hikvision"


class HError(Exception):
    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


class _HBase(AuthedView):
    async def body(self, request: web.Request) -> dict:
        try:
            data = await request.json()
        except (ValueError, UnicodeDecodeError):
            raise HError("Request body must be JSON") from None
        if not isinstance(data, dict):
            raise HError("Request body must be a JSON object")
        return data

    def hub(self, dvr: str | None = None) -> CaiHikvisionHub:
        try:
            return get_hub(self.rt, dvr)
        except LookupError as err:
            raise HError(str(err), 404) from err

    def store(self):
        if self.rt.training is None:
            raise HError("The teaching store is not running", 503)
        return self.rt.training

    def event(self, event_id: str) -> tuple[CaiHikvisionHub, dict[str, Any]]:
        found = find_event(self.rt, event_id)
        if found is None:
            raise HError("Event not found. It may have expired.", 404)
        return found

    async def guard(self, coro):
        try:
            result = await coro
        except HError as err:
            return self.json({"error": str(err)}, status_code=err.status)
        except ValueError as err:
            return self.json({"error": str(err)}, status_code=400)
        except (IsapiError, VisionError) as err:
            return self.json({"error": str(err)}, status_code=502)
        except Exception as err:  # noqa: BLE001
            _LOGGER.exception("Hikvision request failed")
            return self.json({"error": f"Server error: {err}"}, status_code=500)
        if isinstance(result, web.StreamResponse):
            return result
        return self.json(result)


def _int(value: Any, name: str) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        raise HError(f"'{name}' must be a number") from None


# ---------------------------------------------------------------- overview
class OverviewView(_HBase):
    url = HIK + "/overview"
    name = f"api:{DOMAIN}:h_overview"

    async def get(self, request):
        async def go():
            out = []
            dev_reg, ent_reg = dr.async_get(self.hass), er.async_get(self.hass)
            for hub in self.rt.hubs.values():
                summary = await hub.async_summary()
                devices = [
                    {"id": d.id, "name": d.name_by_user or d.name, "model": d.model, "manufacturer": d.manufacturer,
                     "serial": d.serial_number, "sw_version": d.sw_version, "via_device_id": d.via_device_id}
                    for d in dr.async_entries_for_config_entry(dev_reg, hub.entry.entry_id)
                ]
                entities = []
                for e in er.async_entries_for_config_entry(ent_reg, hub.entry.entry_id):
                    st = self.hass.states.get(e.entity_id)
                    entities.append(
                        {"entity_id": e.entity_id, "name": e.name or e.original_name, "domain": e.domain, "device_id": e.device_id,
                         "disabled": bool(e.disabled_by), "state": st.state if st else None,
                         "device_class": e.device_class or e.original_device_class, "unique_id": e.unique_id}
                    )
                out.append(
                    {**summary, "uid": hub.uid, "devices": devices, "entities": entities,
                     "channels": [{"channel": c.id, "name": c.name, "stream_id": c.stream_id} for c in hub.channels.values()],
                     "counts": {"events": len(hub.history), "detections": len(hub.detections),
                                "trained": sum(1 for r in hub.history if r.get("trained"))}}
                )
            return {"dvrs": out, "threat_levels": THREAT_LEVELS, "object_kinds": OBJECT_KINDS}
        return await self.guard(go())


class CamerasView(_HBase):
    url = HIK + "/cameras"
    name = f"api:{DOMAIN}:h_cameras"

    async def get(self, request):
        async def go():
            dvr = request.query.get("dvr")
            hubs = [self.hub(dvr)] if dvr else list(self.rt.hubs.values())
            if not hubs:
                self.hub()  # raises the helpful message
            return {"dvrs": [await h.async_summary() for h in hubs]}
        return await self.guard(go())


class SnapshotView(_HBase):
    url = HIK + "/snapshot/{channel}"
    name = f"api:{DOMAIN}:h_snapshot"

    async def get(self, request, channel):
        async def go():
            hub = self.hub(request.query.get("dvr"))
            ch = hub.resolve_channel(_int(channel, "channel"))
            image = await hub.async_snapshot(ch)
            if request.query.get("format") == "base64":
                return {"dvr": hub.name, "channel": ch, "camera": hub.channels[ch].name, "mime": "image/jpeg",
                        "base64": base64.b64encode(image).decode("ascii")}
            return web.Response(body=image, content_type="image/jpeg", headers={"Cache-Control": "no-store"})
        return await self.guard(go())


class AnalyzeView(_HBase):
    url = HIK + "/analyze"
    name = f"api:{DOMAIN}:h_analyze"

    async def post(self, request):
        async def go():
            body = await self.body(request)
            hub = self.hub(body.get("dvr"))
            if body.get("channel") in (None, ""):
                raise HError("'channel' is required")
            channel = hub.resolve_channel(_int(body["channel"], "channel"))
            frames = _int(body["frames"], "frames") if body.get("frames") else None
            rec = await hub.async_analyse(channel, question=(body.get("question") or None), trigger="ai_request",
                                          frames=frames, notify=bool(body.get("notify", False)))
            return public(rec)
        return await self.guard(go())


class EventsView(_HBase):
    url = HIK + "/events"
    name = f"api:{DOMAIN}:h_events"

    async def get(self, request):
        async def go():
            q = request.query
            hub = self.hub(q.get("dvr"))
            channel = hub.resolve_channel(q["channel"]) if q.get("channel") else None
            try:
                limit, offset = int(q.get("limit") or 20), int(q.get("offset") or 0)
                since = float(q["since_hours"]) if q.get("since_hours") else None
            except ValueError as err:
                raise HError(str(err)) from err
            out = hub.query_events(channel, limit, since, offset)
            only = q.get("filter")
            if only in ("trained", "untrained", "questions"):
                rows = out["analyses"]
                if only == "trained":
                    rows = [r for r in rows if r.get("trained")]
                elif only == "untrained":
                    rows = [r for r in rows if not r.get("trained")]
                else:
                    rows = [r for r in rows if r.get("question_ids")]
                out["analyses"] = rows
            return out
        return await self.guard(go())


class EventView(_HBase):
    url = HIK + "/events/{event_id}"
    name = f"api:{DOMAIN}:h_event"

    async def get(self, request, event_id):
        async def go():
            _hub, rec = self.event(event_id)
            return public(rec)
        return await self.guard(go())

    async def put(self, request, event_id):
        async def go():
            hub, _rec = self.event(event_id)
            return public(await hub.async_teach_event(event_id, await self.body(request)))
        return await self.guard(go())

    async def delete(self, request, event_id):
        async def go():
            hub, rec = self.event(event_id)
            hub.history.remove(rec)
            for ch, last in list(hub.last_analysis.items()):
                if last is rec:
                    del hub.last_analysis[ch]
                    nxt = next((r for r in hub.history if r.get("channel") == ch), None)
                    if nxt:
                        hub.last_analysis[ch] = nxt
            hub._schedule_save()  # noqa: SLF001
            return {"ok": True}
        return await self.guard(go())


class EventImageView(_HBase):
    url = HIK + "/events/{event_id}/image"
    name = f"api:{DOMAIN}:h_event_image"

    async def get(self, request, event_id):
        async def go():
            hub, _rec = self.event(event_id)
            object_id = request.query.get("object")
            if object_id:
                data = await self.hass.async_add_executor_job(hub.read_image, event_id)
                obj = next((o for o in _rec.get("objects", []) if o.get("id") == object_id), None)
                if not data or not obj or not obj.get("box"):
                    raise HError("No picture for that object", 404)
                crop = await self.hass.async_add_executor_job(crop_image, data, obj["box"], 0.08, 256)
                if not crop:
                    raise HError("Cropping needs Pillow, which is not installed", 501)
                return web.Response(body=crop, content_type="image/jpeg", headers={"Cache-Control": "private, max-age=3600"})
            path = await self.hass.async_add_executor_job(hub.image_path, event_id)
            if not path:
                raise HError("Image not found (expired or never saved)", 404)
            return web.FileResponse(path, headers={"Cache-Control": "private, max-age=86400"})
        return await self.guard(go())


class ReplayView(_HBase):
    url = HIK + "/events/{event_id}/replay"
    name = f"api:{DOMAIN}:h_event_replay"

    async def post(self, request, event_id):
        async def go():
            hub, _rec = self.event(event_id)
            return await hub.async_replay(event_id)
        return await self.guard(go())


# ---------------------------------------------------------------- known entities
class EntitiesView(_HBase):
    url = HIK + "/entities"
    name = f"api:{DOMAIN}:h_entities"

    async def get(self, request):
        async def go():
            ents = await self.hass.async_add_executor_job(self.store().entities)
            return {"entities": sorted(ents.values(), key=lambda e: e["name"].lower())}
        return await self.guard(go())

    async def post(self, request):
        async def go():
            body = await self.body(request)
            try:
                ent = await self.hass.async_add_executor_job(self.store().save_entity, body, None)
            except ValueError as err:
                raise HError(str(err)) from err
            return {"entity": ent}
        return await self.guard(go())


class EntityView(_HBase):
    url = HIK + "/entities/{entity_id}"
    name = f"api:{DOMAIN}:h_entity"

    async def put(self, request, entity_id):
        async def go():
            ents = await self.hass.async_add_executor_job(self.store().entities)
            if entity_id not in ents:
                raise HError("Unknown entity", 404)
            body = await self.body(request)
            body["replace_description"] = True
            ent = await self.hass.async_add_executor_job(self.store().save_entity, body, entity_id)
            return {"entity": ent}
        return await self.guard(go())

    async def delete(self, request, entity_id):
        async def go():
            if not await self.hass.async_add_executor_job(self.store().delete_entity, entity_id):
                raise HError("Unknown entity", 404)
            return {"ok": True}
        return await self.guard(go())


class EntityCropsView(_HBase):
    url = HIK + "/entities/{entity_id}/crops"
    name = f"api:{DOMAIN}:h_entity_crops"

    async def post(self, request, entity_id):
        """Add a reference photo: an uploaded image (Content-Type image/*), or from an event: {event_id, object_id} or {event_id, box}."""
        async def go():
            if (request.content_type or "").startswith("image/"):
                data = await request.read()
                if len(data) > 12_000_000:
                    raise HError("That photo is too large (12 MB maximum)", 413)
                photo = await self.hass.async_add_executor_job(normalise_upload, data)
                if not photo:
                    raise HError("Could not read that photo. Use a JPEG or PNG, and make sure Pillow is installed", 400)
                fn = await self.hass.async_add_executor_job(self.store().add_crop, entity_id, photo)
                if not fn:
                    raise HError("Unknown entity", 404)
                return {"file": fn}
            body = await self.body(request)
            hub, rec = self.event(str(body.get("event_id") or ""))
            box = body.get("box")
            if not box and body.get("object_id"):
                obj = next((o for o in rec.get("objects", []) if o.get("id") == body["object_id"]), None)
                box = obj.get("box") if obj else None
            if not isinstance(box, list) or len(box) != 4:
                raise HError("Give an object with a box, or a box of four numbers 0-1000")
            data = await self.hass.async_add_executor_job(hub.read_image, rec["id"])
            if not data:
                raise HError("The image for that event is gone", 404)
            crop = await self.hass.async_add_executor_job(crop_image, data, [int(v) for v in box])
            if not crop:
                raise HError("Could not crop. Pillow may be missing, or the box is too small", 501)
            fn = await self.hass.async_add_executor_job(self.store().add_crop, entity_id, crop)
            if not fn:
                raise HError("Unknown entity", 404)
            return {"file": fn}
        return await self.guard(go())


class EntityCropView(_HBase):
    url = HIK + "/entities/{entity_id}/crops/{file}"
    name = f"api:{DOMAIN}:h_entity_crop"

    async def get(self, request, entity_id, file):
        async def go():
            path = await self.hass.async_add_executor_job(self.store().crop_path, file)
            if not path or not file.startswith(entity_id + "_"):
                raise HError("Not found", 404)
            return web.FileResponse(path, headers={"Cache-Control": "private, max-age=3600"})
        return await self.guard(go())

    async def delete(self, request, entity_id, file):
        async def go():
            if not await self.hass.async_add_executor_job(self.store().remove_crop, entity_id, file):
                raise HError("Not found", 404)
            return {"ok": True}
        return await self.guard(go())


# ---------------------------------------------------------------- rules, lessons, questions
class RulesView(_HBase):
    url = HIK + "/rules"
    name = f"api:{DOMAIN}:h_rules"

    async def get(self, request):
        async def go():
            return {"rules": await self.hass.async_add_executor_job(self.store().rules)}
        return await self.guard(go())

    async def post(self, request):
        async def go():
            return {"rule": await self.hass.async_add_executor_job(self.store().save_rule, await self.body(request), None)}
        return await self.guard(go())


class RuleView(_HBase):
    url = HIK + "/rules/{rule_id}"
    name = f"api:{DOMAIN}:h_rule"

    async def put(self, request, rule_id):
        async def go():
            return {"rule": await self.hass.async_add_executor_job(self.store().save_rule, await self.body(request), rule_id)}
        return await self.guard(go())

    async def delete(self, request, rule_id):
        async def go():
            if not await self.hass.async_add_executor_job(self.store().delete_rule, rule_id):
                raise HError("Unknown rule", 404)
            return {"ok": True}
        return await self.guard(go())


class LessonsView(_HBase):
    url = HIK + "/lessons"
    name = f"api:{DOMAIN}:h_lessons"

    async def get(self, request):
        async def go():
            items = await self.hass.async_add_executor_job(self.store().lessons)
            ch = request.query.get("channel")
            if ch:
                items = [x for x in items if str(x.get("channel")) == ch]
            return {"lessons": items[: int(request.query.get("limit") or 200)]}
        return await self.guard(go())


class LessonView(_HBase):
    url = HIK + "/lessons/{lesson_id}"
    name = f"api:{DOMAIN}:h_lesson"

    async def delete(self, request, lesson_id):
        async def go():
            if not await self.hass.async_add_executor_job(self.store().delete_lesson, lesson_id):
                raise HError("Unknown lesson", 404)
            return {"ok": True}
        return await self.guard(go())


class QuestionsView(_HBase):
    url = HIK + "/questions"
    name = f"api:{DOMAIN}:h_questions"

    async def get(self, request):
        async def go():
            qs = list((await self.hass.async_add_executor_job(self.store().questions)).values())
            status = request.query.get("status", "open")
            if status != "all":
                qs = [q for q in qs if q["status"] == status]
            ch = request.query.get("channel")
            if ch:
                hub = self.hub(request.query.get("dvr"))
                n = hub.resolve_channel(ch)
                qs = [q for q in qs if q.get("channel") == n]
            qs.sort(key=lambda q: q.get("created", ""), reverse=True)
            return {"questions": qs}
        return await self.guard(go())


class QuestionView(_HBase):
    url = HIK + "/questions/{question_id}"
    name = f"api:{DOMAIN}:h_question"

    async def post(self, request, question_id):
        """{"answer": "Davorin"} teaches the answer; {"dismiss": true} closes it without teaching."""
        async def go():
            body = await self.body(request)
            store = self.store()
            qs = await self.hass.async_add_executor_job(store.questions)
            q = qs.get(question_id)
            if q is None:
                raise HError("Question not found", 404)
            if body.get("dismiss"):
                q = await self.hass.async_add_executor_job(partial(store.update_question, question_id, status="dismissed"))
                return {"question": q}
            answer = str(body.get("answer") or "").strip()
            if not answer:
                raise HError("Type who or what it is")
            found = find_event(self.rt, q["event_id"])
            hub = found[0] if found else next(iter(self.rt.hubs.values()), None)
            if hub is None:
                raise HError("No recorder is loaded", 503)
            rec = await hub.async_answer_question(question_id, answer)
            qs = await self.hass.async_add_executor_job(store.questions)
            return {"question": qs.get(question_id), "event": public(rec)}
        return await self.guard(go())

    async def delete(self, request, question_id):
        async def go():
            if not await self.hass.async_add_executor_job(self.store().delete_question, question_id):
                raise HError("Question not found", 404)
            return {"ok": True}
        return await self.guard(go())


# ---------------------------------------------------------------- settings
_OPTION_TYPES: dict[str, type] = {
    CONF_VISION_AGENT: str, CONF_PROMPT: str, CONF_ANALYSIS_CHANNELS: str,
    CONF_NOTIFY_SERVICES: str, CONF_ALARM_ENTITY: str, CONF_NOTIFY_MIN_THREAT: str, CONF_THREAT_FLOOR: str,
    CONF_ANALYSE_EVENTS: list, CONF_ONLY_WHEN_ARMED: bool, CONF_ASK_QUESTIONS: bool,
    CONF_FRAMES: int, CONF_COOLDOWN: int, CONF_MOTION_TIMEOUT: int, CONF_KEEP_IMAGES: int, CONF_KEEP_EVENTS: int,
    CONF_MAX_REFERENCES: int, CONF_FRAME_INTERVAL: float, CONF_IDENTITY_CONFIDENCE: float,
}
_RANGES = {CONF_FRAMES: (1, 5), CONF_COOLDOWN: (0, 3600), CONF_MOTION_TIMEOUT: (5, 300), CONF_KEEP_IMAGES: (10, 20000),
           CONF_KEEP_EVENTS: (50, 100000), CONF_MAX_REFERENCES: (0, 8), CONF_FRAME_INTERVAL: (0.2, 3.0),
           CONF_IDENTITY_CONFIDENCE: (0.1, 1.0)}


class SettingsView(_HBase):
    url = HIK + "/settings"
    name = f"api:{DOMAIN}:h_settings"

    async def get(self, request):
        async def go():
            hub = self.hub(request.query.get("dvr"))
            from ..const import CONF_VISION, SUB_AI_TASK  # noqa: PLC0415

            ref = hub._vision_ref()  # noqa: SLF001
            agents = [{"entity_id": a.entity_id, "name": a.name, "service": a.service, "model": a.data.get("model"), "vision": bool(a.data.get(CONF_VISION))}
                      for a in self.rt.list_agents() if a.kind == SUB_AI_TASK]
            opts = {k: v for k, v in hub.opts.items() if k not in ("ollama_url", "ollama_api_key", "model")}
            opts[CONF_VISION_AGENT] = opts.get(CONF_VISION_AGENT) or (ref.entity_id if ref else "")
            return {"dvr": hub.name, "dvr_id": hub.entry.entry_id, "options": opts, "defaults": {**DEFAULT_OPTIONS, CONF_PROMPT: DEFAULT_PROMPT},
                    "vision": {**hub.vision_status, "model": ref.name if ref else "none set"}, "vision_agents": agents, "threat_levels": THREAT_LEVELS}
        return await self.guard(go())

    async def put(self, request):
        async def go():
            body = await self.body(request)
            hub = self.hub(body.pop("dvr", None) or request.query.get("dvr"))
            new = dict(hub.entry.options)
            for key, value in (body.get("options") or body).items():
                kind = _OPTION_TYPES.get(key)
                if kind is None:
                    continue
                if kind is list:
                    if not isinstance(value, list):
                        raise HError(f"'{key}' must be a list")
                    value = [str(v) for v in value]
                elif kind is bool:
                    value = bool(value)
                elif kind in (int, float):
                    try:
                        value = kind(value)
                    except (TypeError, ValueError):
                        raise HError(f"'{key}' must be a number") from None
                    lo, hi = _RANGES[key]
                    if not lo <= value <= hi:
                        raise HError(f"'{key}' must be between {lo} and {hi}")
                else:
                    value = str(value or "").strip() if key != CONF_PROMPT else str(value or "")
                if key in (CONF_NOTIFY_MIN_THREAT, CONF_THREAT_FLOOR) and value not in THREAT_LEVELS:
                    raise HError(f"'{key}' must be one of {', '.join(THREAT_LEVELS)}")
                new[key] = value
            self.hass.config_entries.async_update_entry(hub.entry, options=new)  # reloads the recorder entry
            return {"ok": True, "note": "Saved. The recorder reloads in a few seconds."}
        return await self.guard(go())


ALL_VIEWS = (OverviewView, CamerasView, SnapshotView, AnalyzeView, EventsView, EventView, EventImageView, ReplayView,
             EntitiesView, EntityView, EntityCropsView, EntityCropView, RulesView, RuleView, LessonsView, LessonView,
             QuestionsView, QuestionView, SettingsView)


def setup_hikvision_views(hass: HomeAssistant, rt: Runtime) -> None:
    for view in ALL_VIEWS:
        hass.http.register_view(view(hass, rt))
