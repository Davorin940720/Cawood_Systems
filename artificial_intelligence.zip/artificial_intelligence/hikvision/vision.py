"""Vision for the camera AI: analysis parsing, and a client that runs on an AI task agent of this integration."""
from __future__ import annotations

import base64
import json
import re
from typing import Any

import httpx

from .const import OBJECT_KINDS, THREAT_LEVELS


class VisionError(Exception):
    """Vision model call failed."""


def normalise_base_url(url: str | None) -> str:
    url = (url or "").strip().rstrip("/")
    if url.endswith("/api"):
        url = url[:-4]
    return url or "https://ollama.com"


def _int(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _box(value: Any) -> list[int] | None:
    """A bounding box as four integers 0-1000 (left, top, right, bottom), or None."""
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        nums = [float(v) for v in value]
    except (TypeError, ValueError):
        return None
    if max(nums) <= 1.0:  # model answered with fractions
        nums = [v * 1000 for v in nums]
    x1, y1, x2, y2 = (max(0, min(1000, int(round(v)))) for v in nums)
    if x2 < x1:
        x1, x2 = x2, x1
    if y2 < y1:
        y1, y2 = y2, y1
    if x2 - x1 < 10 or y2 - y1 < 10:
        return None
    return [x1, y1, x2, y2]


def _objects(value: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if not isinstance(value, list):
        return out
    for item in value[:20]:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "other").strip().lower()
        if kind not in OBJECT_KINDS:
            kind = "other"
        try:
            conf = max(0.0, min(1.0, float(item.get("confidence", 0))))
        except (TypeError, ValueError):
            conf = 0.0
        out.append(
            {
                "kind": kind,
                "description": str(item.get("description") or "").strip()[:300],
                "identity": str(item.get("identity") or "").strip()[:80],
                "confidence": conf,
                "box": _box(item.get("box")),
            }
        )
    return out


def parse_analysis(content: str) -> dict[str, Any]:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", (content or "").strip(), flags=re.I)
    obj: Any = None
    try:
        obj = json.loads(text)
    except ValueError:
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end > start:
            try:
                obj = json.loads(text[start : end + 1])
            except ValueError:
                obj = None
    if not isinstance(obj, dict):
        obj = {"summary": text[:500], "reason": "Model did not return JSON"}
    threat = str(obj.get("threat_level", "")).strip().lower()
    if threat not in THREAT_LEVELS:
        threat = "low"
    return {
        "summary": str(obj.get("summary") or "").strip()[:1000] or "No description returned",
        "answer": str(obj.get("answer") or "").strip(),
        "people": _int(obj.get("people")),
        "vehicles": _int(obj.get("vehicles")),
        "animals": _int(obj.get("animals")),
        "activity": str(obj.get("activity") or "").strip(),
        "threat_level": threat,
        "reason": str(obj.get("reason") or "").strip(),
        "objects": _objects(obj.get("objects")),
    }


class ProviderVision:
    """Runs the camera analysis on an AI task agent (any service that can read images)."""

    def __init__(self, client, model: str, name: str, can_see: bool, extra_prompt: str = "", params: dict | None = None) -> None:
        self._client = client
        self.model = model
        self.name = name
        self.can_see = can_see
        self.extra = extra_prompt
        self.params = params or {}

    async def capabilities(self) -> list[str] | None:
        return ["vision"] if self.can_see else []

    async def analyse(self, images: list[bytes], prompt: str, timeout: float = 180.0) -> dict[str, Any]:
        from ..providers import ProviderError, bytes_part  # noqa: PLC0415

        content = [{"type": "text", "text": prompt}] + [bytes_part(i, "image/jpeg") for i in images]
        msgs = ([{"role": "system", "content": self.extra}] if self.extra else []) + [{"role": "user", "content": content}]
        try:
            reply = await self._client.complete(self.model, msgs, None, {"temperature": 0.2, **self.params, "json": True})
        except ProviderError as err:
            raise VisionError(str(err)) from err
        result = parse_analysis(reply.get("content") or "")
        result["model"] = f"{self.name} ({self.model})"
        return result
