"""Hikvision DVR/NVR support: ISAPI events, cameras, AI vision analysis and teaching."""
