"""Constants for the Hikvision part of Artificial Intelligence."""
from __future__ import annotations

from ..const import DOMAIN, HIK_DIR  # noqa: F401

NAME = "CAI Hikvision"
PLATFORMS = ["binary_sensor", "camera", "sensor"]
ENTITY_PREFIX = "CAI Hikvision"   # in the name of every entity that relates to the camera AI

# Connection (entry.data)
CONF_USE_SSL = "use_ssl"
CONF_VERIFY_SSL = "verify_ssl"
CONF_RTSP_PORT = "rtsp_port"
CONF_AUTH_TYPE = "auth_type"

# Behaviour (entry.options)
CONF_OLLAMA_URL = "ollama_url"
CONF_OLLAMA_KEY = "ollama_api_key"
CONF_MODEL = "model"
CONF_VISION_AGENT = "vision_agent"   # an ai_task entity of this integration that can read images
CONF_PROMPT = "prompt"
CONF_ANALYSE_EVENTS = "analyse_events"
CONF_ANALYSIS_CHANNELS = "analysis_channels"
CONF_FRAMES = "frames"
CONF_FRAME_INTERVAL = "frame_interval"
CONF_COOLDOWN = "cooldown"
CONF_MOTION_TIMEOUT = "motion_timeout"
CONF_NOTIFY_SERVICES = "notify_services"
CONF_NOTIFY_MIN_THREAT = "notify_min_threat"
CONF_ALARM_ENTITY = "alarm_entity"
CONF_ONLY_WHEN_ARMED = "only_when_armed"
CONF_KEEP_IMAGES = "keep_images"
CONF_KEEP_EVENTS = "keep_events"
CONF_IDENTITY_CONFIDENCE = "identity_confidence"
CONF_MAX_REFERENCES = "max_references"
CONF_ASK_QUESTIONS = "ask_questions"
CONF_THREAT_FLOOR = "threat_floor"

THREAT_LEVELS = ["none", "low", "medium", "high"]
OBJECT_KINDS = ["person", "vehicle", "animal", "other"]

# Raw Hikvision eventType (lower case) -> our kind
EVENT_TYPE_MAP = {
    "vmd": "motion",
    "pir": "motion",
    "linedetection": "line_crossing",
    "fielddetection": "intrusion",
    "regionentrance": "region",
    "regionexiting": "region",
    "videoloss": "video_loss",
    "shelteralarm": "tamper",
    "tamperdetection": "tamper",
    "io": "alarm_input",
}

# kind -> (label, device class, enabled by default)
CHANNEL_KINDS: dict[str, tuple[str, str, bool]] = {
    "motion": ("Motion", "motion", True),
    "line_crossing": ("Line crossing", "motion", True),
    "intrusion": ("Intrusion", "motion", True),
    "region": ("Region entrance/exit", "motion", False),
    "video_loss": ("Video loss", "problem", True),
    "tamper": ("Tamper", "tamper", True),
}
ANALYSABLE_KINDS = ["motion", "line_crossing", "intrusion", "region", "tamper"]

DEFAULT_PROMPT = """You are the vision analyst for a home alarm system.
Camera: {camera}
Trigger: {trigger}
Local time: {time}
You are given {frames} sequential frame(s) from this camera, oldest first.
{training_block}
{question_block}
Reply with ONLY a JSON object, no other text:
{"summary": "one short sentence that uses the real name of anyone or anything you recognise", "answer": "direct answer to the user's question, or empty string", "people": 0, "vehicles": 0, "animals": 0, "activity": "what any people, vehicles or animals are doing", "threat_level": "none|low|medium|high", "reason": "why you chose that threat level", "objects": [{"kind": "person|vehicle|animal|other", "description": "short visual description (clothing, colour, size, make)", "identity": "known name if you recognise it, otherwise empty string", "confidence": 0.0, "box": [x1, y1, x2, y2]}]}
List every person, vehicle and animal in "objects". "box" is the object's bounding box in the {box_frame_label}, as integers from 0 to 1000 (left, top, right, bottom). Only set "identity" to a name from the known list, never invent names. Leave it empty when you are not sure.
Threat guide: none = empty scene, lighting or weather change, insects, shadows. low = expected activity (residents, deliveries, passing traffic, pets). medium = unknown person or vehicle on the property, loitering. high = forced entry, climbing walls or fences, weapons, masked people, tampering with cameras, or anyone at doors or windows at night."""

DEFAULT_OPTIONS = {
    CONF_VISION_AGENT: "",
    CONF_PROMPT: DEFAULT_PROMPT,
    CONF_ANALYSE_EVENTS: ["motion", "line_crossing", "intrusion", "region"],
    CONF_ANALYSIS_CHANNELS: "",
    CONF_FRAMES: 3,
    CONF_FRAME_INTERVAL: 0.8,
    CONF_COOLDOWN: 60,
    CONF_MOTION_TIMEOUT: 15,
    CONF_NOTIFY_SERVICES: "",
    CONF_NOTIFY_MIN_THREAT: "medium",
    CONF_ALARM_ENTITY: "",
    CONF_ONLY_WHEN_ARMED: False,
    CONF_KEEP_IMAGES: 500,
    CONF_KEEP_EVENTS: 1000,
    CONF_IDENTITY_CONFIDENCE: 0.6,
    CONF_MAX_REFERENCES: 4,
    CONF_ASK_QUESTIONS: True,
    CONF_THREAT_FLOOR: "low",
}

EVENT_RAW = "cai_hikvision_event"
EVENT_ANALYSIS = "cai_hikvision_analysis"
DETECTIONS_MAX = 500
MEDIA_SUBDIR = "cai_hikvision"
MAX_OPEN_QUESTIONS = 60
