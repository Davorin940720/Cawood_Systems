"""Write access: reading is open, writing only to the locations on the write list. Everything else needs the user's approval.

The check runs here on the server, inside each endpoint that changes something, so no model can get around it:

- a call the user makes by hand (their own terminal window, the file browser) is theirs and goes through;
- a call made by a model (header X-CAI-Tool from cai-tools.js, the voice tools, the MCP server) is checked:
  inside the write list it goes through; outside it the page gets 'needs approval' and must come back with a single-use
  approval; voice is refused or asks on the phone (setting); MCP clients are refused.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import posixpath
import secrets
import time
from collections import deque
from typing import Any

from aiohttp import web

from homeassistant.core import Event, HomeAssistant, callback

from .authz import PRINCIPAL_KEY, AuthedView
from .const import API, APPROVAL_HEADER
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)

DEFAULT_ALLOW = [
    {"id": "a1", "root": "_workspace", "path": "", "label": "AI scratch folder"},
    {"id": "a2", "root": "projects", "path": "", "label": "Projects (sources and chats)"},
    {"id": "a3", "root": "config", "path": "www/Artificial Intelegence", "label": "Integration data (chats, settings, Hikvision training)"},
]
APPROVAL_TTL = 900
PHONE_WAIT = 90


def norm(path: Any) -> str:
    p = str(path or "").replace("\\", "/").strip()
    while p.startswith("/"):
        p = p[1:]
    if not p:
        return ""
    root, _, rest = p.partition("/")
    rest = posixpath.normpath("/" + rest).lstrip("/") if rest else ""
    if rest == ".":
        rest = ""
    return f"{root}/{rest}".rstrip("/") if rest else root


def allowed(target: str, allow: list[dict]) -> bool:
    t = norm(target).lower()
    if not t or "/../" in "/" + t + "/":
        return False
    for a in allow:
        full = norm(str(a.get("root", "")) + ("/" + str(a.get("path")) if a.get("path") else "")).lower()
        if full and (t == full or t.startswith(full + "/")):
            return True
    return False


class AccessManager:
    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt
        self.approvals: dict[str, dict] = {}
        self.audit: deque = deque(maxlen=300)
        self.waiting: dict[str, asyncio.Future] = {}
        self._file = os.path.join(rt.paths.app, "write-audit.json")
        self._unsub = hass.bus.async_listen("mobile_app_notification_action", self._phone_answer)

    async def async_load(self) -> None:
        def read():
            try:
                with open(self._file, encoding="utf-8") as fh:
                    return json.load(fh)
            except (OSError, ValueError):
                return []
        self.audit.extend(await self.hass.async_add_executor_job(read))

    # ------------------------------------------------------------------ settings
    async def settings(self) -> dict:
        cfg = await self.hass.async_add_executor_job(self.rt.core.config)
        return {"readAll": True, "allow": cfg.get("write_allow") or [dict(a) for a in DEFAULT_ALLOW],
                "voice": {"mode": cfg.get("voice_write_mode") or "deny", "notify": cfg.get("voice_write_notify") or ""}}

    async def save(self, body: dict) -> dict:
        changes: dict[str, Any] = {}
        if isinstance(body.get("allow"), list):
            clean = []
            for i, a in enumerate(body["allow"]):
                root = str(a.get("root", "")).strip()
                if not root:
                    continue
                clean.append({"id": str(a.get("id") or f"a{int(time.time())}{i}"), "root": root, "path": norm(a.get("path", "")) if a.get("path") else "",
                              "label": str(a.get("label", ""))[:120]})
            changes["write_allow"] = clean
        voice = body.get("voice") or {}
        if voice.get("mode") in ("deny", "notify"):
            changes["voice_write_mode"] = voice["mode"]
        if "notify" in voice:
            changes["voice_write_notify"] = str(voice["notify"]).strip()
        if changes:
            await self.hass.async_add_executor_job(self.rt.core.set_config, changes)
        return await self.settings()

    def roots(self) -> list[str]:
        from .system import FS_ROOTS, SMB_CONF  # noqa: PLC0415

        names = [n for n in ("config", "projects", "_workspace") if n in FS_ROOTS] + [f"smb:{n}" for n in SMB_CONF]
        if self.rt.agents:
            names += [f"agent:{n}" for n in self.rt.agents.names()]
        return names

    # ------------------------------------------------------------------ log
    def log(self, who: str, tool: str, target: str, result: str, note: str = "") -> None:
        self.audit.appendleft({"ts": int(time.time() * 1000), "who": who, "tool": tool, "target": target[:300], "result": result, "note": note})
        data = list(self.audit)
        self.hass.async_add_executor_job(self._save, data)

    def _save(self, data: list) -> None:
        try:
            tmp = self._file + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh)
            os.replace(tmp, self._file)
        except OSError as err:
            _LOGGER.debug("Could not save the write log: %s", err)

    # ------------------------------------------------------------------ the check
    async def check(self, request: web.Request, tool: str, target: str, summary: str, preview: str = "", listable: bool = True) -> web.Response | None:
        """None = go ahead. A response = stop and return it."""
        p = request.get(PRINCIPAL_KEY)
        origin = getattr(p, "origin", "user")
        if origin == "user":
            return None
        who = {"voice": "Voice assistant", "mcp": "MCP client", "page": f"{getattr(p, 'name', 'user')} (chat)"}.get(origin, origin)
        settings = await self.settings()
        if listable and allowed(target, settings["allow"]):
            self.log(who, tool, target, "allowed", "On the write list")
            return None
        key = f"{tool}|{target}"
        aid = request.headers.get(APPROVAL_HEADER)
        a = self.approvals.get(aid or "")
        if a and a["key"] == key and a["state"] == "approved" and time.time() - a["ts"] < APPROVAL_TTL:
            del self.approvals[aid]
            self.log(who, tool, target, "approved", "Approved once")
            return None
        if origin == "voice":
            if settings["voice"]["mode"] == "notify" and settings["voice"]["notify"]:
                ok = await self._ask_phone(settings["voice"]["notify"], summary)
                self.log(who, tool, target, "approved" if ok else "denied", "Answered on the phone" if ok is not None else "No answer on the phone")
                if ok:
                    return None
                return web.json_response({"error": "The change was not approved on the phone, so nothing was changed."}, status=403)
            self.log(who, tool, target, "blocked", "Voice cannot approve; refused")
            return web.json_response({"error": f"Not allowed from voice: {summary}. That location is not on the write list. Ask the user to do it from the chat page, where they can approve it."}, status=403)
        if origin == "mcp":
            self.log(who, tool, target, "blocked", "MCP clients cannot approve; refused")
            return web.json_response({"error": f"Refused: {summary}. Writes outside the write list need approval, which an MCP client cannot give."}, status=403)
        self._expire()
        nid = secrets.token_urlsafe(9)
        self.approvals[nid] = {"key": key, "tool": tool, "target": target, "who": who, "state": "pending", "ts": time.time()}
        return web.json_response({"error": "This change needs your approval.", "needs_approval": True,
                                  "approval": {"id": nid, "tool": tool, "target": target, "summary": summary, "preview": preview[:1500]}}, status=403)

    def answer(self, aid: str, approve: bool) -> bool:
        a = self.approvals.get(aid)
        if not a:
            return False
        if approve:
            a["state"] = "approved"
            a["ts"] = time.time()
        else:
            self.log(a["who"], a["tool"], a["target"], "denied", "You declined")
            del self.approvals[aid]
        return True

    def _expire(self) -> None:
        now = time.time()
        for k in [k for k, v in self.approvals.items() if now - v["ts"] > APPROVAL_TTL]:
            del self.approvals[k]

    # ------------------------------------------------------------------ approval on the phone (voice)
    async def _ask_phone(self, service: str, summary: str) -> bool | None:
        nid = secrets.token_hex(6)
        domain, _, name = service.partition(".")
        if not name:
            domain, name = "notify", service
        fut: asyncio.Future = self.hass.loop.create_future()
        self.waiting[nid] = fut
        try:
            await self.hass.services.async_call(domain, name, {
                "title": "Allow this change?", "message": f"Your voice assistant wants to: {summary}",
                "data": {"tag": f"cai_{nid}", "actions": [{"action": f"CAI_APPROVE_{nid}", "title": "Allow"}, {"action": f"CAI_DENY_{nid}", "title": "Deny"}]},
            }, blocking=True)
            return await asyncio.wait_for(fut, PHONE_WAIT)
        except TimeoutError:
            return None
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Could not send the approval request to %s: %s", service, err)
            return None
        finally:
            self.waiting.pop(nid, None)

    @callback
    def _phone_answer(self, event: Event) -> None:
        action = str(event.data.get("action", ""))
        for prefix, value in (("CAI_APPROVE_", True), ("CAI_DENY_", False)):
            if action.startswith(prefix):
                fut = self.waiting.get(action[len(prefix):])
                if fut and not fut.done():
                    fut.set_result(value)


# ---------------------------------------------------------------------- views
class AccessView(AuthedView):
    url = API + "/access"
    name = "api:artificial_intelligence:access"

    async def get(self, request):
        s = await self.rt.access.settings()
        return self.json({**s, "roots": self.rt.access.roots()})

    async def put(self, request):
        if not self.who(request).is_admin:
            return self.json({"error": "Only an administrator can change write access."}, status_code=403)
        return self.json(await self.rt.access.save(await request.json()))


class AuditView(AuthedView):
    url = API + "/audit"
    name = "api:artificial_intelligence:audit"

    async def get(self, request):
        return self.json({"entries": list(self.rt.access.audit)[:200]})


class ApprovalView(AuthedView):
    url = API + "/approvals/{aid}"
    name = "api:artificial_intelligence:approval"

    async def post(self, request, aid):
        p = self.who(request)
        if getattr(p, "origin", "user") != "user":
            return self.json({"error": "Only a person can approve a change."}, status_code=403)
        body = await request.json()
        if not self.rt.access.answer(aid, bool(body.get("approve"))):
            return self.json({"error": "That approval has expired. Ask the AI to try again."}, status_code=404)
        return self.json({"ok": True})


def setup_access(hass: HomeAssistant, rt: Runtime) -> None:
    rt.access = AccessManager(hass, rt)
    for view in (AccessView, AuditView, ApprovalView):
        hass.http.register_view(view(hass, rt))
