"""An update entity per machine agent: shows the installed and the latest agent version, and installs it."""
from __future__ import annotations

from typing import Any

from homeassistant.components.update import UpdateEntity, UpdateEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.dispatcher import async_dispatcher_connect
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CONF_ENTRY_TYPE, ENTRY_BACKEND, SIGNAL_AGENT_NEW
from .entities import _AgentEntity
from .runtime import get_runtime


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    if entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND) != ENTRY_BACKEND:
        return
    hub = get_runtime(hass).agents
    done: set[str] = set()

    @callback
    def add(name: str) -> None:
        if name not in done:
            done.add(name)
            async_add_entities([AgentUpdate(hass, name, "update", "Agent update")])

    for name in hub.names():
        add(name)
    entry.async_on_unload(async_dispatcher_connect(hass, SIGNAL_AGENT_NEW, add))


class AgentUpdate(_AgentEntity, UpdateEntity):
    _attr_supported_features = UpdateEntityFeature.INSTALL | UpdateEntityFeature.PROGRESS
    _attr_title = "Cawood AI agent"

    @property
    def installed_version(self) -> str | None:
        return self.a.get("version") or "2.0.0"

    @property
    def latest_version(self) -> str | None:
        return get_runtime(self.hass).agents.latest

    @property
    def in_progress(self) -> bool:
        return self.a.get("update") == "updating"

    @property
    def release_summary(self) -> str | None:
        return self.a.get("update_msg") or None

    async def async_install(self, version: str | None, backup: bool, **kwargs: Any) -> None:
        try:
            await get_runtime(self.hass).agents.async_update_agent(self.agent)
        except RuntimeError as err:
            raise HomeAssistantError(str(err)) from err
