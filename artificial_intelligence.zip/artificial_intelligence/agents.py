"""Machine agents (cai-agent.py on Windows, Linux and Android): devices, heartbeats and automatic updates.

Every agent that registers becomes a Home Assistant device with entities (connected, terminal and browser available,
uptime, last contact, OS, CPU, RAM, version, update). Agents from before version 3 are updated in place the first time
they connect: the new script is written next to the old one, checked, swapped in and the agent restarted, keeping its
cai-agent.conf.json. Version 3 agents update themselves through their own /update endpoint.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import time
from datetime import timedelta
from typing import Any

import aiohttp

from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.dispatcher import async_dispatcher_send
from homeassistant.helpers.event import async_track_time_interval

from .authz import AuthedView
from .const import AGENT_ONLINE_SECONDS, API, CONF_AUTO_UPDATE, DOMAIN, SIGNAL_AGENT_NEW, SIGNAL_AGENT_UPDATE
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)
AGENT_FILE = os.path.join(os.path.dirname(__file__), "agent", "cai-agent.py")
NAME_RE = re.compile(r"[^\w .-]")


def _read_bundled() -> tuple[str, str]:
    with open(AGENT_FILE, encoding="utf-8") as fh:
        code = fh.read()
    m = re.search(r'^AGENT_VERSION\s*=\s*"([^"]+)"', code, re.M)
    return code, (m.group(1) if m else "3.0.0")


def vtuple(v: Any) -> tuple[int, ...]:
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(n) for n in nums[:3]) if nums else (0,)


class AgentHub:
    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt
        self.file = os.path.join(rt.paths.app, "agents.json")
        self.data: dict[str, dict] = {}
        self.code, self.latest = "", "3.0.0"
        self.entry_id: str | None = None
        self._unsub = None
        self._busy: set[str] = set()
        self._tried: dict[str, float] = {}

    async def async_start(self) -> None:
        await self.hass.async_add_executor_job(lambda: os.makedirs(os.path.dirname(self.file), exist_ok=True))
        self.data = await self.hass.async_add_executor_job(self._load)
        self.code, self.latest = await self.hass.async_add_executor_job(_read_bundled)
        self._unsub = async_track_time_interval(self.hass, self._tick, timedelta(seconds=30))

    def _load(self) -> dict:
        try:
            with open(self.file, encoding="utf-8") as fh:
                d = json.load(fh)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self) -> None:
        data = json.dumps(self.data)
        def work():
            os.makedirs(os.path.dirname(self.file), exist_ok=True)
            tmp = self.file + ".tmp"
            
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(data)
            os.replace(tmp, self.file)
        self.hass.async_add_executor_job(work)

    # ------------------------------------------------------------------ state
    def names(self) -> list[str]:
        return sorted(self.data)

    def get(self, name: str) -> dict | None:
        want = str(name or "").lower().strip()
        for k, v in self.data.items():
            if k.lower() == want:
                return {"name": k, **v}
        for k, v in self.data.items():
            if want and want in k.lower():
                return {"name": k, **v}
        return None

    def online(self, a: dict) -> bool:
        return time.time() - float(a.get("ts", 0)) < AGENT_ONLINE_SECONDS

    def view(self, name: str) -> dict:
        a = self.data.get(name, {})
        return {"name": name, "url": a.get("url"), "os": a.get("os"), "caps": a.get("caps", []), "online": self.online(a), "last_seen": int(float(a.get("ts", 0)) * 1000),
                "version": a.get("version") or "2.0 (no version reported)", "update": a.get("update") or ("pending" if vtuple(a.get("version")) < vtuple(self.latest) else "current"),
                "update_msg": a.get("update_msg", ""), "info": a.get("info") or {}}

    def _changed(self, name: str) -> None:
        async_dispatcher_send(self.hass, f"{SIGNAL_AGENT_UPDATE}_{name}")

    @callback
    def _tick(self, _now=None) -> None:
        for name in self.data:
            self._changed(name)

    async def register(self, body: dict) -> dict:
        name = NAME_RE.sub("", str(body.get("name", "")))[:40].strip()
        if not name:
            raise ValueError("name required")
        new = name not in self.data
        a = self.data.setdefault(name, {})
        a.update({"url": str(body.get("url", "")), "os": str(body.get("os", "")), "caps": list(body.get("caps") or []), "ts": time.time()})
        if body.get("version"):
            if vtuple(body["version"]) >= vtuple(self.latest) and a.get("update") in ("updating", "pending", "failed"):
                a["update"], a["update_msg"] = "current", "Updated"
            a["version"] = str(body["version"])
        if isinstance(body.get("info"), dict):
            a["info"] = {k: body["info"].get(k) for k in ("os_name", "cpu", "cores", "ram_total", "uptime_s", "platform", "hostname", "python")}
        self._save()
        if new:
            async_dispatcher_send(self.hass, SIGNAL_AGENT_NEW, name)
        self._changed(name)
        self._maybe_auto_update(name)
        return {"ok": True, "latest": self.latest}

    def forget(self, name: str) -> None:
        if self.data.pop(name, None) is not None:
            self._save()

    def _maybe_auto_update(self, name: str) -> None:
        backend = self.rt.backend_entry()
        if backend is None or not backend.options.get(CONF_AUTO_UPDATE, True):
            return
        a = self.data.get(name, {})
        if vtuple(a.get("version")) >= vtuple(self.latest) or name in self._busy or a.get("update") == "manual":
            return
        if time.time() - self._tried.get(name, 0) < 3600:
            return
        self._tried[name] = time.time()
        self.hass.async_create_background_task(self.async_update_agent(name), f"{DOMAIN} update agent {name}")

    # ------------------------------------------------------------------ talking to an agent
    async def _call(self, a: dict, op: str, body: dict, timeout: float = 120) -> dict:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
            async with s.post(str(a["url"]).rstrip("/") + "/" + op, json=body, headers={"Authorization": "Bearer " + self.rt.relay_secret}) as r:
                try:
                    data = await r.json(content_type=None)
                except (ValueError, aiohttp.ContentTypeError):
                    data = {"error": (await r.text())[:300]}
                if r.status >= 400:
                    raise RuntimeError(str(data.get("error") or f"HTTP {r.status}"))
                return data

    async def _term(self, a: dict, command: str, timeout: float = 60) -> tuple[int, str]:
        d = await self._call(a, "term", {"command": command, "timeout": timeout}, timeout + 20)
        return int(d.get("code") or 0), str(d.get("output") or "")

    def _set(self, name: str, state: str, msg: str = "") -> None:
        if name in self.data:
            self.data[name]["update"], self.data[name]["update_msg"] = state, msg
            self._save()
            self._changed(name)

    async def async_update_agent(self, name: str) -> str:
        a = self.get(name)
        if not a:
            raise RuntimeError(f"No agent named {name}")
        if not self.online(a):
            raise RuntimeError(f"{name} is offline")
        if name in self._busy:
            return "An update is already running."
        self._busy.add(name)
        self._set(name, "updating", "Updating")
        try:
            if vtuple(a.get("version")) >= (3,):
                await self._call(a, "update", {"code": self.code, "sha256": hashlib.sha256(self.code.encode()).hexdigest(), "version": self.latest}, 60)
                msg = "Restarting with the new version"
            else:
                msg = await self._legacy_update(a)
            self._set(name, "updating", msg)
            asyncio.get_running_loop().call_later(180, self._check_done, name)
            return msg
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Updating agent %s failed: %s", name, err)
            self._set(name, "failed", f"Update failed: {err}. Copy the new cai-agent.py over the old one and restart the agent.")
            raise RuntimeError(str(err)) from err
        finally:
            self._busy.discard(name)

    @callback
    def _check_done(self, name: str) -> None:
        a = self.data.get(name, {})
        if a.get("update") == "updating" and vtuple(a.get("version")) < vtuple(self.latest):
            self._set(name, "failed", a.get("update_msg") or "The agent did not come back with the new version.")

    async def _legacy_update(self, a: dict) -> str:
        """Version 2 agents have no update endpoint: use their terminal and file access."""
        is_win = str(a.get("os", "")).lower().startswith("win")
        if is_win:
            ps = ("$ErrorActionPreference='SilentlyContinue';"
                  "$r=Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
                  "Where-Object { $_.CommandLine -match 'cai-agent\\.py' } | "
                  "Select-Object ProcessId,ExecutablePath,CommandLine;"
                  "if($r){ConvertTo-Json -Compress -InputObject @($r)}else{'[]'}")
            b64 = base64.b64encode(ps.encode("utf-16-le")).decode()
            code, out = await self._term(a, f"powershell -NoProfile -NonInteractive -EncodedCommand {b64}")
            try:
                procs = json.loads((out.strip() or "[]"))
            except ValueError as err:
                raise RuntimeError(f"Could not read the agent's process: {out[:200]}") from err
            procs = procs if isinstance(procs, list) else [procs]
            if not procs:
                raise RuntimeError("Could not find the running agent. Is pythonw running cai-agent.py? Try updating again, or copy the new cai-agent.py over the old one and restart it.")
            p = procs[0]
            pid, exe, cmd = p.get("ProcessId"), p.get("ExecutablePath") or "pythonw.exe", p.get("CommandLine") or ""
            m = re.search(r'"?([A-Za-z]:\\[^"]*?cai-agent\.py)"?', cmd)
            if not m:
                raise RuntimeError(f"Could not find the agent's script path in: {cmd[:200]}")
            script = m.group(1)
            folder = script.rsplit("\\", 1)[0]
            sep = "\\"
        else:
            probe = ('for p in /proc/[0-9]*; do e=$(readlink $p/exe 2>/dev/null); case "$e" in *python*) c=$(tr "\\0" " " < $p/cmdline 2>/dev/null); '
                     'case "$c" in *cai-agent.py*) echo "PROC|$(basename $p)|$e|$(readlink $p/cwd)|$c|$(tr "\\n" ";" < $p/cgroup 2>/dev/null)";; esac;; esac; done; echo "PREFIX|$PREFIX"')
            code, out = await self._term(a, probe)
            rows = [ln.split("|") for ln in out.splitlines() if ln.startswith("PROC|")]
            if not rows:
                raise RuntimeError("Could not find the running agent.")
            _t, pid, exe, cwd, cmd, cgroup = (rows[0] + [""] * 6)[:6]
            termux = "com.termux" in out
            tok = next((t for t in cmd.split() if t.endswith("cai-agent.py")), "cai-agent.py")
            script = tok if tok.startswith("/") else os.path.normpath(os.path.join(cwd, tok))
            folder = script.rsplit("/", 1)[0]
            sep = "/"
        new = f"{folder}{sep}cai-agent.py.new"
        conf = await self._call(a, "file", {"op": "read", "path": f"{folder}{sep}cai-agent.conf.json"}, 30)
        try:
            port = int(json.loads(conf.get("content") or "{}").get("listen_port") or 8765)
        except ValueError:
            port = 8765
        await self._call(a, "file", {"op": "write", "path": new, "content": self.code, "mode": "overwrite", "backup": False}, 60)
        if is_win:
            py = re.sub(r"pythonw\.exe$", "python.exe", exe, flags=re.I)
            code, out = await self._term(a, f'"{py}" -m py_compile "{new}"')
            if code != 0:
                raise RuntimeError(f"The new agent failed its syntax check: {out[:200]}")
            helper = f"{folder}\\cai-agent-update.ps1"
            ps = "\r\n".join([
                "Start-Sleep -Seconds 3",
                f"Stop-Process -Id {pid} -Force -ErrorAction SilentlyContinue",
                "Start-Sleep -Seconds 2",
                f"Copy-Item -LiteralPath '{script}' -Destination '{script}.bak' -Force",
                f"Move-Item -LiteralPath '{new}' -Destination '{script}' -Force",
                f"Start-Process -FilePath '{exe}' -ArgumentList '\"{script}\"' -WorkingDirectory '{folder}' -WindowStyle Hidden",
                "$ok = $false",
                f"for ($i = 0; $i -lt 25; $i++) {{ Start-Sleep -Seconds 2; try {{ Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 -Uri 'http://127.0.0.1:{port}/ping' | Out-Null; $ok = $true; break }} catch {{}} }}",
                "if (-not $ok) {",
                "  Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and $_.CommandLine -like '*cai-agent.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }",
                f"  Copy-Item -LiteralPath '{script}.bak' -Destination '{script}' -Force",
                f"  Start-Process -FilePath '{exe}' -ArgumentList '\"{script}\"' -WorkingDirectory '{folder}' -WindowStyle Hidden",
                "}",
            ])
            await self._call(a, "file", {"op": "write", "path": helper, "content": ps, "mode": "overwrite", "backup": False}, 30)
            launch = ('powershell -NoProfile -Command "Start-Process powershell -WindowStyle Hidden -ArgumentList '
                      f"'-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File','\\\"{helper}\\\"'\"")
            try:
                await self._term(a, launch, 30)
            except Exception:  # noqa: BLE001  the agent may be stopped before it answers
                pass
            return "Restarting with the new version (Windows)"
        code, out = await self._term(a, f'"{exe}" -m py_compile "{new}"')
        if code != 0:
            raise RuntimeError(f"The new agent failed its syntax check: {out[:200]}")
        unit = (re.search(r"/([^/;]+\.service)", cgroup) or [None, None])[1] if cgroup else None
        if unit and not termux:
            user = "user@" in cgroup
            sc = "systemctl --user" if user else "systemctl"
            _c, show = await self._term(a, f"{sc} show -p Restart {unit}")
            restart = show.strip().split("=", 1)[-1]
            swap = f'cp "{script}" "{script}.bak" && mv "{new}" "{script}"'
            if restart in ("always", "on-failure", "on-abnormal", "on-abort", "on-watchdog"):
                await self._term(a, f"{swap} && (sleep 2; kill -9 {pid}) >/dev/null 2>&1 &", 30)
                return f"Restarting through systemd ({unit})"
            if user:
                await self._term(a, f"{swap} && (sleep 2; systemctl --user restart {unit}) >/dev/null 2>&1 &", 30)
                return f"Restarting through systemd ({unit})"
            await self._term(a, swap, 30)
            self.data.get(a["name"], {})["update"] = "manual"
            return f"The new file is in place. Restart it once with: sudo systemctl restart {unit}"
        helper = f"{folder}/cai-agent-update.sh"
        sh = "\n".join([
            "#!/bin/sh", "sleep 3", f"kill {pid} 2>/dev/null; sleep 2; kill -9 {pid} 2>/dev/null",
            f'cp "{script}" "{script}.bak"; mv "{new}" "{script}"', f'cd "{folder}"',
            f'nohup "{exe}" "{script}" > "{folder}/agent.log" 2>&1 &', "NEW=$!", "i=0",
            f'while [ $i -lt 25 ]; do sleep 2; "{exe}" -c "import urllib.request;urllib.request.urlopen(\'http://127.0.0.1:{port}/ping\',timeout=3)" 2>/dev/null && exit 0; i=$((i+1)); done',
            f'kill $NEW 2>/dev/null; cp "{script}.bak" "{script}"; nohup "{exe}" "{script}" > "{folder}/agent.log" 2>&1 &', ""])
        await self._call(a, "file", {"op": "write", "path": helper, "content": sh, "mode": "overwrite", "backup": False}, 30)
        try:
            await self._term(a, f'(command -v setsid >/dev/null 2>&1 && setsid sh "{helper}" || nohup sh "{helper}") >/dev/null 2>&1 &', 30)
        except Exception:  # noqa: BLE001
            pass
        return "Restarting with the new version"

    def device_info(self, name: str) -> dict:
        a = self.data.get(name, {})
        info = a.get("info") or {}
        return {"identifiers": {(DOMAIN, f"agent_{name}")}, "name": name, "manufacturer": "Cawood Systems", "model": "Cawood AI agent",
                "sw_version": a.get("version") or "2.x", "hw_version": info.get("os_name") or a.get("os")}


# ---------------------------------------------------------------------- views
class AgentsView(AuthedView):
    """Agents register here (with a Home Assistant token); the pages list them."""

    url = API + "/agents"
    name = "api:artificial_intelligence:agents"

    async def get(self, request):
        hub = self.rt.agents
        return self.json([hub.view(n) for n in hub.names()])

    async def post(self, request):
        if self.who(request).kind != "ha" or getattr(self.who(request), "origin", "user") != "user":
            return self.json({"error": "Only a Home Assistant token can register an agent"}, status_code=403)
        try:
            return self.json(await self.rt.agents.register(await request.json()))
        except ValueError as err:
            return self.json({"error": str(err)}, status_code=400)


class LegacyAgentsView(AgentsView):
    """Agents before version 3 register at this path."""

    url = "/api/davai/agents"
    name = "api:artificial_intelligence:agents_legacy"


def setup_agents(hass: HomeAssistant, rt: Runtime) -> None:
    rt.agents = AgentHub(hass, rt)
    for view in (AgentsView, LegacyAgentsView):
        hass.http.register_view(view(hass, rt))


async def async_remove_agent_device(hass: HomeAssistant, rt: Runtime, device: dr.DeviceEntry) -> bool:
    for domain, ident in device.identifiers:
        if domain == DOMAIN and str(ident).startswith("agent_"):
            rt.agents.forget(str(ident)[6:])
            return True
    return False
