"""File storage, users and sessions for Artificial Intelligence (no Home Assistant imports)."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import threading
import time
from pathlib import Path
from typing import Any

from .const import KINDS, MAX_ITEM_BYTES, RESET_MINUTES, SESSION_DAYS

EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[A-Za-z]{2,}$")
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
PBKDF2_ROUNDS = 200_000

DEFAULT_CONFIG: dict[str, Any] = {
    "allow_signup": True,
    "enabled_integrations": [],
}
# settings other modules keep here (write access, MCP server); set through their own endpoints
EXTRA_KEYS = ("write_allow", "voice_write_mode", "voice_write_notify", "mcp_enabled", "mcp_groups")


class AIError(Exception):
    """Error with an HTTP status and a message for the user."""

    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


def _hash_pw(password: str, salt: bytes, rounds: int = PBKDF2_ROUNDS) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, rounds).hex()


def _sha(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class Core:
    """All file access. Every public method is blocking: run it in the executor."""

    def __init__(self, base: Path) -> None:
        self.base = Path(base)
        self.lock = threading.RLock()
        self.base.mkdir(parents=True, exist_ok=True)
        (self.base / "users").mkdir(exist_ok=True)
        if not (self.base / "config.json").exists():
            self._write(self.base / "config.json", DEFAULT_CONFIG)

    # ---------- low level ----------
    def _read(self, path: Path, default: Any) -> Any:
        try:
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            return default
        except (OSError, ValueError):
            return default

    def _write(self, path: Path, data: Any) -> int:
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        tmp = path.with_name(f".{path.name}.{secrets.token_hex(4)}.tmp")
        with open(tmp, "wb") as fh:
            fh.write(raw)
        os.replace(tmp, path)
        return len(raw)

    def _inside(self, path: Path) -> Path:
        real = path.resolve()
        root = self.base.resolve()
        if root not in real.parents and real != root:
            raise AIError("Invalid path", 400)
        return real

    # ---------- config ----------
    def config(self) -> dict[str, Any]:
        cfg = dict(DEFAULT_CONFIG)
        cfg.update(self._read(self.base / "config.json", {}))
        return cfg

    def set_config(self, changes: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            cfg = self.config()
            cfg.pop("ollama_key", None)
            cfg.pop("base_url", None)
            for key in EXTRA_KEYS:
                if key in changes:
                    cfg[key] = changes[key]
            if "allow_signup" in changes:
                cfg["allow_signup"] = bool(changes["allow_signup"])
            if "enabled_integrations" in changes:
                cfg["enabled_integrations"] = sorted({str(d) for d in changes["enabled_integrations"] if ID_RE.match(str(d))})
            self._write(self.base / "config.json", cfg)
            return cfg

    # ---------- users ----------
    def _users(self) -> dict[str, dict]:
        return self._read(self.base / "users.json", {})

    def _save_users(self, users: dict) -> None:
        self._write(self.base / "users.json", users)

    @staticmethod
    def public(user: dict) -> dict:
        return {k: user.get(k) for k in ("id", "email", "name", "role", "tools", "disabled", "created", "last_login")}

    def _find(self, users: dict, email: str) -> dict | None:
        email = email.strip().lower()
        return next((u for u in users.values() if u["email"] == email), None)

    @staticmethod
    def _check_pw(password: str) -> None:
        if not isinstance(password, str) or len(password) < 8:
            raise AIError("Password must be at least 8 characters.")
        if len(password) > 256:
            raise AIError("Password is too long.")

    def signup(self, email: str, password: str, name: str) -> tuple[dict, str]:
        email = (email or "").strip().lower()
        name = (name or "").strip()[:60] or email.split("@")[0]
        if not EMAIL_RE.match(email):
            raise AIError("Enter a valid email address.")
        self._check_pw(password)
        with self.lock:
            users = self._users()
            if users and not self.config().get("allow_signup", True):
                raise AIError("Sign-up is turned off. Ask the admin for an account.", 403)
            if self._find(users, email):
                raise AIError("An account with that email already exists. Log in instead.", 409)
            salt = secrets.token_bytes(16)
            uid = "u" + secrets.token_hex(8)
            first = not users
            users[uid] = {
                "id": uid, "email": email, "name": name,
                "role": "admin" if first else "user", "tools": first, "disabled": False,
                "salt": salt.hex(), "hash": _hash_pw(password, salt), "rounds": PBKDF2_ROUNDS,
                "created": int(time.time()), "last_login": int(time.time()),
            }
            self._save_users(users)
            (self.base / "users" / uid).mkdir(parents=True, exist_ok=True)
            return self.public(users[uid]), self._new_session(uid)

    def login(self, email: str, password: str) -> tuple[dict, str]:
        with self.lock:
            users = self._users()
            user = self._find(users, email or "")
            # Always hash, so timing doesn't reveal which emails exist.
            salt = bytes.fromhex(user["salt"]) if user else b"0" * 16
            digest = _hash_pw(password or "", salt, user.get("rounds", PBKDF2_ROUNDS) if user else PBKDF2_ROUNDS)
            if not user or not hmac.compare_digest(digest, user["hash"]):
                raise AIError("Email or password is incorrect.", 401)
            if user.get("disabled"):
                raise AIError("This account is disabled. Contact the admin.", 403)
            user["last_login"] = int(time.time())
            self._save_users(users)
            return self.public(user), self._new_session(user["id"])

    def _sessions(self) -> dict:
        return self._read(self.base / "sessions.json", {})

    def _new_session(self, uid: str) -> str:
        token = secrets.token_urlsafe(32)
        sessions = {k: v for k, v in self._sessions().items() if v.get("exp", 0) > time.time()}
        sessions[_sha(token)] = {"uid": uid, "exp": int(time.time() + SESSION_DAYS * 86400)}
        self._write(self.base / "sessions.json", sessions)
        return token

    def user_for(self, token: str | None) -> dict | None:
        if not token:
            return None
        sess = self._sessions().get(_sha(token))
        if not sess or sess.get("exp", 0) < time.time():
            return None
        user = self._users().get(sess["uid"])
        if not user or user.get("disabled"):
            return None
        return self.public(user)

    def logout(self, token: str) -> None:
        with self.lock:
            sessions = self._sessions()
            if sessions.pop(_sha(token or ""), None) is not None:
                self._write(self.base / "sessions.json", sessions)

    def _drop_sessions(self, uid: str, keep: str | None = None) -> None:
        sessions = {k: v for k, v in self._sessions().items() if v["uid"] != uid or k == keep}
        self._write(self.base / "sessions.json", sessions)

    def change_password(self, uid: str, old: str, new: str, token: str) -> None:
        self._check_pw(new)
        with self.lock:
            users = self._users()
            user = users.get(uid)
            if not user or not hmac.compare_digest(_hash_pw(old or "", bytes.fromhex(user["salt"]), user.get("rounds", PBKDF2_ROUNDS)), user["hash"]):
                raise AIError("Current password is incorrect.", 401)
            salt = secrets.token_bytes(16)
            user.update(salt=salt.hex(), hash=_hash_pw(new, salt), rounds=PBKDF2_ROUNDS)
            self._save_users(users)
            self._drop_sessions(uid, keep=_sha(token))

    def update_profile(self, uid: str, name: str) -> dict:
        with self.lock:
            users = self._users()
            users[uid]["name"] = (name or "").strip()[:60] or users[uid]["name"]
            self._save_users(users)
            return self.public(users[uid])

    def start_reset(self, email: str) -> tuple[dict, str] | None:
        """Return (user, code) or None if no such account."""
        with self.lock:
            user = self._find(self._users(), email or "")
            if not user or user.get("disabled"):
                return None
            code = f"{secrets.randbelow(1_000_000):06d}"
            resets = {k: v for k, v in self._read(self.base / "resets.json", {}).items() if v["exp"] > time.time()}
            resets[user["id"]] = {"hash": _sha(code + user["id"]), "exp": int(time.time() + RESET_MINUTES * 60), "tries": 0}
            self._write(self.base / "resets.json", resets)
            return self.public(user), code

    def finish_reset(self, email: str, code: str, password: str) -> tuple[dict, str]:
        self._check_pw(password)
        with self.lock:
            users = self._users()
            user = self._find(users, email or "")
            resets = self._read(self.base / "resets.json", {})
            entry = resets.get(user["id"]) if user else None
            bad = AIError("That code is wrong or has expired. Request a new one.", 400)
            if not entry or entry["exp"] < time.time() or entry["tries"] >= 5:
                raise bad
            if not hmac.compare_digest(entry["hash"], _sha(str(code).strip() + user["id"])):
                entry["tries"] += 1
                self._write(self.base / "resets.json", resets)
                raise bad
            resets.pop(user["id"], None)
            self._write(self.base / "resets.json", resets)
            salt = secrets.token_bytes(16)
            user.update(salt=salt.hex(), hash=_hash_pw(password, salt), rounds=PBKDF2_ROUNDS)
            self._save_users(users)
            self._drop_sessions(user["id"])
            return self.public(user), self._new_session(user["id"])

    def list_users(self) -> list[dict]:
        return sorted((self.public(u) for u in self._users().values()), key=lambda u: u["created"])

    def admin_update(self, actor: str, uid: str, changes: dict) -> dict:
        with self.lock:
            users = self._users()
            user = users.get(uid)
            if not user:
                raise AIError("User not found.", 404)
            if "role" in changes and changes["role"] in ("admin", "user"):
                if uid == actor and changes["role"] != "admin":
                    raise AIError("You can't remove your own admin role.")
                user["role"] = changes["role"]
            if "tools" in changes:
                user["tools"] = bool(changes["tools"])
            if "disabled" in changes:
                if uid == actor and changes["disabled"]:
                    raise AIError("You can't disable your own account.")
                user["disabled"] = bool(changes["disabled"])
            self._save_users(users)
            if user.get("disabled"):
                self._drop_sessions(uid)
            return self.public(user)

    def delete_user(self, actor: str, uid: str) -> None:
        if uid == actor:
            raise AIError("You can't delete your own account here.")
        with self.lock:
            users = self._users()
            if users.pop(uid, None) is None:
                raise AIError("User not found.", 404)
            self._save_users(users)
            self._drop_sessions(uid)
            folder = self._inside(self.base / "users" / uid)
            shutil.rmtree(folder, ignore_errors=True)

    # ---------- per-user storage ----------
    def _item_path(self, uid: str, kind: str, item_id: str) -> Path:
        if kind not in KINDS or not ID_RE.match(item_id or "") or not ID_RE.match(uid):
            raise AIError("Invalid item.", 400)
        return self._inside(self.base / "users" / uid / kind / f"{item_id}.json")

    def all_items(self, uid: str) -> dict[str, list]:
        out: dict[str, list] = {}
        root = self.base / "users" / uid
        for kind in KINDS:
            items = []
            folder = root / kind
            if folder.is_dir():
                for path in folder.glob("*.json"):
                    if path.is_symlink():
                        continue
                    data = self._read(path, None)
                    if isinstance(data, dict):
                        items.append(data)
            out[kind] = items
        return out

    def put(self, uid: str, kind: str, item_id: str, data: dict) -> int:
        if not isinstance(data, dict):
            raise AIError("Item must be an object.")
        data["id"] = item_id
        raw = json.dumps(data, ensure_ascii=False)
        if len(raw.encode("utf-8")) > MAX_ITEM_BYTES:
            raise AIError("Item is too large (25 MB max).", 413)
        path = self._item_path(uid, kind, item_id)
        if path.is_symlink():
            raise AIError("Invalid item.", 400)
        return self._write(path, data)

    def delete(self, uid: str, kind: str, item_id: str) -> bool:
        path = self._item_path(uid, kind, item_id)
        if path.exists() and not path.is_symlink():
            path.unlink()
            return True
        return False

    def wipe(self, uid: str, kind: str | None) -> int:
        kinds = [kind] if kind else [k for k in KINDS if k != "settings"]
        count = 0
        for k in kinds:
            if k not in KINDS:
                raise AIError("Invalid kind.")
            folder = self._inside(self.base / "users" / uid / k)
            if folder.is_dir():
                for path in folder.glob("*.json"):
                    path.unlink()
                    count += 1
        return count

    def usage(self, uid: str) -> dict[str, Any]:
        root = self.base / "users" / uid
        size = sum(p.stat().st_size for p in root.rglob("*.json")) if root.exists() else 0
        return {"bytes": size, "path": str(root)}
