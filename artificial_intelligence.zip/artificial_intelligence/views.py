"""HTTP API for accounts, settings, per-user storage and integration tools. Accepts an AI login or a Home Assistant token."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import defaultdict, deque
from typing import Any

from aiohttp import web

from homeassistant.components.http import HomeAssistantView
from homeassistant.core import Context, HomeAssistant, SupportsResponse
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.service import async_get_all_descriptions
from homeassistant.loader import async_get_custom_components

from . import mail
from .authz import authenticate
from .const import API, DOMAIN, KINDS, TOKEN_HEADER, VERSION
from .core import AIError
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)
FAILS: dict[str, deque] = defaultdict(deque)
FAIL_LIMIT, FAIL_WINDOW = 10, 900


def _ip(request: web.Request) -> str:
    return request.headers.get("X-Forwarded-For", request.remote or "?").split(",")[0].strip()


def _throttle(request: web.Request) -> None:
    q = FAILS[_ip(request)]
    while q and q[0] < time.time() - FAIL_WINDOW:
        q.popleft()
    if len(q) >= FAIL_LIMIT:
        raise AIError("Too many attempts. Wait 15 minutes and try again.", 429)


def _fail(request: web.Request) -> None:
    FAILS[_ip(request)].append(time.time())


def _app_url(request: web.Request, body: dict) -> str:
    url = str(body.get("app_url") or "")
    if url.startswith(("https://", "http://")) and len(url) < 300 and url.split("?")[0].endswith(".html"):
        return url.split("#")[0].split("?")[0]
    proto = request.headers.get("X-Forwarded-Proto", request.scheme)
    return f"{proto}://{request.host}/local/ai-cloud.html"


class Base(HomeAssistantView):
    """Shared helpers."""

    requires_auth = False
    cors_allowed = False

    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt
        self.core = rt.core

    async def run(self, func, *args):
        return await self.hass.async_add_executor_job(func, *args)

    async def body(self, request: web.Request) -> dict:
        try:
            data = await request.json()
        except (ValueError, UnicodeDecodeError):
            raise AIError("Request body must be JSON.") from None
        if not isinstance(data, dict):
            raise AIError("Request body must be a JSON object.")
        return data

    async def user(self, request: web.Request, admin: bool = False) -> dict:
        """The caller as an account dict: an Artificial Intelligence login, or a Home Assistant token (shown as an account)."""
        user = await self.run(self.core.user_for, request.headers.get(TOKEN_HEADER))
        if not user:
            principal = await authenticate(self.rt, request)
            if principal is not None and principal.kind == "ha":
                uid = "ha" + str(getattr(principal.ha_user, "id", "") or "user")[:32]
                name = principal.name
                user = {"id": uid, "name": name, "email": f"{name} (Home Assistant)",
                        "role": "admin" if principal.is_admin else "user", "tools": True}
        if not user:
            raise AIError("Your session has ended. Log in again.", 401)
        if admin and user["role"] != "admin":
            raise AIError("Only an admin can do that.", 403)
        return user

    async def handle(self, request: web.Request, coro):
        try:
            return self.json(await coro)
        except AIError as err:
            return self.json({"error": str(err)}, status_code=err.status)
        except Exception as err:  # noqa: BLE001
            _LOGGER.exception("artificial_intelligence request failed")
            return self.json({"error": f"Server error: {err}"}, status_code=500)


class StatusView(Base):
    url = f"{API}/status"
    name = f"api:{DOMAIN}:status"

    async def get(self, request):
        async def go():
            cfg = await self.run(self.core.config)
            users = await self.run(self.core.list_users)
            return {"version": VERSION, "has_users": bool(users),
                    "signup_open": (not users) or cfg.get("allow_signup", True),
                    "smtp": bool(await self.rt.smtp())}
        return await self.handle(request, go())


class AuthView(Base):
    url = f"{API}/auth/{{action}}"
    name = f"api:{DOMAIN}:auth"

    async def get(self, request, action):
        async def go():
            if action != "me":
                raise AIError("Not found.", 404)
            return {"user": await self.user(request)}
        return await self.handle(request, go())

    async def post(self, request, action):
        return await self.handle(request, self._post(request, action))

    async def _post(self, request, action) -> Any:
        token = request.headers.get(TOKEN_HEADER)
        if action == "logout":
            await self.run(self.core.logout, token or "")
            return {"ok": True}
        body = await self.body(request)
        if action == "signup":
            _throttle(request)
            user, tok = await self.run(self.core.signup, body.get("email"), body.get("password"), body.get("name"))
            mail_status = "sent"
            smtp = await self.rt.smtp()
            if smtp:
                subject, html_body, text = mail.welcome(user["name"], user["email"], _app_url(request, body))
                try:
                    await self.run(mail.send, smtp, user["email"], subject, html_body, text)
                except RuntimeError as err:
                    _LOGGER.warning("Welcome email failed: %s", err)
                    mail_status = str(err)
            else:
                mail_status = "No SMTP settings found, so no welcome email was sent."
            return {"user": user, "token": tok, "mail": mail_status}
        if action == "login":
            _throttle(request)
            try:
                user, tok = await self.run(self.core.login, body.get("email"), body.get("password"))
            except AIError:
                _fail(request)
                raise
            return {"user": user, "token": tok}
        if action == "forgot":
            _throttle(request)
            _fail(request)  # counts every request, limits email spam
            found = await self.run(self.core.start_reset, body.get("email"))
            if found:
                smtp = await self.rt.smtp()
                if not smtp:
                    raise AIError("Email isn't set up on the server, so a reset code can't be sent.", 503)
                user, code = found
                subject, html_body, text = mail.reset(user["name"], code)
                try:
                    await self.run(mail.send, smtp, user["email"], subject, html_body, text)
                except RuntimeError as err:
                    raise AIError(str(err), 502) from err
            return {"ok": True}
        if action == "reset":
            _throttle(request)
            try:
                user, tok = await self.run(self.core.finish_reset, body.get("email"), body.get("code"), body.get("password"))
            except AIError:
                _fail(request)
                raise
            return {"user": user, "token": tok}
        if action == "password":
            user = await self.user(request)
            await self.run(self.core.change_password, user["id"], body.get("old"), body.get("new"), token)
            return {"ok": True}
        if action == "profile":
            user = await self.user(request)
            return {"user": await self.run(self.core.update_profile, user["id"], body.get("name"))}
        raise AIError("Not found.", 404)


class ConfigView(Base):
    url = f"{API}/config"
    name = f"api:{DOMAIN}:config"

    async def get(self, request):
        async def go():
            user = await self.user(request)
            cfg = await self.run(self.core.config)
            cfg = {k: v for k, v in cfg.items() if k not in ("ollama_key", "base_url")}
            if user["role"] == "admin":
                return cfg
            return {"allow_signup": cfg.get("allow_signup", True)}
        return await self.handle(request, go())

    async def put(self, request):
        async def go():
            await self.user(request, admin=True)
            body = {k: v for k, v in (await self.body(request)).items() if k in ("allow_signup", "enabled_integrations")}
            return await self.run(self.core.set_config, body)
        return await self.handle(request, go())


class StoreAllView(Base):
    url = f"{API}/store"
    name = f"api:{DOMAIN}:store_all"

    async def get(self, request):
        async def go():
            user = await self.user(request)
            return await self.run(self.core.all_items, user["id"])
        return await self.handle(request, go())

    async def delete(self, request):
        async def go():
            user = await self.user(request)
            return {"deleted": await self.run(self.core.wipe, user["id"], None)}
        return await self.handle(request, go())


class StoreKindView(Base):
    url = f"{API}/store/{{kind}}"
    name = f"api:{DOMAIN}:store_kind"

    async def delete(self, request, kind):
        async def go():
            user = await self.user(request)
            return {"deleted": await self.run(self.core.wipe, user["id"], kind)}
        return await self.handle(request, go())


class StoreItemView(Base):
    url = f"{API}/store/{{kind}}/{{item_id}}"
    name = f"api:{DOMAIN}:store_item"

    async def put(self, request, kind, item_id):
        async def go():
            user = await self.user(request)
            size = await self.run(self.core.put, user["id"], kind, item_id, await self.body(request))
            return {"ok": True, "bytes": size}
        return await self.handle(request, go())

    async def delete(self, request, kind, item_id):
        async def go():
            user = await self.user(request)
            return {"ok": await self.run(self.core.delete, user["id"], kind, item_id)}
        return await self.handle(request, go())


class UsersView(Base):
    url = f"{API}/users"
    name = f"api:{DOMAIN}:users"

    async def get(self, request):
        async def go():
            await self.user(request, admin=True)
            return {"users": await self.run(self.core.list_users)}
        return await self.handle(request, go())


class UserView(Base):
    url = f"{API}/users/{{uid}}"
    name = f"api:{DOMAIN}:user"

    async def post(self, request, uid):
        async def go():
            admin = await self.user(request, admin=True)
            return {"user": await self.run(self.core.admin_update, admin["id"], uid, await self.body(request))}
        return await self.handle(request, go())

    async def delete(self, request, uid):
        async def go():
            admin = await self.user(request, admin=True)
            await self.run(self.core.delete_user, admin["id"], uid)
            return {"ok": True}
        return await self.handle(request, go())


def _flatten_fields(fields: dict) -> dict:
    out = {}
    for key, val in (fields or {}).items():
        if isinstance(val, dict) and isinstance(val.get("fields"), dict):  # a collapsible section
            out.update(_flatten_fields(val["fields"]))
        elif isinstance(val, dict):
            out[key] = {k: val.get(k) for k in ("name", "description", "required", "example", "selector", "default") if k in val}
    return out


async def integrations(hass: HomeAssistant, cfg: dict) -> list[dict]:
    custom = await async_get_custom_components(hass)
    descriptions = await async_get_all_descriptions(hass)
    services = hass.services.async_services()
    enabled = set(cfg.get("enabled_integrations", []))
    out = []
    for domain, integ in sorted(custom.items()):
        if domain == DOMAIN:
            continue
        loaded = domain in hass.config.components
        svc_list = []
        for svc in sorted(services.get(domain, {})):
            desc = descriptions.get(domain, {}).get(svc, {}) or {}
            try:
                resp = hass.services.supports_response(domain, svc)
            except Exception:  # noqa: BLE001
                resp = SupportsResponse.NONE
            svc_list.append({"service": svc, "name": desc.get("name") or svc, "description": desc.get("description") or "",
                             "fields": _flatten_fields(desc.get("fields", {})), "target": bool(desc.get("target")),
                             "response": getattr(resp, "value", str(resp))})
        if not loaded:
            reason = "Installed but not loaded, so it isn't running in Home Assistant."
        elif not svc_list:
            reason = "Provides no services, so there's nothing the AI can call."
        else:
            reason = ""
        out.append({"domain": domain, "name": integ.name, "version": str(integ.version or ""),
                    "documentation": integ.documentation or "", "loaded": loaded, "usable": not reason,
                    "reason": reason, "enabled": domain in enabled and not reason, "services": svc_list})
    return out


class IntegrationsView(Base):
    url = f"{API}/integrations"
    name = f"api:{DOMAIN}:integrations"

    async def get(self, request):
        async def go():
            user = await self.user(request)
            cfg = await self.run(self.core.config)
            items = await integrations(self.hass, cfg)
            return {"integrations": items, "can_use": True}
        return await self.handle(request, go())


class IntegrationCallView(Base):
    url = f"{API}/integrations/call"
    name = f"api:{DOMAIN}:integration_call"

    async def post(self, request):
        async def go():
            user = await self.user(request)
            body = await self.body(request)
            domain, service = str(body.get("domain", "")), str(body.get("service", ""))
            data = body.get("data") or {}
            if not isinstance(data, dict):
                raise AIError("Service data must be an object.")
            cfg = await self.run(self.core.config)
            items = {i["domain"]: i for i in await integrations(self.hass, cfg)}
            item = items.get(domain)
            if not item:
                raise AIError(f"{domain} isn't a custom integration.", 404)
            if not item["usable"]:
                raise AIError(f"{item['name']} can't be used: {item['reason']}")
            if not item["enabled"]:
                raise AIError(f"{item['name']} is turned off for the AI. An admin can turn it on in Admin > Integrations.", 403)
            svc = next((s for s in item["services"] if s["service"] == service), None)
            if not svc:
                raise AIError(f"{domain}.{service} doesn't exist.", 404)
            want = svc["response"] in ("optional", "only")
            try:
                async with asyncio.timeout(60):
                    result = await self.hass.services.async_call(domain, service, data, blocking=True,
                                                                 context=Context(), return_response=want)
            except TimeoutError as err:
                raise AIError(f"{domain}.{service} took longer than 60 seconds.", 504) from err
            except (HomeAssistantError, ValueError, TypeError) as err:
                raise AIError(f"{domain}.{service} failed: {err}") from err
            except Exception as err:  # noqa: BLE001  voluptuous.Invalid and friends
                raise AIError(f"{domain}.{service} rejected the data: {err}") from err
            _LOGGER.info("AI tool call %s.%s by %s", domain, service, user["email"])
            return {"ok": True, "response": json.loads(json.dumps(result, default=str)) if result else None}
        return await self.handle(request, go())


class MailTestView(Base):
    url = f"{API}/mail/test"
    name = f"api:{DOMAIN}:mail_test"

    async def post(self, request):
        async def go():
            admin = await self.user(request, admin=True)
            smtp = await self.rt.smtp()
            if not smtp:
                raise AIError("No smtp: settings found under artificial_intelligence: (or the old davai:) in configuration.yaml.", 503)
            subject, html_body, text = mail.welcome(admin["name"], admin["email"], _app_url(request, await self.body(request)))
            try:
                await self.run(mail.send, smtp, admin["email"], "Test: " + subject, html_body, text)
            except RuntimeError as err:
                raise AIError(str(err), 502) from err
            return {"ok": True, "to": admin["email"]}
        return await self.handle(request, go())


ALL_VIEWS = (StatusView, AuthView, ConfigView, StoreAllView, StoreKindView, StoreItemView,
             UsersView, UserView, IntegrationsView, IntegrationCallView, MailTestView)
assert KINDS
