"""AI analysis sensors per channel: summary text and threat level."""
from __future__ import annotations

from typing import Any

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.dispatcher import async_dispatcher_connect
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .hikvision.const import THREAT_LEVELS
from .hikvision.hub import CaiHikvisionHub
from .hikvision.isapi import Channel


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    from .entities import async_setup_extra  # noqa: PLC0415

    if await async_setup_extra(hass, entry, async_add_entities, 1):
        return
    hub: CaiHikvisionHub = entry.runtime_data
    entities: list[SensorEntity] = []
    for ch in hub.channels.values():
        entities += [AISummarySensor(hub, ch), AIThreatSensor(hub, ch)]
    entities.append(OpenQuestionsSensor(hub))
    async_add_entities(entities)


class _AISensor(SensorEntity):
    _attr_has_entity_name = True
    _attr_should_poll = False
    _suffix = ""

    def __init__(self, hub: CaiHikvisionHub, ch: Channel) -> None:
        self._hub = hub
        self._ch = ch
        self._attr_unique_id = f"{hub.uid}_ch{ch.id}_{self._suffix}"
        self._attr_device_info = hub.channel_device_info(ch)

    @property
    def _last(self) -> dict[str, Any] | None:
        return self._hub.last_analysis.get(self._ch.id)

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(
            async_dispatcher_connect(self.hass, self._hub.signal_analysis, self._on_analysis)
        )

    @callback
    def _on_analysis(self, channel: int) -> None:
        if channel == self._ch.id:
            self.async_write_ha_state()


class AISummarySensor(_AISensor):
    _attr_name = "CAI Hikvision AI summary"
    _attr_icon = "mdi:cctv"
    _suffix = "ai_summary"

    @property
    def native_value(self) -> str | None:
        return (self._last or {}).get("summary", "")[:255] or None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        last = self._last
        if not last:
            return {}
        keys = ("time", "trigger", "question", "answer", "people", "vehicles", "animals",
                "activity", "threat_level", "reason", "model", "frames", "duration_s",
                "image_url", "image_api", "threat_source", "trained")
        attrs = {k: last.get(k) for k in keys}
        attrs["event_id"] = last.get("id")
        attrs["recognised"] = [o["identity"] for o in last.get("objects", []) if o.get("identity")]
        attrs["unknown_objects"] = [o.get("description") for o in last.get("objects", []) if not o.get("identity")]
        return attrs


class AIThreatSensor(_AISensor):
    _attr_name = "CAI Hikvision AI threat level"
    _attr_icon = "mdi:shield-alert"
    _attr_device_class = SensorDeviceClass.ENUM
    _attr_options = THREAT_LEVELS
    _suffix = "ai_threat"

    @property
    def native_value(self) -> str | None:
        return (self._last or {}).get("threat_level")

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        last = self._last
        return {"time": last.get("time"), "trigger": last.get("trigger")} if last else {}


class OpenQuestionsSensor(SensorEntity):
    """How many things the camera AI could not identify and is waiting to be taught."""

    _attr_has_entity_name = True
    _attr_should_poll = False
    _attr_name = "CAI Hikvision open questions"
    _attr_icon = "mdi:help-circle"
    _attr_native_unit_of_measurement = "questions"

    def __init__(self, hub: CaiHikvisionHub) -> None:
        self._hub = hub
        self._attr_unique_id = f"{hub.uid}_cai_hikvision_open_questions"
        self._attr_device_info = hub.dvr_device_info()
        self._count = 0

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(async_dispatcher_connect(self.hass, self._hub.signal_questions, self._refresh))
        await self._load()

    @callback
    def _refresh(self) -> None:
        self.hass.async_create_task(self._reload())

    async def _reload(self) -> None:
        await self._load()
        self.async_write_ha_state()

    async def _load(self) -> None:
        training = self._hub.rt.training
        if training is None:
            return
        qs = await self.hass.async_add_executor_job(training.questions)
        self._count = sum(1 for q in qs.values() if q["status"] == "open")

    @property
    def native_value(self) -> int:
        return self._count
