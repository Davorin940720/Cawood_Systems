"""Whole-config file access, SMB shares, custom tools, the terminal in the Home Assistant container and agent token checks."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import secrets
import shutil
import time
import uuid

from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant

from .authz import AuthedView
from .const import API
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)

# roots the AI can reach through the filesystem tools.  "config" is the whole HA
# config dir; smb roots are added at runtime from configuration or the UI.
FS_ROOTS: dict[str, str] = {}
SMB_CONF: dict[str, dict] = {}            # name -> {host, share, path, username, password, ...}
TERM_SESSIONS: dict[str, dict] = {}
AGENTS: dict[str, dict] = {}              # name -> {url, last_seen}
MAX_FS_READ = 200_000
MAX_FS_WRITE = 20_000_000


def _ms(path):
    try:
        return int(os.path.getmtime(path) * 1000)
    except OSError:
        return 0


class _FsErr(Exception):
    pass


def register_root(name: str, path: str):
    FS_ROOTS[name] = os.path.realpath(path)


def _split(vpath: str):
    """'config/foo/bar' -> ('config', 'foo/bar'). Root name then relative path."""
    vpath = str(vpath or "").replace("\\", "/").strip().strip("/")
    if not vpath:
        return "", ""
    parts = vpath.split("/", 1)
    return parts[0], (parts[1] if len(parts) > 1 else "")


def _resolve(vpath: str):
    """Map a virtual path to a real path inside a known root. No escape allowed."""
    root, rel = _split(vpath)
    if not root:
        return None, None, None
    base = FS_ROOTS.get(root)
    if base is None:
        raise _FsErr(f"Unknown location '{root}'. Call fs_list with an empty path to see the available locations.")
    for seg in rel.split("/"):
        if seg in ("..",) or "\x00" in seg:
            raise _FsErr("That path is not allowed")
    full = os.path.realpath(os.path.join(base, rel)) if rel else base
    # allow following symlinks but keep the final target inside the root
    if os.path.commonpath([full, base]) != base:
        raise _FsErr("That path is outside the allowed location")
    return full, base, root


def _entry(path, name=None):
    try:
        st = os.stat(path, follow_symlinks=False)
        isdir = os.path.isdir(path)
        return {"name": name or os.path.basename(path), "type": "dir" if isdir else "file",
                "size": None if isdir else st.st_size, "modified": int(st.st_mtime * 1000),
                "link": os.path.islink(path)}
    except OSError:
        return {"name": name or os.path.basename(path), "type": "file", "size": None, "modified": 0}


def fs_list(vpath):
    if not _split(vpath)[0]:
        return [{"name": n, "type": "dir", "size": None, "modified": 0} for n in FS_ROOTS]
    full, base, root = _resolve(vpath)
    if not os.path.exists(full):
        raise _FsErr("Not found")
    if not os.path.isdir(full):
        return [_entry(full)]
    out = []
    for n in sorted(os.listdir(full), key=str.lower):
        out.append(_entry(os.path.join(full, n), n))
    return out


_TEXT_READ_EXT = {".txt", ".md", ".csv", ".tsv", ".json", ".jsonl", ".yaml", ".yml", ".xml", ".html", ".htm",
                  ".log", ".ini", ".cfg", ".conf", ".toml", ".py", ".ps1", ".psm1", ".sh", ".bash", ".bat",
                  ".cmd", ".js", ".mjs", ".ts", ".css", ".sql", ".tex", ".env", ".service", ".rules", ".j2",
                  ".jinja", ".jinja2", ".properties", ".gitignore", ".dockerfile", ".lua", ".c", ".h", ".cpp"}


def _looks_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in _TEXT_READ_EXT or os.path.basename(path).lower() in ("dockerfile", "makefile"):
        return True
    try:
        with open(path, "rb") as fh:
            chunk = fh.read(4096)
        return b"\x00" not in chunk
    except OSError:
        return False


def fs_read(vpath, offset=0, max_chars=None):
    full, base, root = _resolve(vpath)
    if not os.path.isfile(full):
        raise _FsErr("File not found")
    if not _looks_text(full):
        raise _FsErr(f"'{os.path.basename(full)}' is not a text file, so it cannot be read as text")
    max_chars = max(1000, min(MAX_FS_READ, int(max_chars or MAX_FS_READ)))
    with open(full, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    chunk = text[offset: offset + max_chars]
    return {"path": vpath, "content": chunk, "offset": offset, "total_chars": len(text),
            "truncated": offset + len(chunk) < len(text)}


def fs_write(vpath, content, mode="overwrite", backup=True):
    full, base, root = _resolve(vpath)
    if not _split(vpath)[1]:
        raise _FsErr("Give a file path inside the location")
    if os.path.isdir(full):
        raise _FsErr("That path is a folder")
    if len(content) > MAX_FS_WRITE:
        raise _FsErr("Content is too large")
    existed = os.path.isfile(full)
    if mode == "create" and existed:
        raise _FsErr("File already exists. Use mode 'overwrite' or 'append'.")
    os.makedirs(os.path.dirname(full), exist_ok=True)
    made_backup = None
    if backup and existed and mode != "append":
        made_backup = full + ".cai-bak"
        try:
            shutil.copy2(full, made_backup)
        except OSError:
            made_backup = None
    with open(full, "a" if mode == "append" else "w", encoding="utf-8") as fh:
        fh.write(content)
    return {"ok": True, "path": vpath, "bytes": os.path.getsize(full), "created": not existed, "backup": made_backup}


def fs_mkdir(vpath):
    full, base, root = _resolve(vpath)
    if not _split(vpath)[1]:
        raise _FsErr("Give a folder path inside the location")
    os.makedirs(full, exist_ok=True)
    return {"ok": True, "path": vpath}


def fs_delete(vpath, recursive=False):
    full, base, root = _resolve(vpath)
    if full == base or not _split(vpath)[1]:
        raise _FsErr("The location root cannot be deleted")
    if os.path.isdir(full) and not os.path.islink(full):
        if os.listdir(full) and not recursive:
            raise _FsErr("Folder is not empty. Pass recursive=true to delete it and its contents.")
        shutil.rmtree(full)
    elif os.path.exists(full) or os.path.islink(full):
        os.remove(full)
    else:
        raise _FsErr("Not found")
    return {"ok": True, "path": vpath}


def fs_move(vpath, to_vpath):
    src, _, _ = _resolve(vpath)
    dst, dbase, _ = _resolve(to_vpath)
    if not _split(to_vpath)[1]:
        raise _FsErr("Give a destination path inside a location")
    if not os.path.exists(src):
        raise _FsErr("Source not found")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.move(src, dst)
    return {"ok": True, "from": vpath, "to": to_vpath}


# ----------------------------------------------------------------- SMB shares
def _smb_client():
    import smbclient  # provided by the smbprotocol requirement, installed by Home Assistant
    return smbclient


def mount_or_register_smb(name: str, conf: dict):
    """Try a real CIFS mount; fall back to the smbclient library root."""
    SMB_CONF[name] = conf
    # register as an smb-backed virtual root; the Smb* ops use smbclient directly
    FS_ROOTS["smb:" + name] = "\\\\%s\\%s" % (conf["host"], conf["share"])
    return True


# --------------------------------------------------------- custom tool registry
# Stored in <data>/Chats and Settings/tools.json as a list of definitions the page turns into
# tool schemas. Execution of service/script/webhook kinds happens server-side here.
def _render_template(tmpl, args):
    def sub(m):
        key = m.group(1).strip()
        val = args.get(key, "")
        return val if isinstance(val, str) else json.dumps(val)
    return re.sub(r"\{\{\s*([\w.-]+)\s*\}\}", sub, str(tmpl))


class _ToolErr(Exception):
    pass


# ================================================================= HTTP VIEWS
class _V(AuthedView):
    def _run(self, fn):
        return self.hass.async_add_executor_job(fn)


class Fs2View(_V):
    """Full filesystem for the AI: /config, SMB shares, and whatever roots are registered."""
    url = API + "/fs2"
    name = "api:artificial_intelligence:x_fs2"

    async def get(self, request):
        op = request.query.get("op", "list")
        path = request.query.get("path", "")

        def work():
            if path.startswith("smb:") or _split(path)[0].startswith("smb:"):
                return _smb_op(op, path, request.query)
            if op == "list":
                return {"path": path, "entries": fs_list(path)}
            if op == "read":
                return fs_read(path, max(0, int(request.query.get("offset", 0) or 0)), request.query.get("max_chars"))
            raise _FsErr("Unknown operation")
        try:
            return self.json(await self._run(work))
        except _FsErr as e:
            return self.json_message(str(e), 400)
        except Exception as e:  # noqa: BLE001
            return self.json_message("File error: " + str(e)[:200], 400)

    async def post(self, request):
        b = await request.json()
        op, path = str(b.get("op", "")), b.get("path", "")
        what = {"write": ("Append to " if b.get("mode") == "append" else "Write ") , "mkdir": "Create the folder ", "delete": "Delete ", "move": "Move "}.get(op, op + " ")
        stop = await self.rt.access.check(request, "fs_" + op, str(path), what + str(path) + (f" to {b.get('to')}" if op == "move" else ""),
                                          str(b.get("content", ""))[:1500] if op == "write" else "")
        if stop is None and op == "move":
            stop = await self.rt.access.check(request, "fs_move", str(b.get("to", "")), f"Move {path} to {b.get('to')}")
        if stop is not None:
            return stop

        def work():
            if str(path).startswith("smb:"):
                return _smb_op(op, path, b)
            if op == "write":
                mode = b.get("mode", "overwrite")
                if mode not in ("create", "overwrite", "append"):
                    raise _FsErr("mode must be create, overwrite or append")
                return fs_write(path, str(b.get("content", "")), mode, b.get("backup", True))
            if op == "mkdir":
                return fs_mkdir(path)
            if op == "delete":
                return fs_delete(path, bool(b.get("recursive")))
            if op == "move":
                return fs_move(path, str(b.get("to", "")))
            raise _FsErr("Unknown operation")
        try:
            return self.json(await self._run(work))
        except _FsErr as e:
            return self.json_message(str(e), 400)
        except Exception as e:  # noqa: BLE001
            return self.json_message("File error: " + str(e)[:200], 400)


def _smb_op(op, path, params):
    smb = _smb_client()
    name, rel = _split(path)
    conf = SMB_CONF.get(name[4:] if name.startswith("smb:") else name)
    if not conf:
        raise _FsErr("Unknown SMB share")
    unc = "\\\\%s\\%s" % (conf["host"], conf["share"])
    if conf.get("path"):
        unc += "\\" + conf["path"].strip("\\/").replace("/", "\\")
    if rel:
        unc += "\\" + rel.strip("/").replace("/", "\\")
    reg = {"username": conf.get("username"), "password": conf.get("password")}
    if op == "list":
        out = []
        for e in smb.scandir(unc, **reg):
            out.append({"name": e.name, "type": "dir" if e.is_dir() else "file",
                        "size": None if e.is_dir() else e.stat().st_size, "modified": int(e.stat().st_mtime * 1000)})
        return {"path": path, "entries": sorted(out, key=lambda x: x["name"].lower())}
    if op == "read":
        offset = max(0, int(params.get("offset", 0) or 0))
        mx = max(1000, min(MAX_FS_READ, int(params.get("max_chars") or MAX_FS_READ)))
        with smb.open_file(unc, mode="r", encoding="utf-8", errors="replace", **reg) as fh:
            text = fh.read()
        chunk = text[offset: offset + mx]
        return {"path": path, "content": chunk, "offset": offset, "total_chars": len(text), "truncated": offset + len(chunk) < len(text)}
    if op == "write":
        mode = params.get("mode", "overwrite")
        with smb.open_file(unc, mode="a" if mode == "append" else "w", encoding="utf-8", **reg) as fh:
            fh.write(str(params.get("content", "")))
        return {"ok": True, "path": path}
    if op == "mkdir":
        smb.makedirs(unc, exist_ok=True, **reg)
        return {"ok": True, "path": path}
    if op == "delete":
        try:
            smb.remove(unc, **reg)
        except Exception:  # noqa: BLE001
            smb.rmdir(unc, **reg)
        return {"ok": True, "path": path}
    raise _FsErr("Unknown operation")


class SharesView(_V):
    """Manage SMB shares from the page."""
    url = API + "/shares"
    name = "api:artificial_intelligence:x_shares"

    def _file(self):
        return os.path.join(self.rt.paths.app, "shares.json")

    async def get(self, request):
        def work():
            try:
                with open(self._file(), encoding="utf-8") as fh:
                    data = json.load(fh)
            except (OSError, ValueError):
                data = []
            return [{k: v for k, v in s.items() if k != "password"} | {"hasPassword": bool(s.get("password"))} for s in data]
        return self.json(await self._run(work))

    async def post(self, request):
        b = await request.json()
        shares = b.get("shares")
        if not isinstance(shares, list):
            return self.json_message("shares must be a list", 400)

        def work():
            try:
                with open(self._file(), encoding="utf-8") as fh:
                    old = {x.get("name"): x for x in json.load(fh) if isinstance(x, dict)}
            except (OSError, ValueError):
                old = {}
            clean = []
            for s in shares[:20]:
                if not s.get("name") or not s.get("host") or not s.get("share"):
                    continue
                name = re.sub(r"[^\w .-]", "", str(s["name"]))[:40].strip()
                # a password that is not sent keeps the one already saved under that name
                password = str(s["password"]) if s.get("password") is not None else str((old.get(name) or {}).get("password", ""))
                clean.append({"name": name, "host": str(s["host"]), "share": str(s["share"]),
                              "path": str(s.get("path", "")), "username": str(s.get("username", "")),
                              "password": password})
            os.makedirs(os.path.dirname(self._file()), exist_ok=True)
            tmp = self._file() + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(clean, fh)
            os.replace(tmp, self._file())
            # re-register roots
            for k in [k for k in FS_ROOTS if k.startswith("smb:")]:
                FS_ROOTS.pop(k, None)
            SMB_CONF.clear()
            for s in clean:
                try:
                    mount_or_register_smb(s["name"], s)
                except Exception as e:  # noqa: BLE001
                    _LOGGER.warning("SMB share %s not registered: %s", s["name"], e)
            return len(clean)
        n = await self._run(work)
        return self.json({"ok": True, "count": n})


class SmbTestView(_V):
    url = API + "/shares/test"
    name = "api:artificial_intelligence:x_shares:test"

    async def post(self, request):
        b = await request.json()

        def work():
            smb = _smb_client()
            if b.get("password") is None and b.get("name"):  # testing a saved share: reuse its saved password
                try:
                    with open(os.path.join(self.rt.paths.app, "shares.json"), encoding="utf-8") as fh:
                        saved = next((x for x in json.load(fh) if x.get("name") == b["name"]), {})
                except (OSError, ValueError):
                    saved = {}
                b["password"] = saved.get("password", "")
            unc = "\\\\%s\\%s" % (b["host"], b["share"])
            if b.get("path"):
                unc += "\\" + str(b["path"]).strip("\\/").replace("/", "\\")
            names = [e.name for e in smb.scandir(unc, username=b.get("username"), password=b.get("password"))]
            return {"ok": True, "entries": len(names), "sample": names[:8]}
        try:
            return self.json(await self._run(work))
        except Exception as e:  # noqa: BLE001
            return self.json_message("Could not connect: " + str(e)[:200], 400)


class ToolExecView(_V):
    """Execute a server-side custom tool (HA service, script or webhook)."""
    url = API + "/tool/exec"
    name = "api:artificial_intelligence:x_tool:exec"

    async def post(self, request):
        b = await request.json()
        kind = str(b.get("kind", ""))
        args = b.get("args") or {}
        try:
            if kind in ("service", "script"):
                domain = str(b.get("domain", "")).strip()
                service = str(b.get("service", "")).strip()
                if kind == "script":
                    domain, service = "script", str(b.get("script", "")).strip().replace("script.", "")
                if not re.fullmatch(r"[a-z0-9_]+", domain) or not re.fullmatch(r"[a-z0-9_]+", service):
                    return self.json_message("Invalid service", 400)
                data = b.get("data")
                if not isinstance(data, dict):
                    data = {}
                res = await self.hass.services.async_call(domain, service, data, blocking=True, return_response=b.get("wantResponse", False))
                return self.json({"ok": True, "response": res})
            if kind == "webhook":
                import aiohttp
                from homeassistant.helpers.aiohttp_client import async_get_clientsession
                url = str(b.get("url", ""))
                if not re.match(r"^https?://", url):
                    return self.json_message("Invalid webhook URL", 400)
                method = str(b.get("method", "POST")).upper()
                body = b.get("body")
                session = async_get_clientsession(self.hass)
                async with session.request(method, url, json=body if isinstance(body, (dict, list)) else None,
                                           data=None if isinstance(body, (dict, list)) else body, timeout=aiohttp.ClientTimeout(total=30)) as r:
                    text = await r.text()
                return self.json({"ok": r.status < 400, "status": r.status, "body": text[:4000]})
            return self.json_message("Unknown tool kind", 400)
        except Exception as e:  # noqa: BLE001
            return self.json_message("Tool failed: " + str(e)[:200], 502)


class ExposedScriptsView(_V):
    """List scripts/services exposed to Assist so the page can offer them as tools."""
    url = API + "/exposed_tools"
    name = "api:artificial_intelligence:x_exposed_tools"

    async def get(self, request):
        from homeassistant.helpers import entity_registry as er
        out = []
        try:
            from homeassistant.components.homeassistant.exposed_entities import async_should_expose
            reg = er.async_get(self.hass)
            for ent in reg.entities.values():
                if ent.domain != "script":
                    continue
                try:
                    if not async_should_expose(self.hass, "conversation", ent.entity_id):
                        continue
                except Exception:  # noqa: BLE001
                    continue
                st = self.hass.states.get(ent.entity_id)
                fields = {}
                svc = self.hass.services.async_services().get("script", {}).get(ent.entity_id.split(".", 1)[1])
                if svc and getattr(svc, "schema", None) is not None:
                    pass
                out.append({"entity_id": ent.entity_id,
                            "name": (st.attributes.get("friendly_name") if st else None) or ent.entity_id,
                            "fields": fields})
        except Exception as e:  # noqa: BLE001
            return self.json_message("Could not read exposed scripts: " + str(e)[:150], 500)
        return self.json({"scripts": out})


# ---------------------------------------------------------------- host terminal
class TermView(_V):
    """A shell inside the Home Assistant container. With "stream": true the output comes back line by line while it runs."""
    url = API + "/term"
    name = "api:artificial_intelligence:x_term"

    async def post(self, request):
        b = await request.json()
        action = str(b.get("action", "run"))
        if action != "run":
            return self.json_message("Unknown action", 400)
        cmd = str(b.get("command", ""))
        if not cmd.strip():
            return self.json_message("Empty command", 400)
        stop = await self.rt.access.check(request, "run_command", "ha: " + cmd, "Run on Home Assistant: " + cmd, listable=False)
        if stop is not None:
            return stop
        cwd = b.get("cwd") or self.hass.config.config_dir
        if not os.path.isdir(str(cwd)):
            cwd = self.hass.config.config_dir
        timeout = max(1.0, min(3600.0, float(b.get("timeout", 60) or 60)))
        m = re.fullmatch(r"\s*cd(?:\s+(.+?))?\s*", cmd)
        if m:  # change folder for the next command, like a real terminal
            target = os.path.normpath(os.path.join(str(cwd), os.path.expanduser((m.group(1) or "~").strip().strip('"'))))
            if not os.path.isdir(target):
                return self._reply(b, f"cd: no such folder: {m.group(1)}\n", 1, str(cwd))
            return self._reply(b, "", 0, target)
        try:
            proc = await asyncio.create_subprocess_shell(cmd, cwd=str(cwd), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=dict(os.environ, TERM="dumb"))
        except Exception as e:  # noqa: BLE001
            return self.json_message("Could not start: " + str(e)[:150], 400)
        if not b.get("stream"):
            try:
                out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
                text, code = out.decode("utf-8", "replace"), proc.returncode
            except asyncio.TimeoutError:
                proc.kill()
                text, code = "(timed out)", 124
            return self.json({"ok": True, "code": code, "output": text[-100000:], "cwd": str(cwd)})
        from aiohttp import web  # noqa: PLC0415

        resp = web.StreamResponse(headers={"Content-Type": "application/x-ndjson", "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        await resp.prepare(request)
        code = None
        try:
            async def pump():
                while True:
                    chunk = await proc.stdout.read(4096)
                    if not chunk:
                        break
                    await resp.write((json.dumps({"out": chunk.decode("utf-8", "replace")}) + "\n").encode())
            await asyncio.wait_for(pump(), timeout=timeout)
            code = await proc.wait()
        except asyncio.TimeoutError:
            proc.kill()
            code = 124
            await resp.write((json.dumps({"out": "\n(timed out)\n"}) + "\n").encode())
        except (ConnectionResetError, asyncio.CancelledError):
            proc.kill()
            raise
        await resp.write((json.dumps({"done": True, "code": code, "cwd": str(cwd)}) + "\n").encode())
        await resp.write_eof()
        return resp

    def _reply(self, b, out, code, cwd):
        if not b.get("stream"):
            return self.json({"ok": True, "code": code, "output": out, "cwd": cwd})
        from aiohttp import web  # noqa: PLC0415

        body = (json.dumps({"out": out}) + "\n" if out else "") + json.dumps({"done": True, "code": code, "cwd": cwd}) + "\n"
        return web.Response(body=body.encode(), content_type="application/x-ndjson")


class VerifyView(HomeAssistantView):
    """A machine agent asks: is this token good? Answers ok for a valid Home Assistant token, or for this
    Home Assistant instance's own relay secret (used when an AI login, not a Home Assistant token, drives an agent)."""

    url = API + "/verify"
    name = "api:artificial_intelligence:x_verify"
    requires_auth = False
    cors_allowed = False

    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt

    async def get(self, request):
        from .authz import KEY_AUTHENTICATED, KEY_HASS_USER  # pylint: disable=import-outside-toplevel

        if request.get(KEY_AUTHENTICATED):
            user = request.get(KEY_HASS_USER)
            return self.json({"ok": True, "user": getattr(user, "name", None), "is_admin": bool(getattr(user, "is_admin", False))})
        bearer = (request.headers.get("Authorization") or "").replace("Bearer ", "").strip()
        if bearer and secrets.compare_digest(bearer, self.rt.relay_secret):
            return self.json({"ok": True, "user": "relay", "is_admin": True})
        return self.json({"ok": False, "error": "invalid token"}, status_code=401)


class LegacyVerifyView(VerifyView):
    """Same as /verify, at the path the machine agents already use, so agents keep working without an update."""

    url = "/api/davai/verify"
    name = "api:artificial_intelligence:x_verify_legacy"


SYSTEM_VIEWS = [Fs2View, SharesView, SmbTestView, ToolExecView, ExposedScriptsView, TermView]


def _restore_shares(rt: Runtime) -> None:
    """Re-register the saved SMB shares (runs in a worker thread)."""
    try:
        with open(os.path.join(rt.paths.app, "shares.json"), encoding="utf-8") as fh:
            shares = json.load(fh)
    except (OSError, ValueError):
        return
    for s in shares:
        try:
            mount_or_register_smb(s["name"], s)
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("SMB share %s not registered: %s", s.get("name"), err)


def setup_system(hass: HomeAssistant, rt: Runtime) -> None:
    register_root("config", hass.config.config_dir)
    register_root("_workspace", rt.paths.workspace)   # the AI's scratch folder
    register_root("projects", rt.paths.projects)      # every project: projects/<name>/sources, chats, index
    hass.async_add_executor_job(_restore_shares, rt)  # file and network access: not on the event loop
    for view in SYSTEM_VIEWS:
        hass.http.register_view(view(hass, rt))
    hass.http.register_view(VerifyView(hass, rt))
    hass.http.register_view(LegacyVerifyView(hass, rt))
