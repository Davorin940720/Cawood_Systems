"""Home Assistant control for the AI, usable with an AI login or a Home Assistant token.

Entities and services (exposed entities only), Python running in Home Assistant, and a relay to machine agents so a
signed-in AI user can use a machine's terminal and browser without holding a Home Assistant token.
"""
from __future__ import annotations

import asyncio
import contextlib
import io
import json
import logging
import os
import re
import sys
import textwrap
import time
import traceback
import uuid
from typing import Any

import aiohttp
from aiohttp import web

from homeassistant.core import HomeAssistant

from .authz import AuthedView
from .const import API, DOMAIN
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)
ENTITY_RE = re.compile(r"^[a-z0-9_]+\.[a-z0-9_]+$")
NAME_RE = re.compile(r"^[a-z0-9_]+$")
MAX_OUTPUT = 100_000


def is_exposed(hass: HomeAssistant, entity_id: str) -> bool:
    """True if the entity is exposed to Assist (the same list the voice assistant may use)."""
    try:
        from homeassistant.components.homeassistant.exposed_entities import async_should_expose  # noqa: PLC0415

        return bool(async_should_expose(hass, "conversation", entity_id))
    except Exception:  # noqa: BLE001
        return False


def _camera_note(hass: HomeAssistant, entity_id: str) -> str | None:
    """Camera entities from the Hikvision part are analysed with camera_analyze, not with entity tools."""
    if not entity_id.startswith("camera."):
        return None
    try:
        from homeassistant.helpers import entity_registry as er  # noqa: PLC0415

        ent = er.async_get(hass).async_get(entity_id)
        if ent and ent.platform == DOMAIN:
            return ("This is a Hikvision camera managed by Artificial Intelligence. To look at it, use camera_analyze "
                    "(with its channel) or camera_snapshot. Entity tools cannot see the picture.")
    except Exception:  # noqa: BLE001
        return None
    return None


def _entity_areas(hass: HomeAssistant) -> dict[str, str]:
    """entity_id -> lower-case area name (the entity's own area, else its device's)."""
    from homeassistant.helpers import area_registry as ar, device_registry as dr, entity_registry as er  # noqa: PLC0415

    areas, devices, out = ar.async_get(hass), dr.async_get(hass), {}
    for ent in er.async_get(hass).entities.values():
        area_id = ent.area_id
        if not area_id and ent.device_id and (dev := devices.async_get(ent.device_id)):
            area_id = dev.area_id
        if area_id and (area := areas.async_get_area(area_id)):
            out[ent.entity_id] = area.name.lower()
    return out


def _entity_row(hass: HomeAssistant, state, with_attributes: bool = False) -> dict[str, Any]:
    row: dict[str, Any] = {
        "entity_id": state.entity_id,
        "name": state.attributes.get("friendly_name") or state.entity_id,
        "state": state.state,
        "domain": state.domain,
    }
    if with_attributes:
        attrs = {k: v for k, v in state.attributes.items() if k not in ("entity_picture", "access_token")}
        row["attributes"] = json.loads(json.dumps(attrs, default=str))
        row["last_changed"] = state.last_changed.isoformat()
    if note := _camera_note(hass, state.entity_id):
        row["note"] = note
    return row


class HaEntitiesView(AuthedView):
    url = API + "/ha/entities"
    name = "api:artificial_intelligence:ha_entities"

    async def get(self, request):
        q = (request.query.get("q") or request.query.get("query") or "").strip().lower()
        domain = (request.query.get("domain") or "").strip().lower()
        area = (request.query.get("area") or "").strip().lower()
        areas = _entity_areas(self.hass) if area else {}
        out = []
        for st in self.hass.states.async_all():
            if domain and st.domain != domain:
                continue
            if not is_exposed(self.hass, st.entity_id):
                continue
            if area and area not in areas.get(st.entity_id, ""):
                continue
            if q and q not in st.entity_id.lower() and q not in str(st.attributes.get("friendly_name", "")).lower():
                continue
            out.append(_entity_row(self.hass, st))
            if len(out) >= 300:
                break
        return self.json({"entities": out, "count": len(out), "only_exposed": True})


class HaStateView(AuthedView):
    url = API + "/ha/state"
    name = "api:artificial_intelligence:ha_state"

    async def get(self, request):
        ids = [i.strip() for i in (request.query.get("entity_id") or "").split(",") if i.strip()]
        if not ids or len(ids) > 25 or not all(ENTITY_RE.match(i) for i in ids):
            return self.json({"error": "Give entity_id (up to 25, comma separated)"}, status_code=400)
        out, missing = [], []
        for eid in ids:
            st = self.hass.states.get(eid)
            if st is None or not is_exposed(self.hass, eid):
                missing.append(eid)
            else:
                out.append(_entity_row(self.hass, st, with_attributes=True))
        return self.json({"states": out, "not_found_or_not_exposed": missing})


class HaCallServiceView(AuthedView):
    url = API + "/ha/call_service"
    name = "api:artificial_intelligence:ha_call_service"

    async def post(self, request):
        try:
            body = await request.json()
        except ValueError:
            return self.json({"error": "Body must be JSON"}, status_code=400)
        domain, service = str(body.get("domain", "")).strip(), str(body.get("service", "")).strip()
        if not NAME_RE.match(domain) or not NAME_RE.match(service):
            return self.json({"error": "domain and service must look like light and turn_on"}, status_code=400)
        data = body.get("data") if isinstance(body.get("data"), dict) else {}
        data = dict(data)
        targets: list[str] = []
        for source in (body.get("entity_id"), data.get("entity_id")):
            if isinstance(source, str):
                targets += [t.strip() for t in source.split(",") if t.strip()]
            elif isinstance(source, list):
                targets += [str(t) for t in source]
        if domain == "script" and not targets:
            targets = [f"script.{service}"]
        if not targets:
            return self.json({"error": "Name the entity_id the service should act on."}, status_code=400)
        bad = [t for t in targets if not ENTITY_RE.match(t) or not is_exposed(self.hass, t)]
        if bad:
            return self.json({"error": "Only exposed entities can be controlled. Not allowed or unknown: " + ", ".join(bad)}, status_code=403)
        if targets and "entity_id" not in data and domain != "script":
            data["entity_id"] = targets if len(targets) > 1 else targets[0]
        if not self.hass.services.has_service(domain, service):
            return self.json({"error": f"{domain}.{service} does not exist"}, status_code=404)
        try:
            async with asyncio.timeout(60):
                result = await self.hass.services.async_call(domain, service, data, blocking=True,
                                                             return_response=bool(body.get("want_response")))
        except TimeoutError:
            return self.json({"error": f"{domain}.{service} took longer than 60 seconds"}, status_code=504)
        except Exception as err:  # noqa: BLE001
            return self.json({"error": f"{domain}.{service} failed: {err}"}, status_code=400)
        _LOGGER.info("AI called %s.%s on %s (%s)", domain, service, ", ".join(targets), self.who(request).label)
        return self.json({"ok": True, "response": json.loads(json.dumps(result, default=str)) if result else None})


# ------------------------------------------------------------------ Python
def _tail(text: str) -> str:
    return text[-MAX_OUTPUT:]


class PythonRunView(AuthedView):
    """Run Python code in a separate process using Home Assistant's own interpreter and libraries."""

    url = API + "/python"
    name = "api:artificial_intelligence:python"

    async def post(self, request):
        try:
            body = await request.json()
        except ValueError:
            return self.json({"error": "Body must be JSON"}, status_code=400)
        code = str(body.get("code", ""))
        if not code.strip():
            return self.json({"error": "No code given"}, status_code=400)
        if len(code) > 500_000:
            return self.json({"error": "Code is too long (500,000 characters maximum)"}, status_code=400)
        stop = await self.rt.access.check(request, "python_run", "python: " + code[:200], "Run Python on the Home Assistant machine", code[:1500], listable=False)
        if stop is not None:
            return stop
        try:
            timeout = max(1.0, min(600.0, float(body.get("timeout", 60))))
        except (TypeError, ValueError):
            timeout = 60.0
        paths = self.rt.paths
        cwd = str(body.get("cwd") or "").strip()
        if cwd in ("", "workspace", "_workspace"):
            cwd = paths.workspace
        elif cwd in ("config", "/config"):
            cwd = paths.config_dir
        if not os.path.isdir(cwd):
            return self.json({"error": f"Folder not found: {cwd}"}, status_code=400)
        stdin = body.get("stdin")

        tmpdir = os.path.join(paths.workspace, ".python_run")
        script = os.path.join(tmpdir, f"{uuid.uuid4().hex[:10]}.py")

        def write() -> None:
            os.makedirs(tmpdir, exist_ok=True)
            with open(script, "w", encoding="utf-8") as fh:
                fh.write(code)

        await self.run(write)
        started = time.monotonic()
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8", TERM="dumb",
                   CAI_CONFIG_DIR=paths.config_dir, CAI_WORKSPACE=paths.workspace)
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-u", script, cwd=cwd, env=env,
                stdin=asyncio.subprocess.PIPE if stdin is not None else asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        except Exception as err:  # noqa: BLE001
            await self.run(lambda: os.path.exists(script) and os.remove(script))
            return self.json({"error": "Could not start Python: " + str(err)[:200]}, status_code=400)
        timed_out = False
        try:
            out, _ = await asyncio.wait_for(proc.communicate(str(stdin).encode() if stdin is not None else None), timeout=timeout)
        except asyncio.TimeoutError:
            timed_out = True
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
            out, _ = await proc.communicate()
        finally:
            await self.run(lambda: os.path.exists(script) and os.remove(script))
        text = _tail((out or b"").decode("utf-8", "replace"))
        if timed_out:
            text += f"\n(stopped after {timeout:.0f} seconds)"
        _LOGGER.info("AI ran Python (%d chars, exit %s) for %s", len(code), proc.returncode, self.who(request).label)
        return self.json({"ok": not timed_out and proc.returncode == 0, "exit_code": 124 if timed_out else proc.returncode,
                          "output": text, "seconds": round(time.monotonic() - started, 2), "cwd": cwd})


async def run_in_hass(hass: HomeAssistant, code: str, timeout: float) -> dict[str, Any]:
    """Run code inside Home Assistant itself with the live hass object. `await` works; use `return` for a result."""
    buf = io.StringIO()

    def cprint(*args, **kwargs) -> None:
        kwargs.pop("file", None)
        print(*args, file=buf, **kwargs)

    src = "async def __cai_main(hass, print, asyncio, json, os, time):\n" + textwrap.indent(code, "    ") + "\n    return None\n"
    ns: dict[str, Any] = {}
    try:
        exec(compile(src, "<cai-python-in-hass>", "exec"), ns)  # noqa: S102
        async with asyncio.timeout(timeout):
            value = await ns["__cai_main"](hass, cprint, asyncio, json, os, time)
    except TimeoutError:
        return {"ok": False, "output": _tail(buf.getvalue()) + f"\n(stopped after {timeout:.0f} seconds)", "result": None}
    except BaseException as err:  # noqa: BLE001
        if isinstance(err, (KeyboardInterrupt, SystemExit)):
            raise
        tb = "".join(traceback.format_exception(type(err), err, err.__traceback__))
        return {"ok": False, "output": _tail(buf.getvalue()), "error": tb[-3000:], "result": None}
    result = None
    if value is not None:
        try:
            result = json.loads(json.dumps(value, default=str))
        except (TypeError, ValueError):
            result = repr(value)
    return {"ok": True, "output": _tail(buf.getvalue()), "result": result}


class PythonHassView(AuthedView):
    """Run Python inside Home Assistant with the live hass object (advanced: bad code can slow or crash HA)."""

    url = API + "/python_hass"
    name = "api:artificial_intelligence:python_hass"

    async def post(self, request):
        try:
            body = await request.json()
        except ValueError:
            return self.json({"error": "Body must be JSON"}, status_code=400)
        code = str(body.get("code", ""))
        if not code.strip():
            return self.json({"error": "No code given"}, status_code=400)
        try:
            timeout = max(1.0, min(300.0, float(body.get("timeout", 30))))
        except (TypeError, ValueError):
            timeout = 30.0
        stop = await self.rt.access.check(request, "python_hass", "python_hass: " + code[:200], "Run Python inside Home Assistant", code[:1500], listable=False)
        if stop is not None:
            return stop
        res = await run_in_hass(self.hass, code, timeout)
        _LOGGER.info("AI ran Python inside Home Assistant (%d chars, ok=%s) for %s", len(code), res["ok"], self.who(request).label)
        return self.json(res)


# -------------------------------------------------------------- machine relay
class AgentRelayView(AuthedView):
    """Forward term, browser and file calls to a machine agent (signed with this instance's relay secret), and start updates."""

    url = API + "/agents/{name}/{op}"
    name = "api:artificial_intelligence:agent_relay"
    BROWSER_SAFE = {"goto", "read", "screenshot", "status", "scroll", "back", "forward", "reload", "close"}

    async def post(self, request, name: str, op: str):
        if op not in ("term", "browser", "file", "update"):
            return self.json({"error": "op must be term, browser, file or update"}, status_code=404)
        hub = self.rt.agents
        agent = hub.get(name) if hub else None
        if not agent or not agent.get("url"):
            return self.json({"error": f"No agent named '{name}' is registered"}, status_code=404)
        if op == "update":
            if not self.who(request).is_admin:
                return self.json({"error": "Only an administrator can update agents."}, status_code=403)
            try:
                return self.json({"ok": True, "message": await hub.async_update_agent(agent["name"])})
            except RuntimeError as err:
                return self.json({"error": str(err)}, status_code=502)
        try:
            body = await request.json()
        except ValueError:
            return self.json({"error": "Body must be JSON"}, status_code=400)
        access = self.rt.access
        if op == "term":
            cmd = str(body.get("command", ""))
            stop = await access.check(request, "run_command", f"{agent['name']}: {cmd}", f"Run on {agent['name']}: {cmd}", listable=False)
        elif op == "file" and body.get("op") in ("write", "mkdir", "delete", "move"):
            target = f"agent:{agent['name']}/" + str(body.get("path", "")).replace("\\", "/").lstrip("/")
            stop = await access.check(request, "fs_" + str(body["op"]), target, f"{body['op']} {body.get('path')} on {agent['name']}", str(body.get("content", ""))[:1500])
        elif op == "browser" and str(body.get("action", "")) not in self.BROWSER_SAFE:
            stop = await access.check(request, "browser", f"{agent['name']}: {body.get('action')}", f"Use the browser on {agent['name']}: {body.get('action')} {body.get('selector') or body.get('text') or ''}".strip(), listable=False)
        else:
            stop = None
        if stop is not None:
            return stop
        timeout = 600 if op == "browser" else max(10, min(3700, float(body.get("timeout", 120) or 120) + 15))
        try:
            session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout))
            async with session:
                async with session.post(str(agent["url"]).rstrip("/") + "/" + op, json=body,
                                        headers={"Authorization": "Bearer " + self.rt.relay_secret}) as resp:
                    if op == "term" and body.get("stream") and "ndjson" in resp.headers.get("Content-Type", ""):
                        out = web.StreamResponse(headers={"Content-Type": "application/x-ndjson", "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
                        await out.prepare(request)
                        async for chunk in resp.content.iter_any():
                            await out.write(chunk)
                        await out.write_eof()
                        return out
                    try:
                        data = await resp.json(content_type=None)
                    except (ValueError, aiohttp.ContentTypeError):
                        data = {"error": (await resp.text())[:300]}
                    return self.json(data, status_code=resp.status)
        except (aiohttp.ClientError, asyncio.TimeoutError) as err:
            return self.json({"error": f"Could not reach agent {agent['name']}: {err}"}, status_code=502)


class MailSendView(AuthedView):
    """Send a plain email through the smtp: settings (used by the email tool)."""

    url = API + "/mail/send"
    name = "api:artificial_intelligence:mail_send"

    async def post(self, request):
        from . import mail  # noqa: PLC0415

        smtp = await self.rt.smtp()
        if not smtp:
            return self.json({"error": "Email is not set up. Add the smtp section under artificial_intelligence: in configuration.yaml."}, status_code=503)
        try:
            body = await request.json()
        except ValueError:
            return self.json({"error": "Body must be JSON"}, status_code=400)
        raw = body.get("to")
        to = [t.strip() for t in (raw if isinstance(raw, list) else re.split(r"[,;\s]+", str(raw or ""))) if str(t).strip()]
        if not 1 <= len(to) <= 5 or not all(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", t) for t in to):
            return self.json({"error": "Give between 1 and 5 valid email addresses in 'to'"}, status_code=400)
        subject = " ".join(str(body.get("subject") or "").split())[:200] or "Message"
        text = str(body.get("body") or body.get("text") or "")[:50_000]
        if not text.strip():
            return self.json({"error": "The email body is empty"}, status_code=400)
        import html as htmllib  # noqa: PLC0415

        page = mail._wrap(subject, "<div style=\"white-space:pre-wrap\">" + htmllib.escape(text) + "</div>")  # noqa: SLF001
        try:
            for addr in to:
                await self.run(mail.send, smtp, addr, subject, page, text)
        except RuntimeError as err:
            return self.json({"error": str(err)}, status_code=502)
        _LOGGER.info("AI sent an email to %s for %s", ", ".join(to), self.who(request).label)
        return self.json({"ok": True, "sent_to": to})


HA_VIEWS = (HaEntitiesView, HaStateView, HaCallServiceView, PythonRunView, PythonHassView, AgentRelayView, MailSendView)


def setup_hatools(hass: HomeAssistant, rt: Runtime) -> None:
    for view in HA_VIEWS:
        hass.http.register_view(view(hass, rt))
