"""AI task agents: titles, tags, summaries and camera vision. One per 'AI task agent' added under a service."""
from __future__ import annotations

import json
import logging
import re

from homeassistant.components import ai_task, conversation
from homeassistant.config_entries import ConfigEntry, ConfigSubentry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.device_registry import DeviceEntryType, DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CONF_ENTRY_TYPE, CONF_PROMPT, CONF_VISION, DOMAIN, ENTRY_BACKEND, ENTRY_SERVICE, SUB_AI_TASK
from .llm_bridge import agent_params, chatlog_messages
from .providers import ProviderError
from .runtime import get_runtime

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    if entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND) != ENTRY_SERVICE:
        return
    for sub in (entry.subentries or {}).values():
        if sub.subentry_type == SUB_AI_TASK:
            async_add_entities([AgentTask(entry, sub)], config_subentry_id=sub.subentry_id)


def parse_json(text: str):
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", (text or "").strip(), flags=re.I)
    try:
        return json.loads(t)
    except ValueError:
        a, b = t.find("{"), t.rfind("}")
        if a != -1 and b > a:
            return json.loads(t[a:b + 1])
        raise


class AgentTask(ai_task.AITaskEntity):
    _attr_has_entity_name = True
    _attr_name = None

    def __init__(self, entry: ConfigEntry, sub: ConfigSubentry) -> None:
        self.entry = entry
        self.sub = sub
        self._attr_unique_id = sub.subentry_id
        feats = ai_task.AITaskEntityFeature.GENERATE_DATA
        if sub.data.get(CONF_VISION) and hasattr(ai_task.AITaskEntityFeature, "SUPPORT_ATTACHMENTS"):
            feats |= ai_task.AITaskEntityFeature.SUPPORT_ATTACHMENTS
        self._attr_supported_features = feats
        self._attr_device_info = DeviceInfo(identifiers={(DOMAIN, sub.subentry_id)}, name=sub.title, manufacturer=entry.title,
                                            model=sub.data.get("model"), entry_type=DeviceEntryType.SERVICE, via_device=(DOMAIN, entry.entry_id))

    async def _async_generate_data(self, task: ai_task.GenDataTask, chat_log: conversation.ChatLog) -> ai_task.GenDataTaskResult:
        client = get_runtime(self.hass).providers.get(self.entry.entry_id)
        if client is None:
            raise HomeAssistantError(f"The service {self.entry.title} is not loaded.")
        msgs = await chatlog_messages(self.hass, chat_log, bool(self.sub.data.get(CONF_VISION)), self.sub.data.get(CONF_PROMPT) or "")
        params = agent_params(self.sub.data)
        if task.structure:
            params["json"] = True
            msgs.append({"role": "system", "content": "Reply with one JSON object only, no other text."})
        try:
            reply = await client.complete(self.sub.data["model"], msgs, None, params)
        except ProviderError as err:
            raise HomeAssistantError(str(err)) from err
        text = reply["content"]
        chat_log.async_add_assistant_content_without_tools(conversation.AssistantContent(agent_id=self.entity_id, content=text))
        data = text
        if task.structure:
            try:
                data = parse_json(text)
            except ValueError as err:
                raise HomeAssistantError("The model did not return valid JSON.") from err
        return ai_task.GenDataTaskResult(conversation_id=chat_log.conversation_id, data=data)
