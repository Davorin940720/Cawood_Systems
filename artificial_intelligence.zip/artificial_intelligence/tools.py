"""One registry of every tool the AI has, with a capabilities guide so any model knows exactly how each one works.

GET  /api/artificial_intelligence/tools           -> {tools, guide, context}; the pages send `guide` as part of the system prompt
GET  /api/artificial_intelligence/tools/describe  -> detailed how-to for one topic (also the describe_capabilities tool)

Each tool carries an `x-cai` route: how cai-tools.js executes it with the caller's own credentials. The routes point at the
endpoints of this integration, so a page needs no tool-specific code.
"""
from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

from homeassistant.core import HomeAssistant

from .authz import AuthedView
from .const import API, VERSION
from .hikvision.api import HIK
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)


def _t(name: str, group: str, desc: str, props: dict | None = None, required: list[str] | None = None, route: dict | None = None) -> dict:
    return {
        "type": "function",
        "function": {"name": name, "description": desc, "parameters": {"type": "object", "properties": props or {}, "required": required or []}},
        "x-cai": route or {},
        "group": group,
    }


_S = {"type": "string"}
_I = {"type": "integer"}
_B = {"type": "boolean"}
_LEVEL = {"type": "string", "enum": ["none", "low", "medium", "high"]}


def _camera_tools(cam_hint: str) -> list[dict]:
    channel = {"type": "integer", "description": "Camera number or stream number (1 or 101 both work)." + cam_hint}
    dvr = {"type": "string", "description": "Recorder name. Omit when there is only one."}
    return [
        _t("camera_list", "cameras",
           "List the Hikvision security cameras with live detection states (motion, line crossing, intrusion), alarm status and the latest AI analysis of each camera. START HERE for any camera question." + cam_hint,
           {"dvr": dvr}, route={"method": "GET", "path": HIK + "/cameras", "send": "query"}),
        _t("camera_analyze", "cameras",
           "LOOK AT A CAMERA RIGHT NOW. Captures live frames and returns an AI vision analysis: summary, people/vehicles/animals, who was recognised by name, threat level, and a direct answer to your question. "
           "Use for 'analyse the front door camera', 'is anyone at the gate', 'is my car in the driveway'. Never use entity tools for this." + cam_hint,
           {"channel": channel, "question": {"type": "string", "description": "What you want to know about the scene. Optional."},
            "frames": {"type": "integer", "description": "Frames to capture, 1-5. Use 3 or more to judge movement."}, "dvr": dvr},
           ["channel"], route={"method": "POST", "path": HIK + "/analyze", "send": "body"}),
        _t("camera_events", "cameras",
           "History of camera activity: the logged AI analyses (with event_id, summary, threat level, recognised people, unknown objects) and raw detections. Use for 'what happened overnight', 'any activity at the front today', 'who came to the door'." + cam_hint,
           {"channel": {"type": "integer", "description": "Optional camera filter." + cam_hint}, "since_hours": {"type": "number", "description": "Only the last N hours."},
            "limit": {"type": "integer", "description": "Maximum analyses to return (default 20)."}, "dvr": dvr},
           route={"method": "GET", "path": HIK + "/events", "send": "query"}),
        _t("camera_snapshot", "cameras",
           "Fetch a live still image from a camera so you can look at it yourself. Only useful if you can see images. camera_analyze is better for most questions." + cam_hint,
           {"channel": channel, "dvr": dvr}, ["channel"],
           route={"method": "GET", "path": HIK + "/snapshot/{channel}", "send": "query", "fixed": {"format": "base64"}, "returns_image": True}),
        _t("camera_known", "cameras",
           "Everyone and everything the camera AI has been taught: name, kind, description, usual threat level and how often each was seen. Use before answering 'who is X' or when asked what the camera knows.",
           route={"method": "GET", "path": HIK + "/entities", "send": "query"}),
        _t("camera_teach", "cameras",
           "Teach the camera AI by correcting one logged analysis (get the event_id from camera_events). You can fix the description (summary), the threat_level, add a note, and name the objects in the picture "
           "(objects: [{id, identity: 'Davorin Cawood'}]). Named objects are remembered with a reference photo and recognised next time. Set remember_threat true to make the threat level a standing rule for that person or camera.",
           {"event_id": _S, "summary": {"type": "string", "description": "The corrected description, with real names."}, "threat_level": _LEVEL, "note": _S,
            "remember_threat": {"type": "boolean", "description": "Keep this threat level for the people involved (or for unknown people on this camera)."},
            "objects": {"type": "array", "description": "Objects to name or fix. Use the object ids from camera_events.",
                        "items": {"type": "object", "properties": {"id": _S, "identity": {"type": "string", "description": "Who or what it is. Empty clears it."}, "description": _S,
                                                                   "kind": {"type": "string", "enum": ["person", "vehicle", "animal", "other"]}}}}},
           ["event_id"], route={"method": "PUT", "path": HIK + "/events/{event_id}", "send": "body"}),
        _t("camera_questions", "cameras",
           "The questions the camera AI is waiting to have answered, such as 'Who is the unknown child in a pink shirt?'. Each has a question_id, the camera, the event and a description of the object.",
           {"status": {"type": "string", "enum": ["open", "answered", "dismissed", "all"]}, "channel": _I},
           route={"method": "GET", "path": HIK + "/questions", "send": "query"}),
        _t("camera_answer", "cameras",
           "Answer one camera question (from camera_questions). Say who or what it is, for example 'Emma' or 'Davorin Cawood'. The camera AI will recognise them from now on.",
           {"question_id": _S, "answer": _S}, ["question_id", "answer"],
           route={"method": "POST", "path": HIK + "/questions/{question_id}", "send": "body"}),
        _t("camera_rules", "cameras", "List the owner's threat rules for the camera AI (for example 'unknown person at night = high').",
           route={"method": "GET", "path": HIK + "/rules", "send": "query"}),
        _t("camera_set_rule", "cameras",
           "Add a threat rule for the camera AI. who: 'unknown', 'known' or 'any' (or an id from camera_known). kind: person, vehicle, animal, any or scene. Optional channels, time window (time_from and time_to as HH:MM) and level. Rules beat the model's own threat level.",
           {"who": _S, "kind": _S, "channels": {"type": "array", "items": _I}, "time_from": _S, "time_to": _S, "level": _LEVEL, "label": _S}, ["level"],
           route={"method": "POST", "path": HIK + "/rules", "send": "body"}),
    ]


def _ha_tools() -> list[dict]:
    return [
        _t("ha_list_entities", "home_assistant",
           "List Home Assistant entities exposed to the voice assistant, with state and area. Filter by domain (light, switch, climate, sensor, cover, lock, media_player...), area or text. "
           "This does NOT analyse cameras: use camera_analyze for that. Only exposed entities are listed.",
           {"domain": _S, "area": _S, "query": {"type": "string", "description": "Text to match in the name or entity id"}},
           route={"method": "GET", "path": API + "/ha/entities", "send": "query"}),
        _t("ha_get_state", "home_assistant", "Get the current state and attributes of exposed entities (several separated by commas).",
           {"entity_id": _S}, ["entity_id"], route={"method": "GET", "path": API + "/ha/state", "send": "query"}),
        _t("ha_call_service", "home_assistant",
           "Control exposed entities by calling a Home Assistant service, e.g. domain light, service turn_on, entity_id light.kitchen, data {\"brightness_pct\": 50}. Only exposed entities. For anything else use python_hass.",
           {"domain": _S, "service": _S, "entity_id": {"type": "string", "description": "Entity id, or several separated by commas"}, "data": {"type": "object"}},
           ["domain", "service", "entity_id"], route={"method": "POST", "path": API + "/ha/call_service", "send": "body"}),
        _t("integration_list", "home_assistant",
           "List the custom integrations installed in Home Assistant and the services each offers (with fields). Use before integration_call.",
           route={"method": "GET", "path": API + "/integrations", "send": "query"}),
        _t("integration_call", "home_assistant",
           "Call a service of an enabled custom integration, e.g. domain 'artificial_intelligence', service 'cai_hikvision_get_events'. Check integration_list for the fields first.",
           {"domain": _S, "service": _S, "data": {"type": "object"}}, ["domain", "service"],
           route={"method": "POST", "path": API + "/integrations/call", "send": "body"}),
    ]


def _file_tools() -> list[dict]:
    p = {"path": {"type": "string", "description": 'e.g. "", "config", "config/custom_components", "smb:NAS/folder", "_workspace/notes.txt"'}}
    return [
        _t("fs_list", "files", "List a folder. An empty path lists every location: config (the Home Assistant /config folder), projects (all projects, sources are in projects/<name>/sources), _workspace (your scratch folder) and SMB network shares (smb:Name).",
           p, route={"method": "GET", "path": API + "/fs2", "send": "query", "fixed": {"op": "list"}}),
        _t("fs_read", "files", "Read a text file. Long files come in parts: pass offset to continue.",
           {**p, "offset": {"type": "integer", "description": "Character offset to continue from"}}, ["path"],
           route={"method": "GET", "path": API + "/fs2", "send": "query", "fixed": {"op": "read"}}),
        _t("fs_write", "files", "Create or change a text file. The previous version is backed up. mode: create (fails if it exists), overwrite or append.",
           {**p, "content": _S, "mode": {"type": "string", "enum": ["create", "overwrite", "append"]}}, ["path", "content"],
           route={"method": "POST", "path": API + "/fs2", "send": "body", "fixed": {"op": "write"}}),
        _t("fs_mkdir", "files", "Create a folder.", p, ["path"], route={"method": "POST", "path": API + "/fs2", "send": "body", "fixed": {"op": "mkdir"}}),
        _t("fs_move", "files", "Move or rename a file or folder.", {**p, "to": _S}, ["path", "to"],
           route={"method": "POST", "path": API + "/fs2", "send": "body", "fixed": {"op": "move"}}),
        _t("fs_delete", "files", "Delete a file or folder. Pass recursive true for a non-empty folder.", {**p, "recursive": _B}, ["path"],
           route={"method": "POST", "path": API + "/fs2", "send": "body", "fixed": {"op": "delete"}}),
    ]


def _machine_tools(machines: str) -> list[dict]:
    m = {"type": "string", "description": 'Agent name, or "ha" for the Home Assistant container.' + machines}
    return [
        _t("list_machines", "terminal", "List the machines you can run commands and a browser on: Home Assistant itself plus every registered agent.",
           route={"method": "GET", "path": API + "/agents", "send": "query"}),
        _t("run_command", "terminal",
           "Run a shell command on a machine and return its output and exit code. machine 'ha' (the default) is the Home Assistant container; any other value is an agent name from list_machines. Ask the user before destructive commands." + machines,
           {"command": _S, "machine": m, "cwd": {"type": "string", "description": "Working folder"}, "timeout": {"type": "integer", "description": "Seconds, default 120"}},
           ["command"], route={"special": "run_command"}),
        _t("python_run", "terminal",
           "Run Python code on the Home Assistant machine, in a separate process with Home Assistant's own Python and libraries (homeassistant, aiohttp, yaml, PIL...). Use print() for output. "
           "It cannot see the live hass object: use python_hass for that. Working folder defaults to the _workspace folder; pass cwd 'config' for /config.",
           {"code": _S, "cwd": _S, "timeout": {"type": "integer", "description": "Seconds, default 60, maximum 600"}, "stdin": _S}, ["code"],
           route={"method": "POST", "path": API + "/python", "send": "body"}),
        _t("python_hass", "terminal",
           "Run Python INSIDE the running Home Assistant with the live `hass` object (hass.states, hass.services, registries, hass.config). Top-level `await` works, print() is captured, and `return value` gives a result. "
           "Example: `return {s.entity_id: s.state for s in hass.states.async_all('light')}`. This is the full-power route: use it for entities that are not exposed, registries and anything the other tools cannot do. Bad code can slow Home Assistant, so keep it short and read-only unless asked to change something.",
           {"code": _S, "timeout": {"type": "integer", "description": "Seconds, default 30, maximum 300"}}, ["code"],
           route={"method": "POST", "path": API + "/python_hass", "send": "body"}),
        _t("browser", "terminal",
           "Control a real web browser on a machine where an agent is running (not on Home Assistant). actions: goto (url), click (selector), type (selector, text), press (key), read (page text), eval (script), screenshot, close. Returns the page url, title and visible text.",
           {"action": {"type": "string", "enum": ["goto", "click", "type", "press", "read", "eval", "screenshot", "close"]}, "url": _S, "selector": _S, "text": _S, "key": _S, "script": _S, "machine": m},
           ["action"], route={"special": "browser"}),
    ]


def _project_tools() -> list[dict]:
    return [
        _t("project_list", "projects", "List the projects (folders of sources and chats) with their names, descriptions and source titles.",
           route={"method": "GET", "path": API + "/projects", "send": "query"}),
        _t("project_search", "projects",
           "Search a project's sources (documents, PDFs, notes) for what is relevant to a query and return the best passages. folder is the project folder name from project_list.",
           {"folder": _S, "query": _S, "budget": {"type": "integer", "description": "Maximum characters to return (1000-60000)"}}, ["folder", "query"],
           route={"method": "POST", "path": API + "/projects/{folder}/context", "send": "body"}),
        _t("project_share_email", "projects",
           "Email a project to up to 5 addresses, with a time-limited link to its sources. to is comma separated; linkHours is how long the link works (default 168).",
           {"folder": _S, "to": _S, "linkHours": _I}, ["folder", "to"],
           route={"method": "POST", "path": API + "/projects/{folder}/share", "send": "body", "inject": {"baseUrl": "$origin"}}),
    ]


def _mail_tools() -> list[dict]:
    return [
        _t("email_send", "email", "Send a plain email through the server's mail account. to is up to 5 addresses, comma separated.",
           {"to": _S, "subject": _S, "body": _S}, ["to", "subject", "body"], route={"method": "POST", "path": API + "/mail/send", "send": "body"}),
    ]


def _meta_tools() -> list[dict]:
    return [
        _t("describe_capabilities", "meta",
           "Explain exactly how a group of tools works, with examples and common mistakes. topic: cameras, home_assistant, files, terminal, projects, email, teaching or all. Call this whenever you are unsure which tool to use or how it behaves.",
           {"topic": {"type": "string", "enum": ["all", "cameras", "teaching", "home_assistant", "files", "terminal", "projects", "email"]}},
           route={"method": "GET", "path": API + "/tools/describe", "send": "query"}),
    ]


# ---------------------------------------------------------------- guide text
GUIDE = """You are connected to Home Assistant through the Artificial Intelligence integration. You have tools. Use the RIGHT tool; the rules below say which.

ROUTING RULES (follow them exactly)
1. Anything about a security camera, the DVR/NVR, CCTV, "the front door camera", "who is at the gate", "what happened overnight": use the camera_* tools. camera_analyze looks at the camera right now and tells you what it sees (and who, by name). camera_events is the history. NEVER use ha_list_entities, ha_get_state or python_hass to look at a camera: camera entities only hold a still picture and have no analysis.
2. Camera numbers: a camera can be given as its number (1) or its stream number (101). Both work. If you are unsure which camera the user means, call camera_list first.
3. Controlling devices (lights, switches, climate, covers, locks, media players): ha_list_entities to find them, then ha_call_service. These only see entities exposed to the voice assistant. For anything not exposed, or for registries and automations, use python_hass.
4. Files: fs_* tools. Paths start with a location: config (the /config folder), projects (all projects), _workspace (your scratch folder) or smb:ShareName (network shares). Start with fs_list with an empty path to see them. Read before you write; ask before deleting.
5. Commands: run_command runs a shell command. machine "ha" is the Home Assistant container; other machines are agents (list_machines). The browser tool only works on agent machines.
6. Python: python_run runs Python in a separate process with Home Assistant's interpreter (no live hass object). python_hass runs inside Home Assistant with the live hass object and can use await. Choose python_hass when you need live state, registries or services; python_run for data crunching and scripts.
7. Projects: project_list shows the projects; project_search finds passages in a project's sources. Use it before answering questions about a project's documents.
8. Email: email_send for a plain email; project_share_email to share a project.
9. Teaching the camera AI: when the user tells you who someone in a camera picture is, or corrects a description or threat level, call camera_events to find the event, then camera_teach. Open questions from the camera AI are in camera_questions; answer them with camera_answer when the user tells you.
10. If a tool returns an error, read it, fix the call and try once more. Say plainly what failed. Never invent results and never claim you did something a tool did not confirm.
11. If you are unsure how a tool works, call describe_capabilities with the topic.

Tools and what each is for:
{tool_lines}
{context}"""

TOPICS: dict[str, str] = {
    "cameras": """CAMERAS (Hikvision DVR/NVR through Artificial Intelligence)
What exists: one or more recorders, each with cameras. Every camera has motion, line crossing, intrusion, tamper and video loss detectors, and an AI that analyses pictures with a vision model. Everything is logged: time, camera, snapshot, AI description, threat level (none, low, medium, high), who was recognised, and which objects were unknown.
How to use it:
- "Analyse the front door camera" -> camera_list (to find its number if you do not know it), then camera_analyze with channel and, if the user asked something specific, a question. The result has summary, answer, people, vehicles, animals, objects (each with a description and, when recognised, a name), threat_level and reason. Tell the user the summary, the names of anyone recognised, and the threat level.
- "What happened overnight / today at the gate" -> camera_events with channel and since_hours.
- "Show me" a picture -> camera_snapshot (only if you can see images).
- Detection state "is there motion right now" -> camera_list (detections_active).
Common mistakes: asking ha_list_entities for the camera (it cannot analyse); guessing a camera number (call camera_list); reporting a threat level without saying why (use the reason field).
Camera numbers can be 1 or 101, both are accepted.""",
    "teaching": """TEACHING THE CAMERA AI
The camera AI learns from the owner without any model training: names with reference photos, corrected descriptions, threat rules, and answers to questions are stored on the server and used in every later analysis.
- Name someone: camera_events -> find the event and the object id -> camera_teach with objects [{id, identity: "Davorin Cawood"}]. Next time that person is seen the summary says "Davorin Cawood is walking towards the camera".
- Fix a description: camera_teach with summary (the corrected text, with real names).
- Fix the threat level: camera_teach with threat_level; add remember_threat true to keep it for those people (or for unknown people on that camera).
- Standing rules: camera_set_rule, for example who unknown, kind person, channels [1], time_from 22:00, time_to 06:00, level high.
- Questions: the AI asks about unknowns ("Who is the unknown child in a pink shirt?"). camera_questions lists them, camera_answer answers one.
- What it knows: camera_known.
The owner can also do all of this on cai_hik_config.html.""",
    "home_assistant": """HOME ASSISTANT
- ha_list_entities: exposed entities only (the same ones the voice assistant sees). Filter with domain, area, query.
- ha_get_state: state and attributes of up to 25 exposed entities.
- ha_call_service: domain, service and entity_id of exposed entities, plus optional data. Check the entity is exposed with ha_list_entities first.
- integration_list / integration_call: services of custom integrations.
- python_hass: the full-power route (live hass object). Examples: `return hass.states.get('sensor.x').as_dict()`, `await hass.services.async_call('light','turn_on',{'entity_id':'light.x'},blocking=True)`, reading the entity registry.
Cameras are NOT analysed with these tools: use camera_analyze.""",
    "files": """FILES
fs_list "" shows every location. config is the Home Assistant /config folder (configuration.yaml, custom_components, www...). projects holds every project (projects/<name>/sources has its documents). _workspace is your scratch folder. smb:Name is a network share the owner has set up.
fs_read returns parts of large files: use offset to continue. fs_write modes: create (fails if the file exists), overwrite, append; a backup of the old version is kept. Be careful in config: a bad configuration.yaml can stop Home Assistant starting, so show the owner the change first.""",
    "terminal": """COMMANDS, PYTHON AND BROWSER
- list_machines shows where you can run things.
- run_command: machine "ha" (default) runs in the Home Assistant container; an agent name runs on that computer (Windows, Linux or Mac). Output and exit code are returned.
- python_run: Python in a separate process on the Home Assistant machine with HA's libraries. print() for output.
- python_hass: Python inside Home Assistant with the live hass object; await works; use return for a result.
- browser: drives a real browser on an agent machine: goto, click, type, press, read, eval, screenshot.""",
    "projects": """PROJECTS
A project is a folder of sources (documents, PDFs, notes) and chats. project_list shows them. project_search(folder, query) returns the most relevant passages from the sources, so use it before answering questions about a project. project_share_email emails a project to up to 5 people with a link that expires.""",
    "email": """EMAIL
email_send(to, subject, body) sends a plain email through the server's mail account. It fails with a clear message when email is not set up. project_share_email shares a project.""",
}


def _machines(rt: Runtime) -> list[dict]:
    try:
        with open(os.path.join(rt.paths.app, "agents.json"), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return []
    return [{"name": k, "os": (v.get("info") or {}).get("os_name") or v.get("os"), "caps": v.get("caps", [])} for k, v in data.items()]


async def build_context(rt: Runtime) -> dict[str, Any]:
    cams = []
    for hub in rt.hubs.values():
        for ch in hub.channels.values():
            cams.append({"channel": ch.id, "stream": ch.stream_id, "name": ch.name, "dvr": hub.name})
    machines = await rt.hass.async_add_executor_job(_machines, rt)
    smtp = bool(await rt.smtp())
    known = open_q = 0
    if rt.training is not None:
        known = len(await rt.hass.async_add_executor_job(rt.training.entities))
        qs = await rt.hass.async_add_executor_job(rt.training.questions)
        open_q = sum(1 for q in qs.values() if q["status"] == "open")
    mcp = rt.mcp.registry_tools() if rt.mcp else []
    return {"cameras": cams, "machines": machines, "email_ready": smtp, "known_entities": known, "open_questions": open_q, "mcp_tools": mcp}


def _context_text(ctx: dict[str, Any]) -> str:
    lines = ["", "RIGHT NOW"]
    if ctx["cameras"]:
        lines.append("Cameras: " + "; ".join(f"{c['channel']} = {c['name']} (stream {c['stream']}" + (f", recorder {c['dvr']}" if len({x["dvr"] for x in ctx["cameras"]}) > 1 else "") + ")" for c in ctx["cameras"]) + ".")
        lines.append(f"The camera AI knows {ctx['known_entities']} named people, vehicles or animals and has {ctx['open_questions']} open questions.")
    else:
        lines.append("Cameras: none are set up or loaded, so camera_* tools will report that.")
    names = ", ".join(m["name"] for m in ctx["machines"]) or "none registered"
    lines.append(f"Machines: Home Assistant (machine \"ha\") plus agents: {names}.")
    lines.append("Email: " + ("ready." if ctx["email_ready"] else "not set up, email_send will fail."))
    return "\n".join(lines)


def _all_tools(ctx: dict[str, Any]) -> list[dict]:
    cams = "; ".join(f"{c['channel']}={c['name']}" for c in ctx["cameras"])
    cam_hint = f" Cameras (number=name): {cams}." if cams else ""
    machines = " Agents: " + ", ".join(m["name"] for m in ctx["machines"]) + "." if ctx["machines"] else ""
    return (_camera_tools(cam_hint) + _ha_tools() + _file_tools() + _machine_tools(machines) + _project_tools() + _mail_tools() + _meta_tools()
            + list(ctx.get("mcp_tools") or []))


def build_guide(tools: list[dict], ctx: dict[str, Any]) -> str:
    lines = "\n".join(f"- {t['function']['name']}: {re.split(r'(?<!e.g)(?<!i.e)[.] ', t['function']['description'], maxsplit=1)[0].rstrip('.')}." for t in tools)
    return GUIDE.replace("{tool_lines}", lines).replace("{context}", _context_text(ctx))


def describe(topic: str) -> str:
    topic = (topic or "all").lower().strip()
    if topic == "all":
        return "\n\n".join(TOPICS.values())
    key = {"camera": "cameras", "hikvision": "cameras", "training": "teaching", "ha": "home_assistant", "home": "home_assistant",
           "file": "files", "shell": "terminal", "python": "terminal", "browser": "terminal", "mail": "email", "project": "projects"}.get(topic, topic)
    return TOPICS.get(key) or f"Unknown topic '{topic}'. Topics: " + ", ".join(TOPICS) + ", all."


class ToolsView(AuthedView):
    url = API + "/tools"
    name = "api:artificial_intelligence:tools"

    async def get(self, request):
        ctx = await build_context(self.rt)
        tools = _all_tools(ctx)
        ctx_out = {k: v for k, v in ctx.items() if k != "mcp_tools"}
        return self.json({"version": VERSION, "tools": tools, "guide": build_guide(tools, ctx), "context": ctx_out})


class DescribeView(AuthedView):
    url = API + "/tools/describe"
    name = "api:artificial_intelligence:tools_describe"

    async def get(self, request):
        return self.json({"topic": request.query.get("topic") or "all", "text": describe(request.query.get("topic") or "all")})


def setup_tools(hass: HomeAssistant, rt: Runtime) -> None:
    for view in (ToolsView, DescribeView):
        hass.http.register_view(view(hass, rt))
