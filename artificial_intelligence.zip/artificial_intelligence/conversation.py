"""Conversation agents: one per 'conversation agent' added under a service, plus the Boss AIs. Usable in Assist pipelines and voice."""
from __future__ import annotations

import logging
from typing import Literal

from homeassistant.components import conversation
from homeassistant.config_entries import ConfigEntry, ConfigSubentry
from homeassistant.const import MATCH_ALL
from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.device_registry import DeviceEntryType, DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    CONF_ENTRY_TYPE, CONF_LLM_HASS_API, CONF_PRIMARY_PROMPT, CONF_PROMPT, CONF_TOOLS, CONF_VISION, DOMAIN, ENTRY_BACKEND, ENTRY_SERVICE,
    PRESETS, SUB_BOSS, SUB_CONVERSATION, CONF_PRESET,
)
from .llm_bridge import MAX_TOOL_ROUNDS, agent_params, boss_primary, chatlog_messages, format_tools, provide_llm_data, to_delta_stream
from .providers import ProviderError
from .runtime import get_runtime

_LOGGER = logging.getLogger(__name__)


def service_device(entry: ConfigEntry) -> DeviceInfo:
    return DeviceInfo(identifiers={(DOMAIN, entry.entry_id)}, name=entry.title, manufacturer=PRESETS.get(entry.data.get(CONF_PRESET, "custom"), ("AI service",))[0],
                      model="AI service", entry_type=DeviceEntryType.SERVICE)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    kind = entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
    for sub in (entry.subentries or {}).values():
        if kind == ENTRY_SERVICE and sub.subentry_type == SUB_CONVERSATION:
            async_add_entities([AgentConversation(entry, sub)], config_subentry_id=sub.subentry_id)
        elif kind == ENTRY_BACKEND and sub.subentry_type == SUB_BOSS:
            async_add_entities([BossConversation(entry, sub)], config_subentry_id=sub.subentry_id)


class _Base(conversation.ConversationEntity, conversation.AbstractConversationAgent):
    _attr_has_entity_name = True
    _attr_name = None

    def __init__(self, entry: ConfigEntry, sub: ConfigSubentry) -> None:
        self.entry = entry
        self.sub = sub
        self._attr_unique_id = sub.subentry_id

    @property
    def supported_languages(self) -> list[str] | Literal["*"]:
        return MATCH_ALL



class AgentConversation(_Base):
    """An agent on an AI service, with Home Assistant's tools and the Cawood tools."""

    _attr_supports_streaming = True

    def __init__(self, entry: ConfigEntry, sub: ConfigSubentry) -> None:
        super().__init__(entry, sub)
        self._attr_device_info = DeviceInfo(identifiers={(DOMAIN, sub.subentry_id)}, name=sub.title, manufacturer=entry.title,
                                            model=sub.data.get("model"), entry_type=DeviceEntryType.SERVICE, via_device=(DOMAIN, entry.entry_id))
        if sub.data.get(CONF_LLM_HASS_API) and sub.data.get(CONF_TOOLS, True):
            self._attr_supported_features = conversation.ConversationEntityFeature.CONTROL

    async def _async_handle_message(self, user_input: conversation.ConversationInput, chat_log: conversation.ChatLog) -> conversation.ConversationResult:
        data = self.sub.data
        rt = get_runtime(self.hass)
        client = rt.providers.get(self.entry.entry_id)
        apis = data.get(CONF_LLM_HASS_API) if data.get(CONF_TOOLS, True) else None
        try:
            await provide_llm_data(chat_log, user_input, DOMAIN, apis, data.get(CONF_PROMPT))
        except conversation.ConverseError as err:
            return err.as_conversation_result()
        if client is None:
            raise ProviderError(f"The service {self.entry.title} is not loaded.")
        tools = format_tools(chat_log) if data.get(CONF_TOOLS, True) else None
        for _ in range(MAX_TOOL_ROUNDS):
            msgs = await chatlog_messages(self.hass, chat_log, bool(data.get(CONF_VISION)))
            stream = client.stream(data["model"], msgs, tools, agent_params(data))
            async for _content in chat_log.async_add_delta_content_stream(self.entity_id, to_delta_stream(stream)):
                pass
            if not chat_log.unresponded_tool_results:
                break
        return conversation.async_get_result_from_chat_log(user_input, chat_log)


class BossConversation(_Base):
    """A Boss AI: the primary model hands work to the secondary, which can ask a Home Assistant agent."""

    def __init__(self, entry: ConfigEntry, sub: ConfigSubentry) -> None:
        super().__init__(entry, sub)
        self._attr_device_info = DeviceInfo(identifiers={(DOMAIN, sub.subentry_id)}, name=sub.title, manufacturer="Cawood Systems", model="Boss AI",
                                            entry_type=DeviceEntryType.SERVICE)

    async def _async_handle_message(self, user_input: conversation.ConversationInput, chat_log: conversation.ChatLog) -> conversation.ConversationResult:
        rt = get_runtime(self.hass)
        boss = dict(self.sub.data)
        try:
            await provide_llm_data(chat_log, user_input, DOMAIN, None, None)
        except conversation.ConverseError as err:
            return err.as_conversation_result()
        system = "\n\n".join(x for x in (boss.get(CONF_PRIMARY_PROMPT),
                                         "You lead a small team. Use ask_secondary for anything practical, especially anything in the home, then check the answer and reply to the user briefly in plain words (your answer may be spoken). Use UK English.") if x)
        msgs = await chatlog_messages(self.hass, chat_log, False, system)
        msgs = [m for m in msgs if m["role"] in ("system", "user") or (m["role"] == "assistant" and not m.get("tool_calls"))]
        try:
            answer, trace = await boss_primary(self.hass, rt, boss, msgs, user_input.context)
        except ProviderError as err:
            answer, trace = f"Sorry, that failed: {err}", []
        _LOGGER.debug("Boss AI %s: %s", self.sub.title, " | ".join(trace))
        chat_log.async_add_assistant_content_without_tools(conversation.AssistantContent(agent_id=self.entity_id, content=answer or "Done."))
        return conversation.async_get_result_from_chat_log(user_input, chat_log)
