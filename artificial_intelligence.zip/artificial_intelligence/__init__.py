"""Artificial Intelligence: AI services and agents, Boss AIs, MCP, machine agents, projects, tools and the Hikvision camera AI."""
from __future__ import annotations

import asyncio
import logging

import voluptuous as vol

from homeassistant.config_entries import SOURCE_IMPORT, ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryError, ConfigEntryNotReady
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.typing import ConfigType

from .access import setup_access
from .agents import async_remove_agent_device, setup_agents
from .chat_api import setup_chat_api
from .const import CONF_ENTRY_TYPE, DOMAIN, ENTRY_BACKEND, ENTRY_DVR, ENTRY_MCP, ENTRY_SERVICE, VERSION
from .core import Core
from .hatools import setup_hatools
from .hikvision.api import setup_hikvision_views
from .hikvision.const import PLATFORMS as DVR_PLATFORMS
from .hikvision.hub import CaiHikvisionHub
from .hikvision.isapi import IsapiAuthError, IsapiError
from .hikvision.services import async_register_services
from .hikvision.training import TrainingStore
from .llm_api import setup_llm_api
from .mcp import setup_mcp
from .paths import Paths, prepare
from .projects import setup_projects
from .providers import ProviderClient
from .runtime import Runtime
from .system import setup_system
from .tools import setup_tools
from .views import ALL_VIEWS

_LOGGER = logging.getLogger(__name__)
_LOCK_KEY = f"{DOMAIN}_start_lock"
SERVICE_PLATFORMS = ["binary_sensor", "sensor", "conversation", "ai_task"]
BACKEND_PLATFORMS = ["binary_sensor", "sensor", "update", "conversation"]

CONFIG_SCHEMA = vol.Schema({DOMAIN: vol.Any(None, vol.Schema({}, extra=vol.ALLOW_EXTRA))}, extra=vol.ALLOW_EXTRA)


async def _start(hass: HomeAssistant) -> Runtime:
    lock: asyncio.Lock = hass.data.setdefault(_LOCK_KEY, asyncio.Lock())
    async with lock:
        existing = hass.data.get(DOMAIN)
        if isinstance(existing, Runtime):
            return existing
        paths = Paths.build(hass.config.path())
        await hass.async_add_executor_job(prepare, paths)
        core = await hass.async_add_executor_job(Core, paths.base)
        training = await hass.async_add_executor_job(TrainingStore, paths.hik)
        rt = Runtime(hass, core, paths)
        rt.training = training
        hass.data[DOMAIN] = rt
        for view in ALL_VIEWS:
            hass.http.register_view(view(hass, rt))
        setup_access(hass, rt)
        await rt.access.async_load()
        setup_agents(hass, rt)
        await rt.agents.async_start()
        setup_mcp(hass, rt)
        setup_projects(hass, rt)
        setup_system(hass, rt)
        setup_hatools(hass, rt)
        setup_hikvision_views(hass, rt)
        setup_tools(hass, rt)
        setup_chat_api(hass, rt)
        setup_llm_api(hass, rt)
        async_register_services(hass, rt)
        _LOGGER.info("Artificial Intelligence %s ready, data in %s", VERSION, paths.base)
        return rt


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    if DOMAIN in config:
        await _start(hass)
    return True


async def _async_reload(hass: HomeAssistant, entry: ConfigEntry) -> None:
    await hass.config_entries.async_reload(entry.entry_id)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    rt = await _start(hass)
    kind = entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)

    if kind == ENTRY_SERVICE:
        from .conversation import service_device  # noqa: PLC0415

        dr.async_get(hass).async_get_or_create(config_entry_id=entry.entry_id, **service_device(entry))
        client = ProviderClient(hass, entry.entry_id, entry.title, dict(entry.data))
        rt.providers[entry.entry_id] = client
        entry.async_create_background_task(hass, _first_check(client), f"{DOMAIN} check {entry.title}")
        await hass.config_entries.async_forward_entry_setups(entry, SERVICE_PLATFORMS)
        entry.async_on_unload(entry.add_update_listener(_async_reload))
        return True

    if kind == ENTRY_MCP:
        entry.async_create_background_task(hass, rt.mcp.refresh(entry), f"{DOMAIN} MCP {entry.title}")
        entry.async_on_unload(entry.add_update_listener(_mcp_changed))
        return True

    if kind == ENTRY_BACKEND:
        rt.agents.entry_id = entry.entry_id
        await hass.config_entries.async_forward_entry_setups(entry, BACKEND_PLATFORMS)
        entry.async_on_unload(entry.add_update_listener(_async_reload))
        return True

    # Hikvision recorder
    if not any(e.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND) == ENTRY_BACKEND for e in hass.config_entries.async_entries(DOMAIN)):
        hass.async_create_task(hass.config_entries.flow.async_init(DOMAIN, context={"source": SOURCE_IMPORT}, data={CONF_ENTRY_TYPE: ENTRY_BACKEND}))
    hub = CaiHikvisionHub(hass, entry, rt)
    try:
        await hub.async_setup()
    except IsapiAuthError as err:
        raise ConfigEntryError(f"Recorder rejected credentials: {err}") from err
    except IsapiError as err:
        raise ConfigEntryNotReady(f"Recorder not reachable: {err}") from err
    entry.runtime_data = hub
    dvr = dr.async_get(hass).async_get_or_create(config_entry_id=entry.entry_id, **hub.dvr_device_info())
    hub.dvr_device_id = dvr.id
    rt.hubs[entry.entry_id] = hub
    await hass.config_entries.async_forward_entry_setups(entry, DVR_PLATFORMS)
    hub.async_start()
    entry.async_on_unload(entry.add_update_listener(_async_reload))
    return True


async def _first_check(client: ProviderClient) -> None:
    try:
        await client.list_models()
    except Exception as err:  # noqa: BLE001
        _LOGGER.warning("AI service %s: %s", client.title, err)


async def _mcp_changed(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Tool switches change options only; a new address or token needs a fresh tool list."""
    rt = hass.data.get(DOMAIN)
    if isinstance(rt, Runtime) and rt.mcp:
        await rt.mcp.refresh(entry)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    kind = entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
    rt = hass.data.get(DOMAIN)
    if kind == ENTRY_SERVICE:
        ok = await hass.config_entries.async_unload_platforms(entry, SERVICE_PLATFORMS)
        if ok and isinstance(rt, Runtime):
            rt.providers.pop(entry.entry_id, None)
        return ok
    if kind == ENTRY_MCP:
        if isinstance(rt, Runtime) and rt.mcp:
            rt.mcp.remove(entry.entry_id)
        return True
    if kind == ENTRY_BACKEND:
        return await hass.config_entries.async_unload_platforms(entry, BACKEND_PLATFORMS)
    ok = await hass.config_entries.async_unload_platforms(entry, DVR_PLATFORMS)
    if ok:
        hub = rt.hubs.pop(entry.entry_id, None) if isinstance(rt, Runtime) else None
        if hub is not None:
            await hub.async_shutdown()
    return ok


async def async_remove_config_entry_device(hass: HomeAssistant, entry: ConfigEntry, device: dr.DeviceEntry) -> bool:
    """Deleting a machine agent's device forgets the agent (it comes back if it registers again)."""
    rt = hass.data.get(DOMAIN)
    if entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND) == ENTRY_BACKEND and isinstance(rt, Runtime):
        return await async_remove_agent_device(hass, rt, device)
    return False
