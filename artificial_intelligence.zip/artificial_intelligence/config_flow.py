"""Config flow: the backend (once), AI services with their conversation and AI task agents, MCP servers, Hikvision recorders, and Boss AIs."""
from __future__ import annotations

import re
from typing import Any

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_HOST, CONF_NAME, CONF_PASSWORD, CONF_PORT, CONF_USERNAME
from homeassistant.core import callback
from homeassistant.helpers import llm
from homeassistant.helpers.httpx_client import get_async_client
from homeassistant.helpers.selector import (
    BooleanSelector,
    EntitySelector,
    EntitySelectorConfig,
    NumberSelector,
    NumberSelectorConfig,
    NumberSelectorMode,
    SelectOptionDict,
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
)

from .const import (
    BUILTIN_HA_AGENT, CONF_API_KEY, CONF_AUTO_UPDATE, CONF_BASE_URL, CONF_BRAVE_KEY, CONF_DESCRIPTION, CONF_ENTRY_TYPE, CONF_HA_AGENT,
    CONF_LLM_HASS_API, CONF_MAX_HOPS, CONF_MAX_TOKENS, CONF_PRESET, CONF_PRIMARY, CONF_PRIMARY_PROMPT, CONF_PROMPT, CONF_REASONING,
    CONF_SEARCH, CONF_SEARXNG_URL, CONF_SECONDARY, CONF_SECONDARY_PROMPT, CONF_SHOW_STEPS, CONF_TALK_BACK, CONF_TEMPERATURE, CONF_TOKEN,
    CONF_TOOL_GROUPS, CONF_TOOLS, CONF_TOP_P, CONF_TRANSPORT, CONF_URL, CONF_VERIFY_SSL, CONF_VISION, DOMAIN, ENTRY_BACKEND, ENTRY_DVR,
    ENTRY_MCP, ENTRY_SERVICE, NAME, PRESETS, SUB_AI_TASK, SUB_BOSS, SUB_CONVERSATION,
)
from .const import CONF_MODEL as CONF_AGENT_MODEL
from .hikvision.const import (
    ANALYSABLE_KINDS,
    CHANNEL_KINDS,
    CONF_ALARM_ENTITY,
    CONF_ANALYSE_EVENTS,
    CONF_ANALYSIS_CHANNELS,
    CONF_ASK_QUESTIONS,
    CONF_AUTH_TYPE,
    CONF_COOLDOWN,
    CONF_FRAME_INTERVAL,
    CONF_FRAMES,
    CONF_IDENTITY_CONFIDENCE,
    CONF_KEEP_EVENTS,
    CONF_KEEP_IMAGES,
    CONF_MAX_REFERENCES,
    CONF_MOTION_TIMEOUT,
    CONF_NOTIFY_MIN_THREAT,
    CONF_NOTIFY_SERVICES,
    CONF_ONLY_WHEN_ARMED,
    CONF_PROMPT,
    CONF_RTSP_PORT,
    CONF_THREAT_FLOOR,
    CONF_USE_SSL,
    CONF_VISION_AGENT,
    DEFAULT_OPTIONS,
    THREAT_LEVELS,
)
from .hikvision.hub import parse_notify_services
from .hikvision.isapi import IsapiAuthError, IsapiClient, IsapiError

_SERVICE_RE = re.compile(r"^([a-z0-9_]+\.)?[a-z0-9_]+$")


def _num(lo: float, hi: float, step: float = 1, unit: str | None = None) -> NumberSelector:
    cfg = NumberSelectorConfig(min=lo, max=hi, step=step, mode=NumberSelectorMode.BOX)
    if unit:
        cfg["unit_of_measurement"] = unit
    return NumberSelector(cfg)


class AIConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    def _backend_exists(self) -> bool:
        return any(e.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND) == ENTRY_BACKEND for e in self._async_current_entries())

    @classmethod
    @callback
    def async_get_supported_subentry_types(cls, config_entry: config_entries.ConfigEntry) -> dict[str, type[config_entries.ConfigSubentryFlow]]:
        kind = config_entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
        if kind == ENTRY_SERVICE:
            return {SUB_CONVERSATION: ConversationAgentFlow, SUB_AI_TASK: AITaskAgentFlow}
        if kind == ENTRY_BACKEND:
            return {SUB_BOSS: BossAgentFlow}
        return {}

    async def async_step_user(self, user_input: dict[str, Any] | None = None):
        options = ["service", "mcp", "dvr"] if self._backend_exists() else ["backend", "service", "mcp", "dvr"]
        return self.async_show_menu(step_id="user", menu_options=options)

    async def async_step_import(self, data: dict[str, Any]):
        """Created by the integration itself: the backend, or an MCP server added from ai-cloud.html."""
        if data.get(CONF_ENTRY_TYPE) == ENTRY_BACKEND:
            if self._backend_exists():
                return self.async_abort(reason="single_instance_allowed")
            return self.async_create_entry(title=NAME, data={CONF_ENTRY_TYPE: ENTRY_BACKEND})
        if data.get(CONF_ENTRY_TYPE) == ENTRY_MCP:
            return self.async_create_entry(title=data.get(CONF_NAME) or "MCP server", data=data)
        return self.async_abort(reason="unknown")

    async def async_step_backend(self, user_input: dict[str, Any] | None = None):
        if self._backend_exists():
            return self.async_abort(reason="single_instance_allowed")
        if user_input is not None:
            return self.async_create_entry(title=NAME, data={CONF_ENTRY_TYPE: ENTRY_BACKEND})
        return self.async_show_form(step_id="backend", data_schema=vol.Schema({}))

    # ------------------------------------------------------------------ AI service (any OpenAI-compatible API)
    def _service_schema(self, d: dict[str, Any]) -> vol.Schema:
        presets = [SelectOptionDict(value=k, label=v[0]) for k, v in PRESETS.items()]
        return vol.Schema({
            vol.Required(CONF_NAME, default=d.get(CONF_NAME, "")): str,
            vol.Required(CONF_PRESET, default=d.get(CONF_PRESET, "gemini")): SelectSelector(SelectSelectorConfig(options=presets, mode=SelectSelectorMode.DROPDOWN)),
            vol.Optional(CONF_BASE_URL, description={"suggested_value": d.get(CONF_BASE_URL, "")}): TextSelector(TextSelectorConfig(type=TextSelectorType.URL)),
            vol.Optional(CONF_API_KEY, description={"suggested_value": d.get(CONF_API_KEY, "")}): TextSelector(TextSelectorConfig(type=TextSelectorType.PASSWORD)),
            vol.Required(CONF_VERIFY_SSL, default=d.get(CONF_VERIFY_SSL, True)): bool,
        })

    async def _check_service(self, data: dict[str, Any]) -> tuple[dict[str, str], int]:
        from .providers import ProviderClient, ProviderError, base_url_for  # noqa: PLC0415

        if not base_url_for(data):
            return {CONF_BASE_URL: "url_required"}, 0
        client = ProviderClient(self.hass, "check", data.get(CONF_NAME) or "service", data)
        try:
            models = await client.list_models()
        except ProviderError as err:
            self._service_error = str(err)
            return {"base": "invalid_auth" if err.status in (401, 403) else "cannot_connect"}, 0
        return {}, len(models)

    async def async_step_service(self, user_input: dict[str, Any] | None = None):
        errors: dict[str, str] = {}
        if user_input is not None:
            data = {**user_input, CONF_ENTRY_TYPE: ENTRY_SERVICE}
            data[CONF_NAME] = data[CONF_NAME].strip() or PRESETS[data[CONF_PRESET]][0]
            errors, _n = await self._check_service(data)
            if not errors:
                return self.async_create_entry(title=data[CONF_NAME], data=data)
        return self.async_show_form(step_id="service", data_schema=self._service_schema(user_input or {}), errors=errors,
                                    description_placeholders={"error": getattr(self, "_service_error", "")})

    async def async_step_reconfigure(self, user_input: dict[str, Any] | None = None):
        entry = self._get_reconfigure_entry()
        kind = entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
        if kind == ENTRY_MCP:
            return await self.async_step_mcp_reconfigure(user_input)
        if kind != ENTRY_SERVICE:
            return self.async_abort(reason="no_options")
        errors: dict[str, str] = {}
        if user_input is not None:
            data = {**entry.data, **user_input}
            errors, _n = await self._check_service(data)
            if not errors:
                return self.async_update_reload_and_abort(entry, title=data[CONF_NAME], data=data)
        return self.async_show_form(step_id="reconfigure", data_schema=self._service_schema(user_input or dict(entry.data)), errors=errors,
                                    description_placeholders={"error": getattr(self, "_service_error", "")})

    # ------------------------------------------------------------------ MCP server (tools from another app)
    def _mcp_schema(self, d: dict[str, Any]) -> vol.Schema:
        return vol.Schema({
            vol.Required(CONF_NAME, default=d.get(CONF_NAME, "")): str,
            vol.Required(CONF_URL, default=d.get(CONF_URL, "")): TextSelector(TextSelectorConfig(type=TextSelectorType.URL)),
            vol.Required(CONF_TRANSPORT, default=d.get(CONF_TRANSPORT, "streamable-http")): SelectSelector(SelectSelectorConfig(
                options=[SelectOptionDict(value="streamable-http", label="Streamable HTTP"), SelectOptionDict(value="sse", label="SSE (older servers)")], mode=SelectSelectorMode.DROPDOWN)),
            vol.Optional(CONF_TOKEN, description={"suggested_value": d.get(CONF_TOKEN, "")}): TextSelector(TextSelectorConfig(type=TextSelectorType.PASSWORD)),
        })

    async def _check_mcp(self, data: dict[str, Any]) -> dict[str, str]:
        from .mcp import McpClient, McpError  # noqa: PLC0415

        try:
            await McpClient(self.hass, data).list_tools()
        except McpError:
            return {"base": "cannot_connect"}
        return {}

    async def async_step_mcp(self, user_input: dict[str, Any] | None = None):
        errors: dict[str, str] = {}
        if user_input is not None:
            data = {**user_input, CONF_ENTRY_TYPE: ENTRY_MCP}
            errors = await self._check_mcp(data)
            if not errors:
                return self.async_create_entry(title=data[CONF_NAME], data=data)
        return self.async_show_form(step_id="mcp", data_schema=self._mcp_schema(user_input or {}), errors=errors)

    async def async_step_mcp_reconfigure(self, user_input: dict[str, Any] | None = None):
        entry = self._get_reconfigure_entry()
        errors: dict[str, str] = {}
        if user_input is not None:
            data = {**entry.data, **user_input}
            errors = await self._check_mcp(data)
            if not errors:
                return self.async_update_reload_and_abort(entry, title=data[CONF_NAME], data=data)
        return self.async_show_form(step_id="mcp_reconfigure", data_schema=self._mcp_schema(user_input or dict(entry.data)), errors=errors)

    async def async_step_dvr(self, user_input: dict[str, Any] | None = None):
        errors: dict[str, str] = {}
        if user_input is not None:
            isapi = IsapiClient(
                get_async_client(self.hass, verify_ssl=user_input[CONF_VERIFY_SSL]),
                user_input[CONF_HOST].strip(),
                user_input[CONF_PORT],
                user_input[CONF_USERNAME],
                user_input[CONF_PASSWORD],
                use_ssl=user_input[CONF_USE_SSL],
            )
            try:
                info = await isapi.detect_auth()
                channels = await isapi.streaming_channels()
            except IsapiAuthError:
                errors["base"] = "invalid_auth"
            except IsapiError:
                errors["base"] = "cannot_connect"
            else:
                if not channels:
                    errors["base"] = "no_channels"
                else:
                    await self.async_set_unique_id(info.serial or f"{isapi.host}:{isapi.port}")
                    self._abort_if_unique_id_configured(updates={CONF_HOST: isapi.host})
                    data = {**user_input, CONF_HOST: isapi.host, CONF_AUTH_TYPE: isapi.auth_type, CONF_ENTRY_TYPE: ENTRY_DVR}
                    title = data.pop(CONF_NAME, "") or info.name or info.model
                    return self.async_create_entry(title=title, data=data)

        ui = user_input or {}
        schema = vol.Schema(
            {
                vol.Optional(CONF_NAME, default=ui.get(CONF_NAME, "")): str,
                vol.Required(CONF_HOST, default=ui.get(CONF_HOST, "")): str,
                vol.Required(CONF_PORT, default=ui.get(CONF_PORT, 80)): int,
                vol.Required(CONF_USERNAME, default=ui.get(CONF_USERNAME, "admin")): str,
                vol.Required(CONF_PASSWORD): TextSelector(TextSelectorConfig(type=TextSelectorType.PASSWORD)),
                vol.Required(CONF_RTSP_PORT, default=ui.get(CONF_RTSP_PORT, 554)): int,
                vol.Required(CONF_USE_SSL, default=ui.get(CONF_USE_SSL, False)): bool,
                vol.Required(CONF_VERIFY_SSL, default=ui.get(CONF_VERIFY_SSL, False)): bool,
            }
        )
        return self.async_show_form(step_id="dvr", data_schema=schema, errors=errors)

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: config_entries.ConfigEntry) -> config_entries.OptionsFlow:
        return AIOptionsFlow()


class AIOptionsFlow(config_entries.OptionsFlow):
    async def async_step_init(self, user_input: dict[str, Any] | None = None):
        kind = self.config_entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
        if kind == ENTRY_BACKEND:
            return await self.async_step_backend(user_input)
        if kind != ENTRY_DVR:
            return self.async_abort(reason="no_options")
        errors: dict[str, str] = {}
        if user_input is not None:
            services = parse_notify_services(user_input.get(CONF_NOTIFY_SERVICES))
            if any(not _SERVICE_RE.match(s) for s in services):
                errors[CONF_NOTIFY_SERVICES] = "invalid_notify"
            else:
                for key in (CONF_FRAMES, CONF_COOLDOWN, CONF_MOTION_TIMEOUT, CONF_KEEP_IMAGES, CONF_KEEP_EVENTS, CONF_MAX_REFERENCES):
                    if key in user_input:
                        user_input[key] = int(user_input[key])
                return self.async_create_entry(data=user_input)

        o = {**DEFAULT_OPTIONS, **self.config_entry.options, **(user_input or {})}
        kinds = [SelectOptionDict(value=k, label=CHANNEL_KINDS[k][0]) for k in ANALYSABLE_KINDS]
        levels = SelectSelector(SelectSelectorConfig(options=THREAT_LEVELS, mode=SelectSelectorMode.DROPDOWN))
        schema = vol.Schema(
            {
                vol.Optional(CONF_VISION_AGENT, description={"suggested_value": o.get(CONF_VISION_AGENT) or None}): EntitySelector(
                    EntitySelectorConfig(domain="ai_task", integration=DOMAIN)
                ),
                vol.Required(CONF_ANALYSE_EVENTS, default=o[CONF_ANALYSE_EVENTS]): SelectSelector(
                    SelectSelectorConfig(options=kinds, multiple=True, mode=SelectSelectorMode.LIST)
                ),
                vol.Optional(CONF_ANALYSIS_CHANNELS, description={"suggested_value": o[CONF_ANALYSIS_CHANNELS]}): str,
                vol.Required(CONF_FRAMES, default=o[CONF_FRAMES]): _num(1, 5),
                vol.Required(CONF_FRAME_INTERVAL, default=o[CONF_FRAME_INTERVAL]): _num(0.2, 3, 0.1, "s"),
                vol.Required(CONF_COOLDOWN, default=o[CONF_COOLDOWN]): _num(0, 3600, 1, "s"),
                vol.Required(CONF_MOTION_TIMEOUT, default=o[CONF_MOTION_TIMEOUT]): _num(5, 300, 1, "s"),
                vol.Optional(CONF_NOTIFY_SERVICES, description={"suggested_value": o[CONF_NOTIFY_SERVICES]}): str,
                vol.Required(CONF_NOTIFY_MIN_THREAT, default=o[CONF_NOTIFY_MIN_THREAT]): levels,
                vol.Optional(CONF_ALARM_ENTITY, description={"suggested_value": o[CONF_ALARM_ENTITY] or None}): EntitySelector(
                    EntitySelectorConfig(domain="alarm_control_panel")
                ),
                vol.Required(CONF_ONLY_WHEN_ARMED, default=o[CONF_ONLY_WHEN_ARMED]): BooleanSelector(),
                vol.Required(CONF_KEEP_IMAGES, default=o[CONF_KEEP_IMAGES]): _num(10, 20000),
                vol.Required(CONF_KEEP_EVENTS, default=o[CONF_KEEP_EVENTS]): _num(50, 100000),
                vol.Required(CONF_MAX_REFERENCES, default=o[CONF_MAX_REFERENCES]): _num(0, 8),
                vol.Required(CONF_IDENTITY_CONFIDENCE, default=o[CONF_IDENTITY_CONFIDENCE]): _num(0.1, 1, 0.05),
                vol.Required(CONF_ASK_QUESTIONS, default=o[CONF_ASK_QUESTIONS]): BooleanSelector(),
                vol.Required(CONF_THREAT_FLOOR, default=o[CONF_THREAT_FLOOR]): levels,
                vol.Required(CONF_PROMPT, default=o[CONF_PROMPT]): TextSelector(TextSelectorConfig(multiline=True)),
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema, errors=errors)

    async def async_step_backend(self, user_input: dict[str, Any] | None = None):
        if user_input is not None:
            return self.async_create_entry(data=user_input)
        o = {CONF_SEARCH: "duckduckgo", CONF_SEARXNG_URL: "", CONF_BRAVE_KEY: "", CONF_AUTO_UPDATE: True, **self.config_entry.options}
        schema = vol.Schema({
            vol.Required(CONF_SEARCH, default=o[CONF_SEARCH]): SelectSelector(SelectSelectorConfig(options=[
                SelectOptionDict(value="duckduckgo", label="DuckDuckGo (no key)"), SelectOptionDict(value="searxng", label="SearXNG (your own server)"),
                SelectOptionDict(value="brave", label="Brave Search API (key)")], mode=SelectSelectorMode.DROPDOWN)),
            vol.Optional(CONF_SEARXNG_URL, description={"suggested_value": o[CONF_SEARXNG_URL]}): TextSelector(TextSelectorConfig(type=TextSelectorType.URL)),
            vol.Optional(CONF_BRAVE_KEY, description={"suggested_value": o[CONF_BRAVE_KEY]}): TextSelector(TextSelectorConfig(type=TextSelectorType.PASSWORD)),
            vol.Required(CONF_AUTO_UPDATE, default=o[CONF_AUTO_UPDATE]): BooleanSelector(),
        })
        return self.async_show_form(step_id="backend", data_schema=schema)


# ---------------------------------------------------------------------- agents (subentries)
TOOL_GROUP_OPTIONS = [
    SelectOptionDict(value="cameras", label="Cameras"), SelectOptionDict(value="home_assistant", label="Home Assistant"),
    SelectOptionDict(value="files", label="Files"), SelectOptionDict(value="terminal", label="Terminal, Python and browser"),
    SelectOptionDict(value="projects", label="Projects"), SelectOptionDict(value="email", label="Email"),
]
REASONING = [SelectOptionDict(value=v, label=l) for v, l in (("none", "Off"), ("low", "Low"), ("medium", "Medium"), ("high", "High"))]


async def _models(flow: config_entries.ConfigSubentryFlow) -> list[str]:
    from .providers import ProviderClient, ProviderError  # noqa: PLC0415

    entry = flow._get_entry()  # noqa: SLF001
    try:
        return await ProviderClient(flow.hass, entry.entry_id, entry.title, dict(entry.data)).list_models()
    except ProviderError:
        return []


def _model_selector(models: list[str]) -> SelectSelector:
    return SelectSelector(SelectSelectorConfig(options=models or [""], custom_value=True, mode=SelectSelectorMode.DROPDOWN, sort=True))


def _apis(hass) -> list[SelectOptionDict]:
    return [SelectOptionDict(value=a.id, label=a.name) for a in llm.async_get_apis(hass)]


class _AgentFlow(config_entries.ConfigSubentryFlow):
    """Shared add/reconfigure logic."""

    kind = SUB_CONVERSATION

    async def _schema(self, d: dict[str, Any]) -> vol.Schema:
        raise NotImplementedError

    async def async_step_user(self, user_input: dict[str, Any] | None = None):
        if self._get_entry().state is not config_entries.ConfigEntryState.LOADED:
            return self.async_abort(reason="entry_not_loaded")
        if user_input is not None:
            if not str(user_input.get(CONF_AGENT_MODEL, "")).strip():
                return self.async_show_form(step_id="user", data_schema=await self._schema(user_input), errors={CONF_AGENT_MODEL: "model_required"})
            name = user_input.pop(CONF_NAME).strip() or user_input[CONF_AGENT_MODEL]
            return self.async_create_entry(title=name, data=user_input)
        return self.async_show_form(step_id="user", data_schema=await self._schema({}))

    async def async_step_reconfigure(self, user_input: dict[str, Any] | None = None):
        sub = self._get_reconfigure_subentry()
        if user_input is not None:
            name = user_input.pop(CONF_NAME).strip() or sub.title
            return self.async_update_and_abort(self._get_entry(), sub, title=name, data=user_input)
        return self.async_show_form(step_id="reconfigure", data_schema=await self._schema({CONF_NAME: sub.title, **sub.data}))


class ConversationAgentFlow(_AgentFlow):
    kind = SUB_CONVERSATION

    async def _schema(self, d: dict[str, Any]) -> vol.Schema:
        models = await _models(self)
        return vol.Schema({
            vol.Required(CONF_NAME, default=d.get(CONF_NAME, "")): str,
            vol.Required(CONF_AGENT_MODEL, default=d.get(CONF_AGENT_MODEL, models[0] if models else "")): _model_selector(models),
            vol.Optional(CONF_DESCRIPTION, description={"suggested_value": d.get(CONF_DESCRIPTION, "")}): str,
            vol.Optional(CONF_PROMPT, description={"suggested_value": d.get(CONF_PROMPT, "")}): TextSelector(TextSelectorConfig(multiline=True)),
            vol.Optional(CONF_LLM_HASS_API, description={"suggested_value": d.get(CONF_LLM_HASS_API, [llm.LLM_API_ASSIST, "cawood_ai_tools"])}): SelectSelector(
                SelectSelectorConfig(options=_apis(self.hass), multiple=True)),
            vol.Required(CONF_TOOLS, default=d.get(CONF_TOOLS, True)): BooleanSelector(),
            vol.Required(CONF_VISION, default=d.get(CONF_VISION, False)): BooleanSelector(),
            vol.Required(CONF_REASONING, default=d.get(CONF_REASONING, "none")): SelectSelector(SelectSelectorConfig(options=REASONING, mode=SelectSelectorMode.DROPDOWN)),
            vol.Optional(CONF_TEMPERATURE, description={"suggested_value": d.get(CONF_TEMPERATURE)}): _num(0, 2, 0.05),
            vol.Optional(CONF_TOP_P, description={"suggested_value": d.get(CONF_TOP_P)}): _num(0, 1, 0.05),
            vol.Optional(CONF_MAX_TOKENS, description={"suggested_value": d.get(CONF_MAX_TOKENS)}): _num(1, 200000),
            vol.Optional(CONF_TOOL_GROUPS, description={"suggested_value": d.get(CONF_TOOL_GROUPS, [])}): SelectSelector(
                SelectSelectorConfig(options=TOOL_GROUP_OPTIONS, multiple=True)),
        })


class AITaskAgentFlow(_AgentFlow):
    kind = SUB_AI_TASK

    async def _schema(self, d: dict[str, Any]) -> vol.Schema:
        models = await _models(self)
        return vol.Schema({
            vol.Required(CONF_NAME, default=d.get(CONF_NAME, "")): str,
            vol.Required(CONF_AGENT_MODEL, default=d.get(CONF_AGENT_MODEL, models[0] if models else "")): _model_selector(models),
            vol.Optional(CONF_PROMPT, description={"suggested_value": d.get(CONF_PROMPT, "")}): TextSelector(TextSelectorConfig(multiline=True)),
            vol.Required(CONF_VISION, default=d.get(CONF_VISION, True)): BooleanSelector(),
            vol.Optional(CONF_TEMPERATURE, description={"suggested_value": d.get(CONF_TEMPERATURE, 0.3)}): _num(0, 2, 0.05),
            vol.Optional(CONF_MAX_TOKENS, description={"suggested_value": d.get(CONF_MAX_TOKENS)}): _num(1, 200000),
        })


class BossAgentFlow(config_entries.ConfigSubentryFlow):
    """A primary model that hands work to a secondary model, which can ask a Home Assistant agent."""

    def _schema(self, d: dict[str, Any]) -> vol.Schema:
        conv = EntitySelector(EntitySelectorConfig(domain="conversation", integration=DOMAIN))
        return vol.Schema({
            vol.Required(CONF_NAME, default=d.get(CONF_NAME, "")): str,
            vol.Required(CONF_PRIMARY, default=d.get(CONF_PRIMARY, vol.UNDEFINED)): conv,
            vol.Required(CONF_SECONDARY, default=d.get(CONF_SECONDARY, vol.UNDEFINED)): conv,
            vol.Required(CONF_HA_AGENT, default=d.get(CONF_HA_AGENT, BUILTIN_HA_AGENT)): EntitySelector(EntitySelectorConfig(domain="conversation")),
            vol.Optional(CONF_PRIMARY_PROMPT, description={"suggested_value": d.get(CONF_PRIMARY_PROMPT, "")}): TextSelector(TextSelectorConfig(multiline=True)),
            vol.Optional(CONF_SECONDARY_PROMPT, description={"suggested_value": d.get(CONF_SECONDARY_PROMPT, "")}): TextSelector(TextSelectorConfig(multiline=True)),
            vol.Required(CONF_MAX_HOPS, default=d.get(CONF_MAX_HOPS, 4)): _num(1, 8),
            vol.Required(CONF_TALK_BACK, default=d.get(CONF_TALK_BACK, True)): BooleanSelector(),
            vol.Required(CONF_SHOW_STEPS, default=d.get(CONF_SHOW_STEPS, True)): BooleanSelector(),
        })

    def _check(self, user_input: dict[str, Any]) -> dict[str, str]:
        return {CONF_SECONDARY: "same_agent"} if user_input[CONF_PRIMARY] == user_input[CONF_SECONDARY] else {}

    async def async_step_user(self, user_input: dict[str, Any] | None = None):
        if user_input is not None:
            errors = self._check(user_input)
            if not errors:
                user_input[CONF_MAX_HOPS] = int(user_input[CONF_MAX_HOPS])
                return self.async_create_entry(title=user_input.pop(CONF_NAME).strip() or "Boss AI", data=user_input)
            return self.async_show_form(step_id="user", data_schema=self._schema(user_input), errors=errors)
        return self.async_show_form(step_id="user", data_schema=self._schema({}))

    async def async_step_reconfigure(self, user_input: dict[str, Any] | None = None):
        sub = self._get_reconfigure_subentry()
        if user_input is not None:
            errors = self._check(user_input)
            if not errors:
                user_input[CONF_MAX_HOPS] = int(user_input[CONF_MAX_HOPS])
                return self.async_update_and_abort(self._get_entry(), sub, title=user_input.pop(CONF_NAME).strip() or sub.title, data=user_input)
            return self.async_show_form(step_id="reconfigure", data_schema=self._schema(user_input), errors=errors)
        return self.async_show_form(step_id="reconfigure", data_schema=self._schema({CONF_NAME: sub.title, **sub.data}))
