"""MCP both ways.

- As a client: MCP servers added in the integration ("Add Service" > MCP server, or from ai-cloud.html) have their tools
  listed in the tool registry, so the pages, the voice assistants and the Boss AIs can use them. Streamable HTTP and the
  older SSE transport are supported. Every call asks for approval unless the tool is marked safe.
- As a server: POST /api/artificial_intelligence/mcp speaks MCP (Streamable HTTP, JSON responses) so other apps can use
  the Cawood tools with a Home Assistant long-lived token. Writes outside the write list are refused for them.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import secrets
from typing import Any
from urllib.parse import urljoin

import aiohttp
from aiohttp import web

from homeassistant.components.http import HomeAssistantView
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.network import NoURLAvailableError, get_url

from .authz import AuthedView
from .const import API, CONF_ENTRY_TYPE, CONF_MCP_TOOLS, CONF_TOKEN, CONF_TRANSPORT, CONF_URL, DOMAIN, ENTRY_MCP, VERSION
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)
PROTOCOL = "2025-06-18"
DEFAULT_GROUPS = {"cameras": True, "home_assistant": True, "files": True, "terminal": False, "projects": True, "email": False}


class McpError(Exception):
    """An MCP call failed."""


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_") or "mcp"


async def _sse_events(resp: aiohttp.ClientResponse):
    event, data = "message", []
    async for raw in resp.content:
        line = raw.decode("utf-8", "replace").rstrip("\r\n")
        if not line:
            if data:
                yield event, "\n".join(data)
            event, data = "message", []
        elif line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data.append(line[5:].lstrip())
    if data:
        yield event, "\n".join(data)


class McpClient:
    """Talks to one MCP server. A short session per operation keeps it simple and robust."""

    def __init__(self, hass: HomeAssistant, data: dict) -> None:
        self.hass = hass
        self.url = str(data.get(CONF_URL) or "").strip()
        self.transport = data.get(CONF_TRANSPORT) or "streamable-http"
        self.token = str(data.get(CONF_TOKEN) or "").strip()
        self._id = 0

    def _headers(self, extra: dict | None = None) -> dict:
        h = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream", "MCP-Protocol-Version": PROTOCOL}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        h.update(extra or {})
        return h

    def _req(self, method: str, params: dict | None = None) -> dict:
        self._id += 1
        return {"jsonrpc": "2.0", "id": self._id, "method": method, "params": params or {}}

    async def _session(self, requests: list[dict]) -> list[Any]:
        if self.transport == "sse":
            return await self._sse_session(requests)
        return await self._http_session(requests)

    # ----- Streamable HTTP
    async def _post(self, session: aiohttp.ClientSession, body: dict, sid: str | None) -> tuple[Any, str | None]:
        extra = {"Mcp-Session-Id": sid} if sid else {}
        async with session.post(self.url, json=body, headers=self._headers(extra), timeout=aiohttp.ClientTimeout(total=120)) as resp:
            sid = resp.headers.get("Mcp-Session-Id") or sid
            if resp.status == 202 or "id" not in body:
                return None, sid
            if resp.status >= 400:
                raise McpError(f"{resp.status}: {(await resp.text())[:200]}")
            if "text/event-stream" in resp.headers.get("Content-Type", ""):
                async for _ev, data in _sse_events(resp):
                    try:
                        msg = json.loads(data)
                    except ValueError:
                        continue
                    if msg.get("id") == body["id"]:
                        return msg, sid
                raise McpError("The server closed the stream without an answer.")
            return await resp.json(content_type=None), sid

    async def _http_session(self, requests: list[dict]) -> list[Any]:
        session = async_get_clientsession(self.hass)
        try:
            init, sid = await self._post(session, self._req("initialize", {"protocolVersion": PROTOCOL, "capabilities": {}, "clientInfo": {"name": "cawood-ai", "version": VERSION}}), None)
            if init and init.get("error"):
                raise McpError(str(init["error"].get("message")))
            await self._post(session, {"jsonrpc": "2.0", "method": "notifications/initialized"}, sid)
            out = []
            for r in requests:
                msg, sid = await self._post(session, r, sid)
                out.append(msg)
            return out
        except (aiohttp.ClientError, TimeoutError) as err:
            raise McpError(f"Cannot reach {self.url}: {err}") from err

    # ----- older SSE transport
    async def _sse_session(self, requests: list[dict]) -> list[Any]:
        session = async_get_clientsession(self.hass)
        try:
            async with session.get(self.url, headers={k: v for k, v in self._headers().items() if k != "Content-Type"} | {"Accept": "text/event-stream"},
                                   timeout=aiohttp.ClientTimeout(total=180, sock_read=120)) as resp:
                if resp.status >= 400:
                    raise McpError(f"{resp.status}: {(await resp.text())[:200]}")
                events = _sse_events(resp)
                endpoint = None
                async for ev, data in events:
                    if ev == "endpoint":
                        endpoint = urljoin(self.url, data.strip())
                        break
                if not endpoint:
                    raise McpError("The server did not send its message endpoint.")

                async def send(body: dict) -> Any:
                    async with session.post(endpoint, json=body, headers=self._headers(), timeout=aiohttp.ClientTimeout(total=60)) as pr:
                        if pr.status >= 400:
                            raise McpError(f"{pr.status}: {(await pr.text())[:200]}")
                    if "id" not in body:
                        return None
                    async for _ev, data in events:
                        try:
                            msg = json.loads(data)
                        except ValueError:
                            continue
                        if msg.get("id") == body["id"]:
                            return msg
                    raise McpError("The server closed the stream without an answer.")

                await send(self._req("initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "cawood-ai", "version": VERSION}}))
                await send({"jsonrpc": "2.0", "method": "notifications/initialized"})
                return [await send(r) for r in requests]
        except (aiohttp.ClientError, TimeoutError) as err:
            raise McpError(f"Cannot reach {self.url}: {err}") from err

    # ----- operations
    async def list_tools(self) -> list[dict]:
        tools: list[dict] = []
        cursor = None
        for _page in range(10):
            (msg,) = await self._session([self._req("tools/list", {"cursor": cursor} if cursor else {})])
            if not msg or msg.get("error"):
                raise McpError(str((msg or {}).get("error", {}).get("message", "No answer to tools/list")))
            res = msg.get("result") or {}
            tools += res.get("tools") or []
            cursor = res.get("nextCursor")
            if not cursor:
                break
        return tools

    async def call(self, name: str, args: dict) -> tuple[str, bool]:
        (msg,) = await self._session([self._req("tools/call", {"name": name, "arguments": args})])
        if not msg:
            raise McpError("No answer from the MCP server.")
        if msg.get("error"):
            raise McpError(str(msg["error"].get("message")))
        res = msg.get("result") or {}
        parts = []
        for c in res.get("content") or []:
            if c.get("type") == "text":
                parts.append(c.get("text", ""))
            elif c.get("type") == "resource":
                parts.append(json.dumps(c.get("resource"))[:4000])
            else:
                parts.append(f"[{c.get('type')} content]")
        if res.get("structuredContent") and not parts:
            parts.append(json.dumps(res["structuredContent"])[:12000])
        return "\n".join(parts)[:20000] or "(empty result)", bool(res.get("isError"))


class McpManager:
    """Every MCP server entry, its tools and their settings."""

    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt
        self.servers: dict[str, dict] = {}   # entry_id -> {"tools": [...], "error": str, "status": str}

    def _entry(self, entry_id: str) -> ConfigEntry | None:
        e = self.hass.config_entries.async_get_entry(entry_id)
        return e if e and e.data.get(CONF_ENTRY_TYPE) == ENTRY_MCP else None

    async def refresh(self, entry: ConfigEntry) -> dict:
        state = self.servers.setdefault(entry.entry_id, {"tools": [], "error": "", "status": "connecting"})
        try:
            state["tools"] = await McpClient(self.hass, dict(entry.data)).list_tools()
            state.update(error="", status="connected")
        except McpError as err:
            state.update(error=str(err), status="error")
            _LOGGER.warning("MCP server %s: %s", entry.title, err)
        return state

    def remove(self, entry_id: str) -> None:
        self.servers.pop(entry_id, None)

    def tool_settings(self, entry: ConfigEntry, tool: dict) -> dict:
        s = (entry.options.get(CONF_MCP_TOOLS) or {}).get(tool.get("name"), {})
        ro = bool((tool.get("annotations") or {}).get("readOnlyHint"))
        return {"enabled": s.get("enabled", True), "safe": s.get("safe", ro)}

    def view(self, entry: ConfigEntry) -> dict:
        st = self.servers.get(entry.entry_id, {"tools": [], "error": "", "status": "connecting"})
        return {"id": entry.entry_id, "name": entry.title, "url": entry.data.get(CONF_URL), "transport": entry.data.get(CONF_TRANSPORT, "streamable-http"),
                "status": st["status"], "error": st["error"] or None,
                "tools": [{"name": t.get("name"), "description": t.get("description") or "", **self.tool_settings(entry, t)} for t in st["tools"]]}

    def registry_tools(self) -> list[dict]:
        out = []
        for entry_id, st in self.servers.items():
            entry = self._entry(entry_id)
            if not entry or st["status"] != "connected":
                continue
            for t in st["tools"]:
                if not self.tool_settings(entry, t)["enabled"]:
                    continue
                params = t.get("inputSchema") if isinstance(t.get("inputSchema"), dict) else {"type": "object", "properties": {}}
                params = {"type": "object", "properties": params.get("properties") or {}, "required": params.get("required") or []}
                out.append({"type": "function", "group": f"mcp:{entry.title}",
                            "function": {"name": (_slug(entry.title) + "__" + _slug(t.get("name")))[:64], "description": f"[{entry.title}] {t.get('description') or t.get('name')}", "parameters": params},
                            "x-cai": {"method": "POST", "path": API + "/mcp_call", "send": "body", "fixed": {"_mcp_server": entry_id, "_mcp_tool": t.get("name")}}})
        return out

    async def call(self, entry_id: str, tool: str, args: dict) -> tuple[str, bool]:
        entry = self._entry(entry_id)
        if not entry:
            raise McpError("That MCP server is no longer set up.")
        return await McpClient(self.hass, dict(entry.data)).call(tool, args)

    # ----- settings for exposing our own tools
    async def server_settings(self) -> dict:
        cfg = await self.hass.async_add_executor_job(self.rt.core.config)
        return {"enabled": cfg.get("mcp_enabled", True), "groups": {**DEFAULT_GROUPS, **(cfg.get("mcp_groups") or {})}}


# ---------------------------------------------------------------------- MCP server
class McpServerEndpoint(HomeAssistantView):
    """MCP over Streamable HTTP (JSON responses). Sign in with a Home Assistant long-lived token."""

    url = API + "/mcp"
    name = "api:artificial_intelligence:mcp"
    requires_auth = True

    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt

    async def get(self, request):
        return web.Response(status=405, text="Use POST (Streamable HTTP).")

    async def delete(self, request):
        return web.Response(status=200)

    async def post(self, request):
        settings = await self.rt.mcp.server_settings()
        if not settings["enabled"]:
            return web.json_response({"jsonrpc": "2.0", "id": None, "error": {"code": -32000, "message": "The MCP server is switched off in ai-cloud.html, Settings, Tools and MCP."}}, status=403)
        try:
            body = await request.json()
        except ValueError:
            return web.json_response({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}, status=400)
        batch = body if isinstance(body, list) else [body]
        replies = [r for r in [await self._one(m, settings) for m in batch] if r is not None]
        headers = {"Mcp-Session-Id": request.headers.get("Mcp-Session-Id") or secrets.token_hex(12)}
        if not replies:
            return web.Response(status=202, headers=headers)
        return web.json_response(replies if isinstance(body, list) else replies[0], headers=headers)

    async def _tools(self, settings: dict) -> list[dict]:
        from .tools import _all_tools, build_context  # noqa: PLC0415

        ctx = await build_context(self.rt)
        return [t for t in _all_tools(ctx) if settings["groups"].get(t.get("group"), False) or t.get("group") == "meta"]

    async def _one(self, msg: dict, settings: dict) -> dict | None:
        mid, method, params = msg.get("id"), msg.get("method"), msg.get("params") or {}
        if mid is None:
            return None  # notification
        try:
            if method == "initialize":
                result = {"protocolVersion": params.get("protocolVersion") or PROTOCOL, "capabilities": {"tools": {"listChanged": False}},
                          "serverInfo": {"name": "cawood-ai", "title": "Cawood Artificial Intelligence", "version": VERSION},
                          "instructions": "Tools for a Home Assistant home: cameras, devices, files, projects. Writes outside the owner's write list are refused."}
            elif method == "ping":
                result = {}
            elif method == "tools/list":
                result = {"tools": [{"name": t["function"]["name"], "description": t["function"]["description"], "inputSchema": t["function"]["parameters"]} for t in await self._tools(settings)]}
            elif method == "tools/call":
                from .llm_api import run_tool  # noqa: PLC0415

                spec = next((t for t in await self._tools(settings) if t["function"]["name"] == params.get("name")), None)
                if spec is None:
                    return {"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": f"Unknown or switched-off tool: {params.get('name')}"}], "isError": True}}
                out = await run_tool(self.hass, self.rt, spec, dict(params.get("arguments") or {}), origin="mcp")
                text = out.get("result") if "result" in out else out.get("error")
                result = {"content": [{"type": "text", "text": str(text)}], "isError": "error" in out}
            else:
                return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Method not found: {method}"}}
        except Exception as err:  # noqa: BLE001
            _LOGGER.exception("MCP request %s failed", method)
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32603, "message": str(err)[:300]}}
        return {"jsonrpc": "2.0", "id": mid, "result": result}


# ---------------------------------------------------------------------- page endpoints
def _origin(hass: HomeAssistant) -> str:
    try:
        return get_url(hass, prefer_external=True)
    except NoURLAvailableError:
        return ""


class McpServerSettingsView(AuthedView):
    url = API + "/mcp_server"
    name = "api:artificial_intelligence:mcp_server"

    async def get(self, request):
        s = await self.rt.mcp.server_settings()
        from .tools import _all_tools, build_context  # noqa: PLC0415

        tools = _all_tools(await build_context(self.rt))
        return self.json({**s, "url": _origin(self.hass) + API + "/mcp", "tools": sum(1 for t in tools if s["groups"].get(t.get("group")))})

    async def put(self, request):
        if not self.who(request).is_admin:
            return self.json({"error": "Only an administrator can do that."}, status_code=403)
        b = await request.json()
        s = await self.rt.mcp.server_settings()
        changes: dict[str, Any] = {}
        if "enabled" in b:
            changes["mcp_enabled"] = bool(b["enabled"])
        if isinstance(b.get("groups"), dict):
            changes["mcp_groups"] = {**s["groups"], **{str(k): bool(v) for k, v in b["groups"].items()}}
        if changes:
            await self.hass.async_add_executor_job(self.rt.core.set_config, changes)
        return self.json(await self.rt.mcp.server_settings())


class McpServersView(AuthedView):
    url = API + "/mcp_servers"
    name = "api:artificial_intelligence:mcp_servers"

    async def get(self, request):
        entries = [e for e in self.hass.config_entries.async_entries(DOMAIN) if e.data.get(CONF_ENTRY_TYPE) == ENTRY_MCP]
        return self.json({"servers": [self.rt.mcp.view(e) for e in entries]})

    async def post(self, request):
        if not self.who(request).is_admin:
            return self.json({"error": "Only an administrator can do that."}, status_code=403)
        b = await request.json()
        data = {CONF_ENTRY_TYPE: ENTRY_MCP, "name": str(b.get("name") or "MCP server").strip()[:60], CONF_URL: str(b.get("url") or "").strip(),
                CONF_TRANSPORT: b.get("transport") if b.get("transport") in ("sse", "streamable-http") else "streamable-http", CONF_TOKEN: str(b.get("token") or "")}
        try:
            await McpClient(self.hass, data).list_tools()
        except McpError as err:
            return self.json({"error": f"Could not connect: {err}"}, status_code=502)
        res = await self.hass.config_entries.flow.async_init(DOMAIN, context={"source": "import"}, data=data)
        entry = res.get("result") if isinstance(res, dict) else None
        if entry is None:
            return self.json({"error": "Home Assistant did not create the entry."}, status_code=500)
        for _ in range(20):
            if entry.entry_id in self.rt.mcp.servers and self.rt.mcp.servers[entry.entry_id]["status"] != "connecting":
                break
            await asyncio.sleep(0.5)
        return self.json(self.rt.mcp.view(entry))


class McpServerItemView(AuthedView):
    url = API + "/mcp_servers/{entry_id}"
    name = "api:artificial_intelligence:mcp_server_item"

    def _entry(self, entry_id):
        return self.rt.mcp._entry(entry_id)  # noqa: SLF001

    async def get(self, request, entry_id):
        e = self._entry(entry_id)
        return self.json(self.rt.mcp.view(e)) if e else self.json({"error": "No such MCP server."}, status_code=404)

    async def put(self, request, entry_id):
        if not self.who(request).is_admin:
            return self.json({"error": "Only an administrator can do that."}, status_code=403)
        e = self._entry(entry_id)
        if not e:
            return self.json({"error": "No such MCP server."}, status_code=404)
        b = await request.json()
        tools = dict(e.options.get(CONF_MCP_TOOLS) or {})
        for t in b.get("tools") or []:
            cur = dict(tools.get(t.get("name"), {}))
            for k in ("enabled", "safe"):
                if k in t:
                    cur[k] = bool(t[k])
            tools[str(t.get("name"))] = cur
        self.hass.config_entries.async_update_entry(e, options={**e.options, CONF_MCP_TOOLS: tools})
        return self.json(self.rt.mcp.view(e))

    async def delete(self, request, entry_id):
        if not self.who(request).is_admin:
            return self.json({"error": "Only an administrator can do that."}, status_code=403)
        if not self._entry(entry_id):
            return self.json({"error": "No such MCP server."}, status_code=404)
        await self.hass.config_entries.async_remove(entry_id)
        return self.json({"ok": True})

    async def post(self, request, entry_id):
        """POST /mcp_servers/<id> refreshes the tool list (the page calls /test)."""
        e = self._entry(entry_id)
        if not e:
            return self.json({"error": "No such MCP server."}, status_code=404)
        st = await self.rt.mcp.refresh(e)
        if st["status"] != "connected":
            return self.json({"error": st["error"]}, status_code=502)
        return self.json({"ok": True, "tools": len(st["tools"])})


class McpServerTestView(McpServerItemView):
    url = API + "/mcp_servers/{entry_id}/test"
    name = "api:artificial_intelligence:mcp_server_test"


class McpCallView(AuthedView):
    url = API + "/mcp_call"
    name = "api:artificial_intelligence:mcp_call"

    async def post(self, request):
        b = await request.json()
        entry_id, tool = b.pop("_mcp_server", None), b.pop("_mcp_tool", None)
        entry = self.rt.mcp._entry(str(entry_id or ""))  # noqa: SLF001
        if not entry or not tool:
            return self.json({"error": "Unknown MCP tool."}, status_code=404)
        spec = next((t for t in self.rt.mcp.servers.get(entry.entry_id, {}).get("tools", []) if t.get("name") == tool), {"name": tool})
        settings = self.rt.mcp.tool_settings(entry, spec)
        if not settings["enabled"]:
            return self.json({"error": "That tool is switched off."}, status_code=403)
        target = f"{entry.title}: {tool}"
        if settings["safe"]:
            self.rt.access.log(getattr(self.who(request), "name", "?"), "mcp", target, "allowed", "Marked safe")
        else:
            stop = await self.rt.access.check(request, "mcp", target, f"call {tool} on the {entry.title} MCP server", json.dumps(b, indent=1)[:1200], listable=False)
            if stop is not None:
                return stop
        try:
            text, is_err = await self.rt.mcp.call(entry.entry_id, tool, b)
        except McpError as err:
            return self.json({"error": str(err)}, status_code=502)
        return self.json({"error": text} if is_err else {"result": text}, status_code=400 if is_err else 200)


def setup_mcp(hass: HomeAssistant, rt: Runtime) -> None:
    rt.mcp = McpManager(hass, rt)
    hass.http.register_view(McpServerEndpoint(hass, rt))
    for view in (McpServerSettingsView, McpServersView, McpServerItemView, McpServerTestView, McpCallView):
        hass.http.register_view(view(hass, rt))
