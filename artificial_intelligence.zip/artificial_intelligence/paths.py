"""Data folder layout for Artificial Intelligence, and the one-time copy from the old davai folders."""
from __future__ import annotations

import logging
import os
import shutil
from dataclasses import dataclass

from .const import APP_DIR, DATA_DIR, HIK_DIR, OLD_APP_DIR, OLD_PROJECTS_DIR, PROJECTS_DIR, WORKSPACE_DIR, WORKSPACE_NAME

_LOGGER = logging.getLogger(__name__)
MARKER = ".migrated_from_davai"


@dataclass(frozen=True)
class Paths:
    base: str        # <config>/www/Artificial Intelegence
    projects: str    # <base>/Projects
    workspace: str   # <base>/Workspace
    app: str         # <base>/Chats and Settings
    hik: str         # <base>/Hikvision
    config_dir: str

    @classmethod
    def build(cls, config_dir: str) -> "Paths":
        base = os.path.join(config_dir, *DATA_DIR.split("/"))
        return cls(
            base=base,
            projects=os.path.join(base, PROJECTS_DIR),
            workspace=os.path.join(base, WORKSPACE_DIR),
            app=os.path.join(base, APP_DIR),
            hik=os.path.join(base, HIK_DIR),
            config_dir=config_dir,
        )

    @property
    def old_projects(self) -> str:
        return os.path.join(self.config_dir, OLD_PROJECTS_DIR)

    @property
    def old_app(self) -> str:
        return os.path.join(self.config_dir, OLD_APP_DIR)


def _copy_tree(src: str, dst: str, skip: set[str] | None = None) -> int:
    """Copy src into dst without overwriting anything already there. Returns the number of files copied."""
    skip = skip or set()
    count = 0
    os.makedirs(dst, exist_ok=True)
    for name in sorted(os.listdir(src)):
        if name in skip:
            continue
        s, d = os.path.join(src, name), os.path.join(dst, name)
        if os.path.islink(s):
            continue
        if os.path.isdir(s):
            count += _copy_tree(s, d)
        elif not os.path.exists(d):
            shutil.copy2(s, d)
            count += 1
    return count


def prepare(paths: Paths) -> None:
    """Create the folders and, once, copy the old davai data in. The old folders are left in place."""
    for p in (paths.base, paths.projects, paths.workspace, paths.app, paths.hik):
        os.makedirs(p, exist_ok=True)

    marker = os.path.join(paths.projects, MARKER)
    if os.path.exists(marker):
        return
    copied = 0
    if os.path.isdir(paths.old_projects):
        copied += _copy_tree(paths.old_projects, paths.projects, skip={WORKSPACE_NAME})
        old_ws = os.path.join(paths.old_projects, WORKSPACE_NAME)
        if os.path.isdir(old_ws):
            copied += _copy_tree(old_ws, paths.workspace)
    if os.path.isdir(paths.old_app):
        copied += _copy_tree(paths.old_app, paths.app)
    with open(marker, "w", encoding="utf-8") as fh:
        fh.write("Data copied once from the old davai_projects and davai_app folders. Those folders can now be deleted.\n")
    if copied:
        _LOGGER.info(
            "Copied %d files from davai_projects and davai_app into %s. The old folders can be deleted once you have checked the new ones.",
            copied, paths.base,
        )
