"""Constants for Artificial Intelligence: AI services and agents, Boss AIs, MCP, machine agents, projects, tools and Hikvision vision."""
from __future__ import annotations

DOMAIN = "artificial_intelligence"
NAME = "Artificial Intelligence"
VERSION = "3.0.0"

# Public data folder (served at /local/Artificial Intelegence/). The spelling is kept as the user's existing folder.
DATA_DIR = "www/Artificial Intelegence"
PROJECTS_DIR = "Projects"
WORKSPACE_DIR = "Workspace"
APP_DIR = "Chats and Settings"
HIK_DIR = "Hikvision"
OLD_PROJECTS_DIR = "davai_projects"
OLD_APP_DIR = "davai_app"
WORKSPACE_NAME = "_workspace"

API = "/api/artificial_intelligence"
TOKEN_HEADER = "X-AI-Token"
RELAY_HEADER = "X-CAI-Relay"          # internal: the per-run relay secret (voice tools, MCP server, machine agents)
ORIGIN_HEADER = "X-CAI-Origin"        # internal, only trusted together with the relay secret: "voice" or "mcp"
TOOL_HEADER = "X-CAI-Tool"            # set by cai-tools.js: the call was made by a model, not typed by the user
APPROVAL_HEADER = "X-AI-Approval"     # a single-use approval for one write
LLM_API_ID = "cawood_ai_tools"
SESSION_DAYS = 30
RESET_MINUTES = 15
MAX_ITEM_BYTES = 25 * 1024 * 1024
KINDS = ("chats", "folders", "prompts", "models", "knowledge", "memories", "notes", "settings")

# Config entry types. A missing "type" means the backend entry created by version 1.
CONF_ENTRY_TYPE = "type"
ENTRY_BACKEND = "backend"
ENTRY_DVR = "dvr"
ENTRY_SERVICE = "service"
ENTRY_MCP = "mcp"

# Subentry types
SUB_CONVERSATION = "conversation"
SUB_AI_TASK = "ai_task"
SUB_BOSS = "boss"

# Service (AI API) settings
CONF_PRESET = "preset"
CONF_BASE_URL = "base_url"
CONF_API_KEY = "api_key"
CONF_VERIFY_SSL = "verify_ssl"
PRESETS: dict[str, tuple[str, str]] = {   # id -> (label, OpenAI-compatible base URL)
    "gemini": ("Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai"),
    "groq": ("Groq", "https://api.groq.com/openai/v1"),
    "openrouter": ("OpenRouter", "https://openrouter.ai/api/v1"),
    "cerebras": ("Cerebras", "https://api.cerebras.ai/v1"),
    "mistral": ("Mistral", "https://api.mistral.ai/v1"),
    "openai": ("OpenAI", "https://api.openai.com/v1"),
    "github": ("GitHub Models", "https://models.github.ai/inference"),
    "custom": ("Custom (any OpenAI-compatible API)", ""),
}

# Agent (subentry) settings
CONF_MODEL = "model"
CONF_PROMPT = "prompt"
CONF_DESCRIPTION = "description"
CONF_TEMPERATURE = "temperature"
CONF_TOP_P = "top_p"
CONF_MAX_TOKENS = "max_tokens"
CONF_REASONING = "reasoning"          # "none", "low", "medium", "high"
CONF_VISION = "vision"
CONF_TOOLS = "tools"                  # the model can call tools
CONF_TOOL_GROUPS = "tool_groups"      # tool groups the page offers this agent (empty = all)
CONF_LLM_HASS_API = "llm_hass_api"
# Boss settings
CONF_PRIMARY = "primary"
CONF_SECONDARY = "secondary"
CONF_HA_AGENT = "ha_agent"
CONF_PRIMARY_PROMPT = "primary_prompt"
CONF_SECONDARY_PROMPT = "secondary_prompt"
CONF_MAX_HOPS = "max_hops"
CONF_TALK_BACK = "talk_back"
CONF_SHOW_STEPS = "show_steps"
BUILTIN_HA_AGENT = "conversation.home_assistant"

# MCP server entry
CONF_URL = "url"
CONF_TRANSPORT = "transport"
CONF_TOKEN = "token"
CONF_MCP_TOOLS = "mcp_tools"          # options: {tool_name: {"enabled": bool, "safe": bool}}

# Backend options
CONF_SEARCH = "search"                # duckduckgo | searxng | brave
CONF_SEARXNG_URL = "searxng_url"
CONF_BRAVE_KEY = "brave_key"
CONF_AUTO_UPDATE = "auto_update_agents"

# Machine agents
AGENT_ONLINE_SECONDS = 120
SIGNAL_AGENT_NEW = f"{DOMAIN}_agent_new"
SIGNAL_AGENT_UPDATE = f"{DOMAIN}_agent_update"
SIGNAL_SERVICE_UPDATE = f"{DOMAIN}_service_update"

# Legacy configuration.yaml key that holds the smtp: settings (still read, so nothing has to be edited).
LEGACY_YAML_KEY = "davai"
