#!/usr/bin/env python3
"""
Cawood AI Agent 3
=================
Lets the Cawood AI (ai-cloud.html, the voice assistants and the Boss AIs) use a terminal, a browser and files on this
machine. Runs on Windows 10/11, Linux and Android (Termux). Standard library only; the browser needs Playwright.

Every request must carry a Home Assistant token (or the integration's relay secret), checked against Home Assistant,
or the backup passphrase from cai-agent.conf.json. The agent registers itself every 30 seconds and reports its system
information, so it shows in Home Assistant as a device with entities. Home Assistant updates it through /update.

Config: cai-agent.conf.json next to this file (name, listen_port, ha_url, register_token, backup_passphrase, ...).
Browser: pip install playwright && playwright install chromium
"""
import argparse
import base64
import ctypes
import hashlib
import json
import os
import platform
import queue
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

AGENT_VERSION = "3.0.0"
SCRIPT = os.path.abspath(__file__)
HERE = os.path.dirname(SCRIPT)
CONF_PATH = os.path.join(HERE, "cai-agent.conf.json")
IS_WIN = platform.system() == "Windows"
IS_TERMUX = "com.termux" in os.environ.get("PREFIX", "") or os.path.isdir("/data/data/com.termux/files/usr") and not IS_WIN
DEFAULT_CONF = {
    "name": platform.node() or "agent",
    "listen_host": "0.0.0.0",
    "listen_port": 8765,
    "ha_url": "https://cawood94.co.za",
    "backup_passphrase": "",
    "verify_tls": True,
    "allow_roots": [],          # extra absolute paths the AI may touch; [] means the whole machine
    "headless": False,
    "register": True,
    "register_token": "",
    "heartbeat_seconds": 30,
}
CONF = {}
STARTED = time.time()
_token_cache = {}


def log(*a):
    try:
        print(time.strftime("%H:%M:%S"), *a, flush=True)
    except Exception:
        pass


def load_conf():
    global CONF
    if os.path.exists(CONF_PATH):
        try:
            with open(CONF_PATH, encoding="utf-8") as fh:
                CONF = dict(DEFAULT_CONF, **json.load(fh))
        except Exception as e:
            log("Could not read config, using defaults:", e)
            CONF = dict(DEFAULT_CONF)
    else:
        CONF = dict(DEFAULT_CONF)
        with open(CONF_PATH, "w", encoding="utf-8") as fh:
            json.dump(CONF, fh, indent=2)
        log("Wrote a starter config to", CONF_PATH, "- edit ha_url, register_token and backup_passphrase, then restart.")


def _ctx():
    return None if CONF.get("verify_tls", True) else ssl._create_unverified_context()


def _ha(path):
    return CONF["ha_url"].rstrip("/") + path


# --------------------------------------------------------------------- auth
def _verify_token(token):
    now = time.time()
    hit = _token_cache.get(token)
    if hit and hit[0] > now:
        return hit[1]
    ok = None
    for path in ("/api/artificial_intelligence/verify", "/api/davai/verify"):
        try:
            req = urllib.request.Request(_ha(path), headers={"Authorization": "Bearer " + token})
            with urllib.request.urlopen(req, timeout=8, context=_ctx()) as r:
                ok = bool(json.loads(r.read()).get("ok", False))
                break
        except urllib.error.HTTPError as e:
            if e.code == 404:
                continue
            ok = False
            break
        except Exception:
            _token_cache[token] = (now + 15, False)
            return False
    ok = bool(ok)
    _token_cache[token] = (now + 300, ok)
    return ok


def authorized(headers):
    tok = (headers.get("Authorization") or "").replace("Bearer ", "").strip()
    if tok and _verify_token(tok):
        return True
    bp = CONF.get("backup_passphrase") or ""
    return bool(bp) and (headers.get("X-Backup-Pass") or "") == bp


# --------------------------------------------------------------- system info
def _read(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return ""


def _getprop(key):
    try:
        return subprocess.run(["getprop", key], capture_output=True, text=True, timeout=3).stdout.strip()
    except Exception:
        return ""


def os_name():
    if IS_WIN:
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
            name = winreg.QueryValueEx(k, "ProductName")[0]
            build = int(winreg.QueryValueEx(k, "CurrentBuild")[0])
            try:
                disp = winreg.QueryValueEx(k, "DisplayVersion")[0]
            except OSError:
                disp = ""
            if build >= 22000:
                name = name.replace("Windows 10", "Windows 11")
            return f"{name} {disp}".strip()
        except Exception:
            return f"Windows {platform.release()}"
    if IS_TERMUX:
        rel = _getprop("ro.build.version.release")
        model = _getprop("ro.product.model")
        return f"Android {rel} (Termux{', ' + model if model else ''})" if rel else "Android (Termux)"
    for line in _read("/etc/os-release").splitlines():
        if line.startswith("PRETTY_NAME="):
            return line.split("=", 1)[1].strip().strip('"')
    return f"{platform.system()} {platform.release()}"


def cpu_name():
    if IS_WIN:
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
            return winreg.QueryValueEx(k, "ProcessorNameString")[0].strip()
        except Exception:
            return platform.processor() or "unknown"
    info = _read("/proc/cpuinfo")
    for key in ("model name", "Hardware", "Processor", "cpu model"):
        for line in info.splitlines():
            if line.lower().startswith(key.lower()) and ":" in line:
                return line.split(":", 1)[1].strip()
    if IS_TERMUX:
        soc = _getprop("ro.soc.model") or _getprop("ro.board.platform")
        if soc:
            return soc
    return platform.machine() or "unknown"


def ram_total():
    if IS_WIN:
        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong), ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong), ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        try:
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ullTotalPhys)
        except Exception:
            return None
    for line in _read("/proc/meminfo").splitlines():
        if line.startswith("MemTotal:"):
            try:
                return int(line.split()[1]) * 1024
            except (IndexError, ValueError):
                return None
    return None


def uptime_s():
    if IS_WIN:
        try:
            f = ctypes.windll.kernel32.GetTickCount64
            f.restype = ctypes.c_ulonglong
            return int(f() / 1000)
        except Exception:
            return None
    try:
        return int(float(_read("/proc/uptime").split()[0]))
    except (IndexError, ValueError):
        return int(time.time() - STARTED)


_STATIC = {}


def sysinfo():
    if not _STATIC:
        _STATIC.update(os_name=os_name(), cpu=cpu_name(), cores=os.cpu_count(), ram_total=ram_total(), hostname=platform.node(),
                       platform="android" if IS_TERMUX else platform.system().lower(), python=platform.python_version())
    return dict(_STATIC, uptime_s=uptime_s())


def _playwright_installed():
    if IS_TERMUX:
        return False
    try:
        import playwright  # noqa: F401
        return True
    except ImportError:
        return False


def caps():
    c = ["term", "files"]
    if _playwright_installed():
        c.append("browser")
    return c


# ------------------------------------------------------------------- files
def _check_root(path):
    roots = CONF.get("allow_roots") or []
    if not roots:
        return True
    rp = os.path.realpath(path)
    return any(os.path.commonpath([rp, os.path.realpath(r)]) == os.path.realpath(r) for r in roots)


def _entry(path, name):
    try:
        isdir = os.path.isdir(path)
        st = os.stat(path, follow_symlinks=False)
        return {"name": name, "type": "dir" if isdir else "file", "size": None if isdir else st.st_size, "modified": int(st.st_mtime * 1000)}
    except OSError:
        return {"name": name, "type": "file", "size": None, "modified": 0}


def file_op(body):
    op = body.get("op")
    path = body.get("path", "")
    if op == "roots":
        if IS_WIN:
            import string
            return {"roots": [d + ":\\" for d in string.ascii_uppercase if os.path.exists(d + ":\\")], "home": os.path.expanduser("~"), "os": "windows"}
        return {"roots": ["/"], "home": os.path.expanduser("~"), "os": "android" if IS_TERMUX else platform.system().lower()}
    if not path:
        raise ValueError("path required")
    if not _check_root(path):
        raise PermissionError("Path is outside the agent's allowed roots")
    if op == "list":
        if not os.path.isdir(path):
            raise FileNotFoundError("Not a folder")
        return {"path": path, "entries": sorted((_entry(os.path.join(path, n), n) for n in os.listdir(path)), key=lambda e: e["name"].lower())}
    if op == "read":
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
        off = int(body.get("offset", 0) or 0)
        mx = max(1000, min(200000, int(body.get("max_chars") or 200000)))
        chunk = text[off:off + mx]
        return {"path": path, "content": chunk, "offset": off, "total_chars": len(text), "truncated": off + len(chunk) < len(text)}
    if op == "write":
        mode = body.get("mode", "overwrite")
        if mode == "create" and os.path.exists(path):
            raise FileExistsError("File exists")
        bak = None
        if body.get("backup", True) and os.path.isfile(path) and mode != "append":
            bak = path + ".cai-bak"
            try:
                shutil.copy2(path, bak)
            except OSError:
                bak = None
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "a" if mode == "append" else "w", encoding="utf-8", newline="") as fh:
            fh.write(str(body.get("content", "")))
        return {"ok": True, "path": path, "bytes": os.path.getsize(path), "backup": bak}
    if op == "mkdir":
        os.makedirs(path, exist_ok=True)
        return {"ok": True, "path": path}
    if op == "delete":
        if os.path.isdir(path):
            if os.listdir(path) and not body.get("recursive"):
                raise OSError("Folder not empty")
            shutil.rmtree(path)
        else:
            os.remove(path)
        return {"ok": True, "path": path}
    if op == "move":
        shutil.move(path, body["to"])
        return {"ok": True}
    raise ValueError("Unknown file op: " + str(op))


# ---------------------------------------------------------------- terminal
def _shell_args(cmd):
    if IS_WIN:
        return {"args": cmd, "shell": True}
    sh = "/bin/sh" if os.path.exists("/bin/sh") else shutil.which("sh") or "sh"
    return {"args": [sh, "-lc", cmd], "shell": False}


def _cd(cmd, cwd):
    """Handle a bare 'cd x' like a terminal: returns the new folder, or None if it is not a bare cd."""
    s = cmd.strip()
    low = s.lower()
    if not (low == "cd" or low.startswith("cd ") or low.startswith("cd\\") or low.startswith("cd/") or low.startswith("chdir ")):
        return None
    if any(ch in s for ch in "&|;><"):
        return None
    arg = s.split(None, 1)[1].strip() if len(s.split(None, 1)) > 1 else ""
    if IS_WIN and arg.lower().startswith("/d "):
        arg = arg[3:].strip()
    arg = arg.strip('"')
    if not arg:
        return cwd if IS_WIN else os.path.expanduser("~")
    return os.path.normpath(os.path.join(cwd, os.path.expanduser(arg)))


def term_op(body):
    cmd = body.get("command", "")
    if not cmd.strip():
        raise ValueError("Empty command")
    cwd = body.get("cwd") or (HERE if IS_WIN else os.path.expanduser("~"))
    if not os.path.isdir(cwd):
        cwd = os.path.expanduser("~")
    new = _cd(cmd, cwd)
    if new is not None:
        if not os.path.isdir(new):
            return {"ok": True, "code": 1, "output": f"The folder does not exist: {new}\n", "cwd": cwd}
        return {"ok": True, "code": 0, "output": (new + "\n") if IS_WIN and cmd.strip().lower() == "cd" else "", "cwd": new}
    try:
        a = _shell_args(cmd)
        proc = subprocess.run(a["args"], shell=a["shell"], cwd=cwd, capture_output=True, text=True, timeout=float(body.get("timeout", 120)), errors="replace",
                              creationflags=0x08000000 if IS_WIN else 0)
        out = (proc.stdout or "") + (proc.stderr or "")
        return {"ok": True, "code": proc.returncode, "output": out[-200000:], "cwd": cwd}
    except subprocess.TimeoutExpired as e:
        return {"ok": True, "code": 124, "output": (e.stdout or "") + "\n(timed out)", "cwd": cwd}


def term_stream(body, write):
    """Run a command and send its output line by line ({"out": ...}), then {"done": true, "code", "cwd"}."""
    cmd = body.get("command", "")
    cwd = body.get("cwd") or (HERE if IS_WIN else os.path.expanduser("~"))
    if not os.path.isdir(cwd):
        cwd = os.path.expanduser("~")
    new = _cd(cmd, cwd)
    if new is not None:
        if not os.path.isdir(new):
            write({"out": f"The folder does not exist: {new}\n"})
            write({"done": True, "code": 1, "cwd": cwd})
        else:
            if IS_WIN and cmd.strip().lower() == "cd":
                write({"out": new + "\n"})
            write({"done": True, "code": 0, "cwd": new})
        return
    a = _shell_args(cmd)
    proc = subprocess.Popen(a["args"], shell=a["shell"], cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                            creationflags=0x08000000 if IS_WIN else 0)
    deadline = time.time() + float(body.get("timeout", 600) or 600)
    try:
        while True:
            line = proc.stdout.readline()
            if not line:
                break
            write({"out": _dec(line)})
            if time.time() > deadline:
                proc.kill()
                write({"out": "\n(timed out)\n"})
                break
        code = proc.wait(timeout=5)
    except (BrokenPipeError, ConnectionResetError):
        proc.kill()
        raise
    write({"done": True, "code": code, "cwd": cwd})


def _dec(b):
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("cp1252" if IS_WIN else "latin-1", "replace")


# ------------------------------------------------------------------ browser
class Browser:
    """Playwright's sync API must stay on one thread, so every browser action runs on this worker."""

    def __init__(self):
        self.q = queue.Queue()
        self.pw = self.browser = self.page = None
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            fn, box, ev = self.q.get()
            try:
                box["ok"] = fn()
            except Exception as e:
                box["err"] = e
            ev.set()

    def run(self, fn, timeout=120):
        box, ev = {}, threading.Event()
        self.q.put((fn, box, ev))
        if not ev.wait(timeout):
            raise TimeoutError("The browser did not answer in time")
        if "err" in box:
            raise box["err"]
        return box.get("ok")

    def _ensure(self):
        if self.page:
            try:
                self.page.title()
                return
            except Exception:
                self.close()
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start()
        self.browser = self.pw.chromium.launch(headless=bool(CONF.get("headless", False)))
        ctx = self.browser.new_context(viewport={"width": 1280, "height": 800})
        self.page = ctx.new_page()

    def close(self):
        for obj, meth in ((self.browser, "close"), (self.pw, "stop")):
            try:
                if obj:
                    getattr(obj, meth)()
            except Exception:
                pass
        self.pw = self.browser = self.page = None

    def act(self, body):
        action = body.get("action")
        if action == "status":
            return {"available": _playwright_installed(), "open": bool(self.page)}
        if action == "close":
            self.close()
            return {"ok": True}
        self._ensure()
        pg = self.page
        if action == "goto":
            url = str(body.get("url") or "")
            if url and "://" not in url:
                url = "https://" + url
            pg.goto(url, timeout=45000, wait_until="domcontentloaded")
        elif action == "click":
            pg.click(body["selector"], timeout=15000)
        elif action == "click_xy":
            pg.mouse.click(float(body.get("x", 0)), float(body.get("y", 0)))
            pg.wait_for_timeout(300)
        elif action == "type":
            pg.fill(body["selector"], body.get("text", ""), timeout=15000)
        elif action == "type_text":
            pg.keyboard.type(str(body.get("text", "")))
        elif action == "press":
            pg.keyboard.press(body.get("key", "Enter"))
            pg.wait_for_timeout(300)
        elif action == "scroll":
            pg.mouse.wheel(0, float(body.get("dy", 300)))
            pg.wait_for_timeout(150)
        elif action == "back":
            pg.go_back(timeout=20000)
        elif action == "forward":
            pg.go_forward(timeout=20000)
        elif action == "reload":
            pg.reload(timeout=30000)
        elif action == "eval":
            return {"ok": True, "result": str(pg.evaluate(body["script"]))[:8000]}
        elif action not in ("read", "screenshot"):
            raise ValueError("Unknown browser action: " + str(action))
        out = {"ok": True, "url": pg.url, "title": pg.title(), "viewport": [pg.viewport_size["width"], pg.viewport_size["height"]] if pg.viewport_size else [1280, 800]}
        if action == "read":
            out["text"] = pg.evaluate("() => document.body ? document.body.innerText : ''")[:12000]
            return out
        shot = pg.screenshot(type="jpeg", quality=60, full_page=bool(body.get("full")))
        out["image"] = base64.b64encode(shot).decode()
        if action in ("goto", "click", "type", "eval"):
            out["text"] = pg.evaluate("() => document.body ? document.body.innerText : ''")[:12000]
        return out


BROWSER = None


def browser_op(body):
    global BROWSER
    if not _playwright_installed():
        raise NotImplementedError("The browser is not available on this machine. Install Playwright: pip install playwright && playwright install chromium")
    if BROWSER is None:
        BROWSER = Browser()
    return BROWSER.run(lambda: BROWSER.act(body), timeout=150)


# ------------------------------------------------------------------ updates
def update_op(body):
    code = str(body.get("code") or "")
    if not code or "AGENT_VERSION" not in code:
        raise ValueError("No agent code received")
    if body.get("sha256") and hashlib.sha256(code.encode()).hexdigest() != body["sha256"]:
        raise ValueError("The update was damaged in transit")
    compile(code, SCRIPT, "exec")  # refuse anything that does not parse
    tmp = SCRIPT + ".new"
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(code)
    shutil.copy2(SCRIPT, SCRIPT + ".bak")
    os.replace(tmp, SCRIPT)
    threading.Thread(target=_restart, daemon=True).start()
    return {"ok": True, "restarting": True, "version": body.get("version")}


def _restart():
    time.sleep(1.5)
    log("Restarting with the new version")
    args = [sys.executable, SCRIPT] + sys.argv[1:]
    if IS_WIN:
        flags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen(args, cwd=HERE, creationflags=flags, close_fds=True)
        os._exit(0)
    try:
        SERVER.server_close()
    except Exception:
        pass
    os.execv(sys.executable, args)


# --------------------------------------------------------------- HTTP server
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "*"))
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Backup-Pass")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self._cors()
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/ping"):
            return self._send(200, {"ok": True, "name": CONF["name"], "os": "android" if IS_TERMUX else platform.system().lower(), "caps": caps(), "version": AGENT_VERSION})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not authorized(self.headers):
            return self._send(401, {"error": "unauthorized (token invalid and backup passphrase missing or wrong)"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._send(400, {"error": "bad json"})
        try:
            if self.path.startswith("/file"):
                return self._send(200, file_op(body))
            if self.path.startswith("/term"):
                if body.get("stream"):
                    return self._stream(body)
                return self._send(200, term_op(body))
            if self.path.startswith("/browser"):
                return self._send(200, browser_op(body))
            if self.path.startswith("/update"):
                return self._send(200, update_op(body))
            self._send(404, {"error": "unknown endpoint"})
        except PermissionError as e:
            self._send(403, {"error": str(e)})
        except FileNotFoundError as e:
            self._send(404, {"error": str(e)})
        except FileExistsError as e:
            self._send(409, {"error": str(e)})
        except NotImplementedError as e:
            self._send(501, {"error": str(e)})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self._send(400, {"error": str(e)[:300]})
            except Exception:
                pass

    def _stream(self, body):
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Transfer-Encoding", "chunked")
        self._cors()
        self.end_headers()

        def write(obj):
            data = (json.dumps(obj) + "\n").encode()
            self.wfile.write(b"%x\r\n%s\r\n" % (len(data), data))
            self.wfile.flush()

        try:
            term_stream(body, write)
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception as e:
            try:
                write({"out": f"Error: {e}\n"})
                write({"done": True, "code": 1, "cwd": body.get("cwd") or ""})
            except Exception:
                return
        try:
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except Exception:
            pass


# -------------------------------------------------------------- registration
def _lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def register_loop():
    paths = ["/api/artificial_intelligence/agents", "/api/davai/agents"]
    while True:
        tok = CONF.get("register_token") or ""
        if tok:
            payload = json.dumps({"name": CONF["name"], "url": "http://%s:%s" % (_lan_ip(), CONF["listen_port"]), "os": "android" if IS_TERMUX else platform.system().lower(),
                                  "caps": caps(), "version": AGENT_VERSION, "info": sysinfo()}).encode()
            for path in list(paths):
                try:
                    req = urllib.request.Request(_ha(path), data=payload, method="POST", headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"})
                    urllib.request.urlopen(req, timeout=8, context=_ctx()).read()
                    if path != paths[0]:
                        paths.remove(path)
                        paths.insert(0, path)
                    break
                except urllib.error.HTTPError as e:
                    if e.code == 404:
                        continue
                    log("Registration refused:", e.code)
                    break
                except Exception as e:
                    log("Home Assistant not reachable:", e)
                    break
        time.sleep(max(10, int(CONF.get("heartbeat_seconds") or 30)))


SERVER = None


def main():
    global SERVER
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int)
    ap.add_argument("--name")
    a = ap.parse_args()
    load_conf()
    if a.port:
        CONF["listen_port"] = a.port
    if a.name:
        CONF["name"] = a.name
    for attempt in range(30):  # after an update the old process may still hold the port for a moment
        try:
            SERVER = ThreadingHTTPServer((CONF["listen_host"], int(CONF["listen_port"])), Handler)
            break
        except OSError as e:
            if attempt == 29:
                raise
            log("Port busy, retrying:", e)
            time.sleep(1)
    SERVER.daemon_threads = True
    if CONF.get("register") and CONF.get("register_token"):
        threading.Thread(target=register_loop, daemon=True).start()
    log("Cawood AI Agent %s '%s' on %s:%s (%s)" % (AGENT_VERSION, CONF["name"], _lan_ip(), CONF["listen_port"], ", ".join(caps())))
    try:
        SERVER.serve_forever()
    except KeyboardInterrupt:
        log("Stopped.")


if __name__ == "__main__":
    main()
