"""Entities for AI services (connected, last error, requests, tokens) and machine agents (one device each)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from homeassistant.components.binary_sensor import BinarySensorDeviceClass, BinarySensorEntity
from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory, UnitOfInformation, UnitOfTime
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.dispatcher import async_dispatcher_connect
from homeassistant.helpers.entity import Entity
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CONF_ENTRY_TYPE, ENTRY_BACKEND, ENTRY_SERVICE, SIGNAL_AGENT_NEW, SIGNAL_AGENT_UPDATE, SIGNAL_SERVICE_UPDATE
from .conversation import service_device
from .runtime import get_runtime


# ---------------------------------------------------------------------- services
class _ServiceEntity(Entity):
    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(self, entry: ConfigEntry, key: str, name: str) -> None:
        self.entry = entry
        self._attr_unique_id = f"{entry.entry_id}_{key}"
        self._attr_name = name
        self._attr_device_info = service_device(entry)

    @property
    def stats(self):
        c = get_runtime(self.hass).providers.get(self.entry.entry_id)
        return c.stats if c else None

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(async_dispatcher_connect(self.hass, f"{SIGNAL_SERVICE_UPDATE}_{self.entry.entry_id}", self.async_write_ha_state))


class ServiceConnected(_ServiceEntity, BinarySensorEntity):
    _attr_device_class = BinarySensorDeviceClass.CONNECTIVITY

    @property
    def is_on(self) -> bool | None:
        st = self.stats
        return None if st is None or st.connected is None else bool(st.connected)


class ServiceSensor(_ServiceEntity, SensorEntity):
    def __init__(self, entry: ConfigEntry, key: str, name: str, attr: str, unit: str | None = None, diag: bool = False) -> None:
        super().__init__(entry, key, name)
        self._attr = attr
        self._attr_native_unit_of_measurement = unit
        if unit:
            self._attr_state_class = SensorStateClass.TOTAL
        if diag:
            self._attr_entity_category = EntityCategory.DIAGNOSTIC

    @property
    def native_value(self) -> Any:
        st = self.stats
        if st is None:
            return None
        if self._attr == "last_error":
            return (st.last_error or "None")[:250]
        if self._attr == "models":
            return len(st.models)
        return getattr(st, self._attr)


def service_binary_sensors(entry: ConfigEntry) -> list:
    return [ServiceConnected(entry, "connected", "Connected")]


def service_sensors(entry: ConfigEntry) -> list:
    return [ServiceSensor(entry, "requests", "Requests today", "requests", "requests"), ServiceSensor(entry, "tokens", "Tokens today", "tokens", "tokens"),
            ServiceSensor(entry, "last_error", "Last error", "last_error", diag=True), ServiceSensor(entry, "models", "Models available", "models", diag=True)]


# ---------------------------------------------------------------------- machine agents
class _AgentEntity(Entity):
    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(self, hass: HomeAssistant, agent: str, key: str, name: str) -> None:
        self.agent = agent
        self._attr_unique_id = f"agent_{agent}_{key}"
        self._attr_name = name
        self._attr_device_info = DeviceInfo(**get_runtime(hass).agents.device_info(agent))

    @property
    def a(self) -> dict:
        return get_runtime(self.hass).agents.data.get(self.agent, {})

    @property
    def is_online(self) -> bool:
        return get_runtime(self.hass).agents.online(self.a)

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(async_dispatcher_connect(self.hass, f"{SIGNAL_AGENT_UPDATE}_{self.agent}", self.async_write_ha_state))


class AgentBinary(_AgentEntity, BinarySensorEntity):
    def __init__(self, hass, agent, key, name, dclass=None) -> None:
        super().__init__(hass, agent, key, name)
        self._key = key
        self._attr_device_class = dclass

    @property
    def is_on(self) -> bool:
        if self._key == "connected":
            return self.is_online
        cap = {"terminal": "term", "browser": "browser"}[self._key]
        return self.is_online and cap in (self.a.get("caps") or [])


class AgentSensor(_AgentEntity, SensorEntity):
    def __init__(self, hass, agent, key, name, **kw) -> None:
        super().__init__(hass, agent, key, name)
        self._key = key
        for k, v in kw.items():
            setattr(self, f"_attr_{k}", v)

    @property
    def native_value(self) -> Any:
        a, info = self.a, self.a.get("info") or {}
        if self._key == "last_contact":
            ts = float(a.get("ts", 0))
            return datetime.fromtimestamp(ts, timezone.utc) if ts else None
        if self._key == "uptime":
            return info.get("uptime_s") if self.is_online else None
        if self._key == "os":
            return (info.get("os_name") or a.get("os") or None)
        if self._key == "cpu":
            cpu = info.get("cpu") or None
            return f"{cpu} ({info.get('cores')} cores)" if cpu and info.get("cores") and "core" not in cpu.lower() else cpu
        if self._key == "ram":
            return round(info["ram_total"] / 2**30, 1) if info.get("ram_total") else None
        if self._key == "version":
            return a.get("version") or "2.x"
        return None


def agent_entities(hass: HomeAssistant, agent: str) -> tuple[list, list]:
    diag = EntityCategory.DIAGNOSTIC
    binaries = [AgentBinary(hass, agent, "connected", "Connected", BinarySensorDeviceClass.CONNECTIVITY),
                AgentBinary(hass, agent, "terminal", "Terminal tools available"), AgentBinary(hass, agent, "browser", "Browser tools available")]
    sensors = [AgentSensor(hass, agent, "uptime", "Uptime", device_class=SensorDeviceClass.DURATION, native_unit_of_measurement=UnitOfTime.SECONDS,
                           suggested_unit_of_measurement=UnitOfTime.HOURS, suggested_display_precision=1),
               AgentSensor(hass, agent, "last_contact", "Last contact", device_class=SensorDeviceClass.TIMESTAMP),
               AgentSensor(hass, agent, "os", "Operating system", entity_category=diag, icon="mdi:monitor"),
               AgentSensor(hass, agent, "cpu", "CPU", entity_category=diag, icon="mdi:cpu-64-bit"),
               AgentSensor(hass, agent, "ram", "RAM", entity_category=diag, native_unit_of_measurement=UnitOfInformation.GIGABYTES, icon="mdi:memory"),
               AgentSensor(hass, agent, "version", "Agent version", entity_category=diag, icon="mdi:tag")]
    return binaries, sensors


async def setup_agent_platform(hass: HomeAssistant, entry: ConfigEntry, add: AddEntitiesCallback, part: int) -> None:
    """part 0 = binary sensors, 1 = sensors. New agents get entities as they register."""
    hub = get_runtime(hass).agents
    if hub is None:
        return
    done: set[str] = set()

    @callback
    def add_agent(name: str) -> None:
        if name in done:
            return
        done.add(name)
        add(agent_entities(hass, name)[part])

    for name in hub.names():
        add_agent(name)
    entry.async_on_unload(async_dispatcher_connect(hass, SIGNAL_AGENT_NEW, add_agent))


async def async_setup_extra(hass: HomeAssistant, entry: ConfigEntry, add: AddEntitiesCallback, part: int) -> bool:
    """Entities for service and backend entries. Returns True when handled."""
    kind = entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
    if kind == ENTRY_SERVICE:
        add(service_binary_sensors(entry) if part == 0 else service_sensors(entry))
        return True
    if kind == ENTRY_BACKEND:
        await setup_agent_platform(hass, entry, add, part)
        return True
    return kind != "dvr"
