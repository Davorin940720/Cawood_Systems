"""Projects, shared app storage, e-mail sharing and the AI's sandboxed files (ported from davai 1.6.0).

Projects live in <data>/Projects/<Project Name>/
    Creation_Data.davai   (JSON, project details)
    sources/              (uploaded files and manual entries)
    chats/                (<id>.davai JSON chat histories)
Shared app data (settings, chats, prompts, knowledge ...) lives in <data>/Chats and Settings/ so every browser sees it.
The AI's free-use files live in <data>/Workspace/ (shown to the AI as _workspace).
All endpoints sit under /api/artificial_intelligence/ and accept a Home Assistant token or an AI login.
"""
from __future__ import annotations

import hashlib
import hmac
import html as htmllib
import json
import logging
import math
import os
import re
import secrets
import shutil
import smtplib
import ssl
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from urllib.parse import quote
from email.message import EmailMessage
from email.utils import formataddr

from homeassistant.core import HomeAssistant

from .authz import AuthedView
from .const import API, WORKSPACE_NAME
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)
WORKSPACE = WORKSPACE_NAME                 # virtual folder name the AI sees
DOC_KINDS = {"settings": dict, "prompts": list, "presets": list, "memories": list, "folders": list}
FS_MAX_WRITE = 1_000_000
FS_MAX_READ = 60_000
DATA_FILE = "Creation_Data.davai"
TEXT_EXT = {".txt", ".md", ".csv", ".json", ".log", ".yaml", ".yml", ".xml"}
SERVED_AS_TEXT = TEXT_EXT | {".html", ".htm"}
INDEXED_EXT = {".pdf", ".html", ".htm"}   # text is extracted once and cached in <project>/index/
DEFAULT_BUDGET = 6000                      # characters of source excerpts sent with each message
SMALL_SOURCE = 1500                        # sources this small are always included in full
FS_TEXT_EXT = TEXT_EXT | {".html", ".htm", ".py", ".ps1", ".psm1", ".sh", ".bat", ".js", ".css", ".ini", ".conf",
                          ".cfg", ".toml", ".sql", ".tex", ".tsv", ".jsonl", ".rtf"}
HIDDEN = {"passwordSalt", "passwordHash"}
_WORKSPACE_PATH: dict[str, str | None] = {"path": None}


def set_workspace(path: str) -> None:
    _WORKSPACE_PATH["path"] = path


def _workspace_path(root: str) -> str:
    return os.path.realpath(_WORKSPACE_PATH["path"] or os.path.join(os.path.realpath(root), WORKSPACE))


# ---------------------------------------------------------------- helpers
def _clean(name: str, limit: int = 60) -> str:
    name = re.sub(r"[^\w .-]", "", str(name), flags=re.UNICODE)
    name = re.sub(r"\s+", " ", name).strip().strip(".").strip()
    return name[:limit].strip()


def _pdir(root: str, folder: str) -> str | None:
    """Resolve a project folder, refusing anything outside the root."""
    real_root = os.path.realpath(root)
    path = os.path.realpath(os.path.join(real_root, folder))
    if os.path.dirname(path) != real_root or not os.path.isdir(path):
        return None
    return path


def _read_json(path: str):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _write_json(path: str, obj) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)


def _hash(password: str, salt_hex: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 120000).hex()


def _public(data: dict) -> dict:
    return {k: v for k, v in data.items() if k not in HIDDEN}


def _unique(dirpath: str, stem: str, ext: str) -> str:
    name, i = stem + ext, 2
    while os.path.exists(os.path.join(dirpath, name)):
        name = f"{stem} ({i}){ext}"
        i += 1
    return name


def _unique_pair(dirpath: str, stem: str) -> str:
    s, i = stem, 2
    while any(os.path.exists(os.path.join(dirpath, s + e)) for e in (".html", ".txt")):
        s = f"{stem} ({i})"
        i += 1
    return s


def _load_project(path: str) -> dict | None:
    data = _read_json(os.path.join(path, DATA_FILE))
    if not isinstance(data, dict):
        return None
    sources = []
    sdir = os.path.join(path, "sources")
    if os.path.isdir(sdir):
        names = sorted((n for n in os.listdir(sdir) if not n.startswith(".") and os.path.isfile(os.path.join(sdir, n))), key=str.lower)
        manual = {
            os.path.splitext(n)[0]
            for n in names
            if n.lower().endswith(".html") and os.path.splitext(n)[0] + ".txt" in names
        }
        for n in names:
            stem, ext = os.path.splitext(n)
            ext = ext.lower()
            if ext == ".txt" and stem in manual:
                continue
            is_manual = ext == ".html" and stem in manual
            if is_manual or ext in TEXT_EXT:
                ai = "yes"
            elif ext in INDEXED_EXT:
                idx = os.path.join(path, "index", n + ".txt")
                ai = "pending" if not os.path.isfile(idx) else ("yes" if os.path.getsize(idx) > 0 else "no")
            else:
                ai = "no"
            sources.append({
                "name": n,
                "title": stem if is_manual else n,
                "manual": is_manual,
                "size": os.path.getsize(os.path.join(sdir, n)),
                "ai": ai,
            })
    chats = []
    cdir = os.path.join(path, "chats")
    if os.path.isdir(cdir):
        for n in os.listdir(cdir):
            if n.endswith(".davai"):
                c = _read_json(os.path.join(cdir, n))
                if isinstance(c, dict):
                    chats.append(c)
    chats.sort(key=lambda c: c.get("updated", 0), reverse=True)
    return {"folder": os.path.basename(path), "data": _public(data), "sources": sources, "chats": chats}


# ------------------------------------------- text extraction and retrieval
class _HTMLText(HTMLParser):
    _SKIP = {"script", "style", "noscript", "template", "head", "svg"}
    _BLOCK = {"p", "div", "br", "li", "ul", "ol", "tr", "table", "section", "article", "h1", "h2", "h3",
              "h4", "h5", "h6", "pre", "blockquote", "hr", "header", "footer"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP:
            self.skip += 1
        elif tag in self._BLOCK:
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in self._SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self._BLOCK:
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def _html_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        raw = fh.read()
    parser = _HTMLText()
    parser.feed(raw)
    text = "".join(parser.out)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r" ?\n ?", "\n", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _pdf_text(path: str) -> str:
    from pypdf import PdfReader  # installed by Home Assistant from the manifest requirements
    reader = PdfReader(path)
    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception:  # noqa: BLE001
            return ""
    parts, total = [], 0
    for page in reader.pages:
        try:
            t = (page.extract_text() or "").strip()
        except Exception:  # noqa: BLE001
            t = ""
        if t:
            parts.append(t)
            total += len(t)
        if total > 3_000_000:
            break
    return "\n\n".join(parts)


def _build_index(p: str, name: str) -> None:
    """Extract text from an uploaded PDF/HTML into <project>/index/<name>.txt (empty file = nothing readable)."""
    src = os.path.join(p, "sources", name)
    ext = os.path.splitext(name)[1].lower()
    if not os.path.isfile(src) or ext not in INDEXED_EXT:
        return
    try:
        text = _pdf_text(src) if ext == ".pdf" else _html_text(src)
    except ImportError:
        _LOGGER.warning("PDF reader unavailable, %s not indexed", name)
        return
    except Exception as err:  # noqa: BLE001
        _LOGGER.warning("could not read %s: %s", name, err)
        text = ""
    idir = os.path.join(p, "index")
    os.makedirs(idir, exist_ok=True)
    with open(os.path.join(idir, name + ".txt"), "w", encoding="utf-8") as fh:
        fh.write(text)


async def _bg_index(rt: Runtime, p: str, name: str) -> None:
    hass, busy = rt.hass, rt.busy
    key = (p, name)
    if key in busy:
        return
    busy.add(key)
    try:
        await hass.async_add_executor_job(_build_index, p, name)
    finally:
        busy.discard(key)


def _missing_indexes(root: str) -> list:
    out = []
    if not os.path.isdir(root):
        return out
    for folder in os.listdir(root):
        p = _pdir(root, folder)
        sdir = os.path.join(p, "sources") if p else ""
        if p and os.path.isdir(sdir):
            for n in os.listdir(sdir):
                stem, ext = os.path.splitext(n)
                if not os.path.isfile(os.path.join(sdir, n)) or ext.lower() not in INDEXED_EXT or os.path.isfile(os.path.join(p, "index", n + ".txt")):
                    continue
                if ext.lower() == ".html" and os.path.isfile(os.path.join(sdir, stem + ".txt")):
                    continue  # rich copy of a manual entry
                out.append((p, n))
    return out


STOP = set("""the and for with that this these those are was were been have has had you your yours not but can could
should would will about into than then from what which who whom how why when where does did please tell show give
list any some there their them they its our out use using used just like also more most very""".split())


def _tokens(s: str) -> list:
    return [w for w in re.findall(r"[a-z0-9]{3,}", s.lower()) if w not in STOP]


def _chunks(text: str, size: int = 1100) -> list:
    out, buf = [], ""
    for para in re.split(r"\n\s*\n", text):
        para = para.strip()
        while len(para) > size:
            cut = para.rfind(" ", 0, size)
            cut = cut if cut > size // 2 else size
            if buf:
                out.append(buf)
                buf = ""
            out.append(para[:cut].strip())
            para = para[cut:].strip()
        if not para:
            continue
        if buf and len(buf) + len(para) + 2 > size:
            out.append(buf)
            buf = para
        else:
            buf = f"{buf}\n\n{para}" if buf else para
    if buf:
        out.append(buf)
    return [c for c in out if c.strip()]


def _source_text(p: str, name: str):
    """(text, state) where state is ok | empty | pending | unsupported."""
    path = os.path.join(p, "sources", name)
    ext = os.path.splitext(name)[1].lower()
    if ext in TEXT_EXT:
        src = path
    elif ext in INDEXED_EXT:
        src = os.path.join(p, "index", name + ".txt")
        if not os.path.isfile(src):
            return None, "pending"
    else:
        return None, "unsupported"
    try:
        with open(src, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read().strip()
    except OSError:
        return None, "unsupported"
    return (text, "ok") if text else (None, "empty")


def _build_context(p: str, query: str, budget: int) -> dict:
    sdir = os.path.join(p, "sources")
    names = sorted((n for n in os.listdir(sdir) if not n.startswith(".") and os.path.isfile(os.path.join(sdir, n))), key=str.lower) if os.path.isdir(sdir) else []
    sources, pending = [], []
    for n in names:
        stem, ext = os.path.splitext(n)
        twin_txt = os.path.isfile(os.path.join(sdir, stem + ".txt"))
        if ext.lower() == ".html" and twin_txt:
            continue  # rich copy of a manual entry; its .txt twin is used instead
        manual = ext.lower() == ".txt" and os.path.isfile(os.path.join(sdir, stem + ".html"))
        text, state = _source_text(p, n)
        if state == "pending":
            pending.append(n)
        sources.append({"name": stem if manual else n, "text": text, "state": state, "pinned": False})
    if not sources:
        return {"text": "", "sources": [], "truncated": False, "pending": []}

    parts, used = {}, 0
    for s in sources:  # small sources are always included in full
        if s["text"] and len(s["text"]) <= SMALL_SOURCE and used + len(s["text"]) <= budget * 0.4:
            parts[s["name"]] = [s["text"]]
            used += len(s["text"])
            s["pinned"] = True
    cands = []
    for s in sources:
        if s["text"] and not s["pinned"]:
            cands += [(s["name"], c) for c in _chunks(s["text"])]
    truncated = False
    if cands:
        qt = set(_tokens(query))
        toks = [Counter(_tokens(c)) for _, c in cands]
        df = Counter()
        for t in toks:
            df.update(t.keys())
        n_chunks = len(cands)
        scores = []
        for t in toks:
            sc = 0.0
            for q in qt:
                tf = t.get(q, 0)
                if tf:
                    sc += (1 + math.log(tf)) * math.log(1 + n_chunks / (1 + df[q]))
            scores.append(sc)
        chosen, total = [], used
        order = sorted(range(n_chunks), key=lambda k: -scores[k])
        if scores[order[0]] > 0:
            for k in order:
                if scores[k] <= 0:
                    break
                if total + len(cands[k][1]) > budget:
                    truncated = True
                    continue
                chosen.append(k)
                total += len(cands[k][1])
        else:  # nothing matched: the opening passage of each source
            seen = set()
            for k, (lab, c) in enumerate(cands):
                if lab in seen:
                    continue
                seen.add(lab)
                if total + len(c) > budget:
                    truncated = True
                    break
                chosen.append(k)
                total += len(c)
        for k in sorted(chosen):
            parts.setdefault(cands[k][0], []).append(cands[k][1])

    status = {"ok": "searched for relevant passages", "empty": "contains no readable text",
              "pending": "still being indexed, not yet available", "unsupported": "cannot be read (unsupported file type)"}
    lines = ["Project sources: " + "; ".join(
        f"{s['name']} ({'included in full' if s['pinned'] else status[s['state']]})" for s in sources) + "."]
    if parts:
        lines.append("Relevant excerpts from the sources (use them when relevant, and if the answer is not in them, say so):")
        for lab, chunks in parts.items():
            lines.append(f"[{lab}]\n" + "\n\n".join(chunks))
    return {
        "text": "\n\n".join(lines), "truncated": truncated, "pending": pending,
        "sources": [{"name": s["name"], "state": "pinned" if s["pinned"] else s["state"]} for s in sources],
    }


# ------------------------------------------------------------------ views
class _Base(AuthedView):
    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        super().__init__(hass, rt)
        self.root = rt.paths.projects
        self.app_root = rt.paths.app

    def _run(self, fn):
        return self.hass.async_add_executor_job(fn)


class ProjectsView(_Base):
    url = API + "/projects"
    name = "api:artificial_intelligence:p_projects"

    async def get(self, request):
        def work():
            if not os.path.isdir(self.root):
                return []
            out = []
            for n in sorted(os.listdir(self.root), key=str.lower):
                p = _pdir(self.root, n)
                if p:
                    proj = _load_project(p)
                    if proj:
                        out.append(proj)
            return out
        return self.json(await self._run(work))

    async def post(self, request):
        body = await request.json()
        name = _clean(body.get("name", ""))
        desc = str(body.get("description", "")).strip()
        if not name or not desc:
            return self.json_message("Project name and description are required", 400)
        if name.lower() == WORKSPACE:
            return self.json_message("That name is reserved", 400)
        require = bool(body.get("requireAuth"))
        username = str(body.get("username", "")).strip()
        password = str(body.get("password", ""))
        if require and (not username or not password):
            return self.json_message("Username and password are required", 400)

        def work():
            os.makedirs(self.root, exist_ok=True)
            path = os.path.join(self.root, name)
            if os.path.exists(path):
                return None
            os.makedirs(os.path.join(path, "sources"))
            os.makedirs(os.path.join(path, "chats"))
            data = {
                "version": 1,
                "name": name,
                "description": desc,
                "admin": str(body.get("admin", "")).strip(),
                "adminEmail": str(body.get("adminEmail", "")).strip(),
                "requireAuth": require,
                "username": username if require else "",
                "aiName": str(body.get("aiName", "")).strip() or "Cawood-Gemma AI",
                "userName": str(body.get("userName", "")).strip() or "Human",
                "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "sourcesNoticeShown": False,
            }
            if require:
                salt = secrets.token_hex(16)
                data["passwordSalt"] = salt
                data["passwordHash"] = _hash(password, salt)
            _write_json(os.path.join(path, DATA_FILE), data)
            return _load_project(path)

        res = await self._run(work)
        if res is None:
            return self.json_message("A project with that name already exists", 409)
        return self.json(res)


class ProjectView(_Base):
    url = API + "/projects/{folder}"
    name = "api:artificial_intelligence:p_project"

    async def get(self, request, folder):
        res = await self._run(lambda: (lambda p: _load_project(p) if p else None)(_pdir(self.root, folder)))
        if res is None:
            return self.json_message("Project not found", 404)
        return self.json(res)

    async def delete(self, request, folder):
        def work():
            p = _pdir(self.root, folder)
            if not p:
                return False
            shutil.rmtree(p)
            return True
        if not await self._run(work):
            return self.json_message("Project not found", 404)
        return self.json({"ok": True})


class AuthView(_Base):
    url = API + "/projects/{folder}/auth"
    name = "api:artificial_intelligence:p_auth"

    async def post(self, request, folder):
        body = await request.json()

        def work():
            p = _pdir(self.root, folder)
            if not p:
                return None
            d = _read_json(os.path.join(p, DATA_FILE)) or {}
            if not d.get("requireAuth"):
                return True
            user_ok = hmac.compare_digest(str(body.get("username", "")).encode(), str(d.get("username", "")).encode())
            try:
                pw_ok = hmac.compare_digest(
                    _hash(str(body.get("password", "")), d["passwordSalt"]).encode(), d["passwordHash"].encode()
                )
            except (KeyError, ValueError):
                pw_ok = False
            return user_ok and pw_ok

        res = await self._run(work)
        if res is None:
            return self.json_message("Project not found", 404)
        return self.json({"ok": bool(res)})


class FlagsView(_Base):
    url = API + "/projects/{folder}/flags"
    name = "api:artificial_intelligence:p_flags"

    async def post(self, request, folder):
        body = await request.json()

        def work():
            p = _pdir(self.root, folder)
            if not p:
                return False
            f = os.path.join(p, DATA_FILE)
            d = _read_json(f)
            if not isinstance(d, dict):
                return False
            if "sourcesNoticeShown" in body:
                d["sourcesNoticeShown"] = bool(body["sourcesNoticeShown"])
            _write_json(f, d)
            return True

        if not await self._run(work):
            return self.json_message("Project not found", 404)
        return self.json({"ok": True})


class SourcesView(_Base):
    url = API + "/projects/{folder}/sources"
    name = "api:artificial_intelligence:p_sources"

    async def post(self, request, folder):
        saved: list = []
        if request.content_type.startswith("multipart/"):
            form = await request.post()
            files = [v for v in form.values() if hasattr(v, "filename") and hasattr(v, "file")]
            if not files:
                return self.json_message("No file received", 400)

            def work():
                p = _pdir(self.root, folder)
                if not p:
                    return None
                sdir = os.path.join(p, "sources")
                os.makedirs(sdir, exist_ok=True)
                for f in files:
                    base = os.path.basename(f.filename or "file")
                    stem, ext = os.path.splitext(base)
                    stem = _clean(stem, 80) or "file"
                    ext = re.sub(r"[^\w.]", "", ext)[:10]
                    fname = _unique(sdir, stem, ext)
                    with open(os.path.join(sdir, fname), "wb") as fh:
                        shutil.copyfileobj(f.file, fh)
                    saved.append((p, fname))
                return _load_project(p)
        else:
            body = await request.json()
            title = _clean(body.get("title", ""), 80)
            html = str(body.get("html", ""))
            text = str(body.get("text", ""))
            if not title:
                return self.json_message("Source title is required", 400)

            def work():
                p = _pdir(self.root, folder)
                if not p:
                    return None
                sdir = os.path.join(p, "sources")
                os.makedirs(sdir, exist_ok=True)
                stem = _unique_pair(sdir, title)
                with open(os.path.join(sdir, stem + ".html"), "w", encoding="utf-8") as fh:
                    fh.write(html)
                with open(os.path.join(sdir, stem + ".txt"), "w", encoding="utf-8") as fh:
                    fh.write(text)
                return _load_project(p)

        res = await self._run(work)
        if res is None:
            return self.json_message("Project not found", 404)
        for proj_path, fname in saved:
            if os.path.splitext(fname)[1].lower() in INDEXED_EXT:
                self.hass.async_create_task(_bg_index(self.rt, proj_path, fname))
        return self.json(res)


class SourceView(_Base):
    url = API + "/projects/{folder}/sources/{name}"
    name = "api:artificial_intelligence:p_source"

    def _file(self, folder, name):
        p = _pdir(self.root, folder)
        if not p:
            return None
        path = os.path.join(p, "sources", os.path.basename(name))
        return path if os.path.isfile(path) else None

    async def get(self, request, folder, name):
        def work():
            path = self._file(folder, name)
            if not path:
                return None
            with open(path, "rb") as fh:
                return fh.read(), os.path.splitext(path)[1].lower()
        res = await self._run(work)
        if res is None:
            from aiohttp import web
            return web.Response(status=404, text="Not found")
        from aiohttp import web
        body, ext = res
        headers = {
            "X-Content-Type-Options": "nosniff",
            "Content-Disposition": "attachment; filename*=UTF-8''" + quote(os.path.basename(name), safe=""),
        }
        if ext in SERVED_AS_TEXT:
            return web.Response(body=body, content_type="text/plain", charset="utf-8", headers=headers)
        return web.Response(body=body, content_type="application/octet-stream", headers=headers)

    async def delete(self, request, folder, name):
        def work():
            path = self._file(folder, name)
            if not path:
                return None
            os.remove(path)
            stem, ext = os.path.splitext(path)
            if ext.lower() == ".html" and os.path.isfile(stem + ".txt"):
                os.remove(stem + ".txt")
            idx = os.path.join(os.path.dirname(os.path.dirname(path)), "index", os.path.basename(path) + ".txt")
            if os.path.isfile(idx):
                os.remove(idx)
            return _load_project(_pdir(self.root, folder))
        res = await self._run(work)
        if res is None:
            return self.json_message("Source not found", 404)
        return self.json(res)


class ContextView(_Base):
    url = API + "/projects/{folder}/context"
    name = "api:artificial_intelligence:p_context"

    async def _respond(self, folder, query, budget):
        holder = {}

        def work():
            p = _pdir(self.root, folder)
            if not p:
                return None
            holder["p"] = p
            return _build_context(p, query, budget)

        res = await self._run(work)
        if res is None:
            return self.json_message("Project not found", 404)
        for n in res.pop("pending", []):  # index anything that was never indexed (e.g. uploaded before this version)
            self.hass.async_create_task(_bg_index(self.rt, holder["p"], n))
        return self.json(res)

    async def get(self, request, folder):
        return await self._respond(folder, "", DEFAULT_BUDGET)

    async def post(self, request, folder):
        body = await request.json()
        try:
            budget = max(1000, min(60000, int(body.get("budget", DEFAULT_BUDGET))))
        except (TypeError, ValueError):
            budget = DEFAULT_BUDGET
        return await self._respond(folder, str(body.get("query", ""))[:4000], budget)


class ChatView(_Base):
    url = API + "/projects/{folder}/chats/{chat_id}"
    name = "api:artificial_intelligence:p_chat"

    async def put(self, request, folder, chat_id):
        body = await request.json()
        cid = re.sub(r"[^A-Za-z0-9_-]", "", chat_id)[:40]
        if not cid or not isinstance(body, dict):
            return self.json_message("Bad chat", 400)

        def work():
            p = _pdir(self.root, folder)
            if not p:
                return False
            cdir = os.path.join(p, "chats")
            os.makedirs(cdir, exist_ok=True)
            body["id"] = cid
            _write_json(os.path.join(cdir, cid + ".davai"), body)
            return True

        if not await self._run(work):
            return self.json_message("Project not found", 404)
        return self.json({"ok": True})

    async def delete(self, request, folder, chat_id):
        cid = re.sub(r"[^A-Za-z0-9_-]", "", chat_id)[:40]

        def work():
            p = _pdir(self.root, folder)
            if not p:
                return False
            f = os.path.join(p, "chats", cid + ".davai")
            if os.path.isfile(f):
                os.remove(f)
            return True

        if not await self._run(work):
            return self.json_message("Project not found", 404)
        return self.json({"ok": True})


# ------------------------------------------------------------ share by email
DISCLAIMER = (
    "This email was sent by Davorin's Artificial Intelligence. It is private and confidential, and is fully "
    "tracked, secured and encrypted. Unauthorised use or distribution is prohibited by international law; "
    "doing so is considered high treason, punishable by death."
)
EMAIL_RE = re.compile(r"^[^@\s<>\",;:()\[\]\\]+@[^@\s<>\",;:()\[\]\\]+\.[^@\s<>\",;:()\[\]\\]+$")
ME_BG, AI_BG = "#2b7a4b", "#e8ecef"


def _render_html(subject: str, messages: list, user_name: str, ai_name: str) -> str:
    esc = htmllib.escape
    rows = []
    for m in messages:
        mine = m["role"] == "user"
        bg, fg, lab = (ME_BG, "#ffffff", "#cfeedd") if mine else (AI_BG, "#1b1f23", "#5a646e")
        who = esc(user_name if mine else ai_name)
        body = esc(m["text"]).replace("\r\n", "\n").replace("\n", "<br>")
        rows.append(
            f'<tr><td align="{"right" if mine else "left"}" style="padding:4px 0;">'
            f'<div style="display:inline-block;max-width:80%;text-align:left;background:{bg};color:{fg};'
            f'padding:9px 12px;border-radius:14px;font:15px/1.45 Arial,Helvetica,sans-serif;">'
            f'<div style="font-size:12px;font-weight:bold;color:{lab};margin-bottom:3px;">{who}</div>{body}</div>'
            f"</td></tr>"
        )
    return (
        '<!DOCTYPE html><html><body style="margin:0;padding:16px;background:#f4f6f7;">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;margin:0 auto;'
        'background:#ffffff;border-radius:12px;padding:16px;">'
        f'<tr><td style="font:bold 18px Arial,Helvetica,sans-serif;color:#1b1f23;padding-bottom:10px;">{esc(subject)}</td></tr>'
        + "".join(rows)
        + f'<tr><td style="padding-top:18px;border-top:1px solid #dde2e6;font:12px/1.5 Arial,Helvetica,sans-serif;'
        f'color:#6b7680;">{esc(DISCLAIMER)}</td></tr></table></body></html>'
    )


def _render_text(subject: str, messages: list, user_name: str, ai_name: str) -> str:
    out = [subject, ""]
    for m in messages:
        out += [f"{user_name if m['role'] == 'user' else ai_name}:", m["text"], ""]
    out += ["--", DISCLAIMER]
    return "\n".join(out)


def _parse_recipients(raw) -> list | None:
    recipients = [r for r in re.split(r"[,;\s]+", str(raw or "")) if r]
    if not recipients or len(recipients) > 5 or not all(EMAIL_RE.match(r) for r in recipients):
        return None
    return recipients


def _send_mail(smtp: dict, recipients: list, subject: str, text: str, html: str, attachments=()) -> None:
    msg = EmailMessage()
    msg["From"] = formataddr((smtp["sender_name"], smtp["sender"]))
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(text)
    msg.add_alternative(html, subtype="html")
    for filename, content in attachments:
        msg.add_attachment(content, subtype="plain", charset="utf-8", filename=filename)
    context = ssl.create_default_context()
    with smtplib.SMTP(smtp["host"], smtp["port"], timeout=30) as server:
        server.ehlo()
        server.starttls(context=context)  # raises if the server does not offer TLS: never falls back to plain text
        server.ehlo()
        server.login(smtp["username"], smtp["password"])
        server.send_message(msg)


class ShareView(_Base):
    url = API + "/share"
    name = "api:artificial_intelligence:p_share"

    async def post(self, request):
        smtp = await self.rt.smtp()
        if not smtp:
            return self.json_message("Email is not configured. Add the smtp section under artificial_intelligence: in configuration.yaml.", 400)
        body = await request.json()
        recipients = _parse_recipients(body.get("to"))
        if recipients is None:
            return self.json_message("Enter between 1 and 5 valid email addresses", 400)
        subject = " ".join(str(body.get("subject", "")).split())[:200] or "Chat"
        raw = body.get("messages")
        if not isinstance(raw, list) or not raw or len(raw) > 500:
            return self.json_message("Nothing to send", 400)
        messages = []
        for m in raw:
            if isinstance(m, dict) and m.get("role") in ("user", "bot"):
                messages.append({"role": m["role"], "text": str(m.get("text", ""))[:20000]})
        if not messages:
            return self.json_message("Nothing to send", 400)
        user_name = str(body.get("userName", "") or "Human")[:60]
        ai_name = str(body.get("aiName", "") or "Davorin-AI")[:60]
        html = _render_html(subject, messages, user_name, ai_name)
        text = _render_text(subject, messages, user_name, ai_name)
        try:
            await self._run(lambda: _send_mail(smtp, recipients, subject, text, html))
        except smtplib.SMTPAuthenticationError:
            return self.json_message("SMTP login was rejected. Check the username and password.", 502)
        except (smtplib.SMTPException, OSError, ssl.SSLError) as err:
            return self.json_message("Email failed: " + str(err)[:200], 502)
        return self.json({"ok": True})


def _tz(hass):
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(hass.config.time_zone)
    except Exception:  # noqa: BLE001
        return timezone.utc


def _local(ms, tz):
    try:
        return datetime.fromtimestamp(float(ms) / 1000, tz)
    except (TypeError, ValueError, OverflowError, OSError):
        return datetime.now(tz)


def _chat_attachments(proj: dict, tz) -> list:
    """One .txt per chat, named '<chat name> <date> <time>.txt'."""
    d = proj["data"]
    out, used = [], set()
    for c in sorted(proj["chats"], key=lambda c: c.get("updated", 0)):
        msgs = [m for m in c.get("messages", []) if isinstance(m, dict) and m.get("role") in ("user", "bot")]
        if not msgs:
            continue
        dt = _local(c.get("updated"), tz)
        title = str(c.get("title") or "Chat")
        base = f"{_clean(title, 60) or 'Chat'} {dt:%Y-%m-%d %H-%M}"
        name, i = base + ".txt", 2
        while name in used:
            name = f"{base} ({i}).txt"
            i += 1
        used.add(name)
        lines = [title, f"Project: {d.get('name', '')}", f"Date: {dt:%Y-%m-%d %H:%M}", ""]
        for m in msgs:
            who = d.get("userName", "Human") if m["role"] == "user" else d.get("aiName", "AI")
            lines += [f"{who}:", str(m.get("text", "")), ""]
        out.append((name, "\n".join(lines)))
    return out


def _fmt_size(n: int) -> str:
    return f"{n} B" if n < 1024 else f"{n / 1024:.1f} KB" if n < 1048576 else f"{n / 1048576:.1f} MB"


def _render_project_html(proj: dict, tz, attached: int, links: dict | None = None, expires: str = "") -> str:
    esc = htmllib.escape
    d = proj["data"]
    try:
        created = datetime.fromisoformat(d.get("created", "")).astimezone(tz).strftime("%d/%m/%Y %H:%M")
    except ValueError:
        created = "-"

    def row(k, v):
        val = esc(str(v) if v else "-").replace("\n", "<br>")
        return (
            f'<tr><td style="padding:4px 14px 4px 0;color:#6b7680;font:13px Arial,Helvetica,sans-serif;'
            f'vertical-align:top;white-space:nowrap;">{esc(k)}</td>'
            f'<td style="padding:4px 0;font:14px/1.45 Arial,Helvetica,sans-serif;color:#1b1f23;">{val}</td></tr>'
        )

    def head(t):
        return (f'<div style="font:bold 14px Arial,Helvetica,sans-serif;color:{ME_BG};margin:18px 0 6px;">{esc(t)}</div>')

    li = 'style="font:14px/1.5 Arial,Helvetica,sans-serif;color:#1b1f23;margin:2px 0;"'
    info = "".join([
        row("Description", d.get("description")), row("Project admin", d.get("admin")),
        row("Admin email", d.get("adminEmail")),
        row("Authentication", "Required" if d.get("requireAuth") else "Not required"),
        row("AI name", d.get("aiName")), row("AI calls you", d.get("userName")), row("Created", created),
    ])
    links = links or {}

    def src_item(s):
        label = esc(s["title"])
        if s["name"] in links:
            label = f'<a href="{esc(links[s["name"]], quote=True)}" style="color:{ME_BG};">{label}</a>'
        return f"<li {li}>{label} ({_fmt_size(s['size'])})</li>"

    sources = "".join(src_item(s) for s in proj["sources"]) or f"<li {li}>No sources yet.</li>"
    link_note = (f'<div style="font:12px Arial,Helvetica,sans-serif;color:#6b7680;margin-top:6px;">'
                 f"Source links are signed and expire on {esc(expires)}.</div>") if links and expires else ""
    chat_items = []
    for c in proj["chats"]:
        if c.get("messages"):
            when = _local(c.get("updated"), tz).strftime("%d/%m/%Y")
            chat_items.append(f"<li {li}>{esc(str(c.get('title') or 'Chat'))} ({when})</li>")
    chats = "".join(chat_items) or f"<li {li}>No chats yet.</li>"
    note = f" Each chat is attached as a .txt file ({attached})." if attached else ""
    return (
        '<!DOCTYPE html><html><body style="margin:0;padding:16px;background:#f4f6f7;">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;margin:0 auto;'
        'background:#ffffff;border-radius:12px;padding:16px;"><tr><td>'
        f'<div style="font:bold 22px Arial,Helvetica,sans-serif;color:#1b1f23;">{esc(d.get("name", ""))}</div>'
        + head("Project information")
        + f'<table role="presentation" cellpadding="0" cellspacing="0">{info}</table>'
        + head("Sources") + f'<ul style="margin:0;padding-left:20px;">{sources}</ul>' + link_note
        + head("Chats") + f'<ul style="margin:0;padding-left:20px;">{chats}</ul>'
        + (f'<div style="font:12px Arial,Helvetica,sans-serif;color:#6b7680;margin-top:6px;">{esc(note.strip())}</div>' if note else "")
        + f'<div style="margin-top:18px;padding-top:12px;border-top:1px solid #dde2e6;font:12px/1.5 Arial,Helvetica,sans-serif;'
        f'color:#6b7680;">{esc(DISCLAIMER)}</div></td></tr></table></body></html>'
    )


def _render_project_text(proj: dict, tz, links: dict | None = None, expires: str = "") -> str:
    d = proj["data"]
    out = [d.get("name", ""), "", "Project information",
           f"Description: {d.get('description', '')}", f"Project admin: {d.get('admin') or '-'}",
           f"Admin email: {d.get('adminEmail') or '-'}",
           f"Authentication: {'Required' if d.get('requireAuth') else 'Not required'}",
           f"AI name: {d.get('aiName', '')}", f"AI calls you: {d.get('userName', '')}", "", "Sources"]
    links = links or {}
    out += [f"- {s['title']} ({_fmt_size(s['size'])})" + (f": {links[s['name']]}" if s["name"] in links else "")
            for s in proj["sources"]] or ["- No sources yet."]
    if links and expires:
        out.append(f"Source links are signed and expire on {expires}.")
    out += ["", "Chats"]
    out += [f"- {c.get('title') or 'Chat'}" for c in proj["chats"] if c.get("messages")] or ["- No chats yet."]
    return "\n".join(out + ["", "--", DISCLAIMER])


class ProjectShareView(_Base):
    url = API + "/projects/{folder}/share"
    name = "api:artificial_intelligence:p_projectshare"

    async def post(self, request, folder):
        smtp = await self.rt.smtp()
        if not smtp:
            return self.json_message("Email is not configured. Add the smtp section under artificial_intelligence: in configuration.yaml.", 400)
        body = await request.json()
        recipients = _parse_recipients(body.get("to"))
        if recipients is None:
            return self.json_message("Enter between 1 and 5 valid email addresses", 400)

        base = str(body.get("baseUrl", "")).strip().rstrip("/")
        try:
            hours = max(1, min(720, int(body.get("linkHours", 168))))
        except (TypeError, ValueError):
            hours = 168

        def build():
            p = _pdir(self.root, folder)
            proj = _load_project(p) if p else None
            if not proj:
                return None
            tz = _tz(self.hass)
            return proj, tz, _chat_attachments(proj, tz)

        res = await self._run(build)
        if res is None:
            return self.json_message("Project not found", 404)
        proj, tz, att = res
        links, expires = {}, ""
        if re.match(r"^https?://[^\s/?#]+$", base) and proj["sources"]:
            try:
                from homeassistant.components.http.auth import async_sign_path
                kwargs = {}
                rid = request.get("hass_refresh_token_id")
                if rid:
                    kwargs["refresh_token_id"] = rid
                for src in proj["sources"]:
                    path = f"{API}/projects/{quote(proj['folder'], safe='')}/sources/{quote(src['name'], safe='')}"
                    # HA returns the path decoded; re-encode it so spaces and symbols survive in an email
                    signed_path, _, query = async_sign_path(self.hass, path, timedelta(hours=hours), **kwargs).partition("?")
                    links[src["name"]] = base + quote(signed_path, safe="/%") + "?" + query
                expires = (datetime.now(tz) + timedelta(hours=hours)).strftime("%d/%m/%Y %H:%M")
            except Exception as err:  # noqa: BLE001
                _LOGGER.warning("could not sign source links: %s", err)
                links = {}
        subject = " ".join(str(proj["data"].get("name", folder)).split())[:200] or folder
        text = _render_project_text(proj, tz, links, expires)
        html = _render_project_html(proj, tz, len(att), links, expires)
        try:
            await self._run(lambda: _send_mail(smtp, recipients, subject, text, html, att))
        except smtplib.SMTPAuthenticationError:
            return self.json_message("SMTP login was rejected. Check the username and password.", 502)
        except (smtplib.SMTPException, OSError, ssl.SSLError) as err:
            return self.json_message("Email failed: " + str(err)[:200], 502)
        return self.json({"ok": True})


class UpdateView(_Base):
    url = API + "/projects/{folder}/update"
    name = "api:artificial_intelligence:p_update"

    async def post(self, request, folder):
        b = await request.json()

        def work():
            p = _pdir(self.root, folder)
            f = os.path.join(p, DATA_FILE) if p else None
            d = _read_json(f) if f else None
            if not isinstance(d, dict):
                return 404, "Project not found"
            new_name = _clean(b.get("name", d.get("name", folder)))
            desc = str(b.get("description", "")).strip()
            if not new_name or not desc:
                return 400, "Project name and description are required"
            if new_name.lower() == WORKSPACE:
                return 400, "That name is reserved"
            require = bool(b.get("requireAuth"))
            username = str(b.get("username", "")).strip()
            password = str(b.get("password", ""))
            if require:
                if not username:
                    return 400, "Username is required"
                if password:
                    salt = secrets.token_hex(16)
                    d["passwordSalt"], d["passwordHash"] = salt, _hash(password, salt)
                elif not d.get("passwordHash"):
                    return 400, "Password is required"
            else:
                d.pop("passwordSalt", None)
                d.pop("passwordHash", None)
                username = ""
            target = os.path.join(self.root, new_name)
            renaming = new_name != os.path.basename(p)
            if renaming and os.path.exists(target):
                return 409, "A project with that name already exists"
            d.update({
                "name": new_name, "description": desc,
                "admin": str(b.get("admin", "")).strip(), "adminEmail": str(b.get("adminEmail", "")).strip(),
                "requireAuth": require, "username": username,
                "aiName": str(b.get("aiName", "")).strip() or "Cawood-Gemma AI",
                "userName": str(b.get("userName", "")).strip() or "Human",
            })
            if renaming:
                try:
                    os.rename(p, target)
                except OSError as err:
                    return 500, "Could not rename the project folder: " + str(err)[:150]
                p = target
            _write_json(os.path.join(p, DATA_FILE), d)
            return 200, _load_project(p)

        code, res = await self._run(work)
        if code != 200:
            return self.json_message(res, code)
        return self.json(res)


# --------------------------------------------- shared app storage (all browsers)
def _atomic_write(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def _mtime_ms(path: str) -> int:
    try:
        return int(os.path.getmtime(path) * 1000)
    except OSError:
        return 0


def _safe_id(raw: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "", str(raw))[:60]


class AppAllView(_Base):
    url = API + "/app/all"
    name = "api:artificial_intelligence:p_app:all"

    async def get(self, request):
        try:
            since = float(request.query.get("since", 0))
        except (TypeError, ValueError):
            since = 0.0

        def work():
            out = {"serverTime": int(time.time() * 1000), "ts": {}, "chats": [], "chatIds": [], "knowledge": [], "knowledgeIds": []}
            for kind in DOC_KINDS:
                f = os.path.join(self.app_root, kind + ".json")
                if os.path.isfile(f):
                    out[kind] = _read_json(f)
                    out["ts"][kind] = _mtime_ms(f)
            for folder, key in (("chats", "chat"), ("knowledge", "knowledge")):
                d = os.path.join(self.app_root, folder)
                if not os.path.isdir(d):
                    continue
                for n in sorted(os.listdir(d)):
                    if not n.endswith(".json"):
                        continue
                    f = os.path.join(d, n)
                    out[key + "Ids" if key == "knowledge" else "chatIds"].append(n[:-5])
                    if _mtime_ms(f) > since:
                        item = _read_json(f)
                        if isinstance(item, dict):
                            out["chats" if key == "chat" else "knowledge"].append(item)
            return out
        return self.json(await self._run(work))


class AppKindView(_Base):
    url = API + "/app/{kind}"
    name = "api:artificial_intelligence:p_app:kind"

    async def put(self, request, kind):
        want = DOC_KINDS.get(kind)
        if want is None:
            return self.json_message("Unknown kind", 404)
        body = await request.json()
        if not isinstance(body, want):
            return self.json_message("Wrong data type", 400)

        def work():
            f = os.path.join(self.app_root, kind + ".json")
            _atomic_write(f, json.dumps(body, ensure_ascii=False))
            return _mtime_ms(f)
        return self.json({"ok": True, "ts": await self._run(work)})

    async def delete(self, request, kind):
        if kind != "chat":
            return self.json_message("Unsupported", 404)

        def work():
            d = os.path.join(self.app_root, "chats")
            n = 0
            if os.path.isdir(d):
                for f in os.listdir(d):
                    if f.endswith(".json"):
                        os.remove(os.path.join(d, f))
                        n += 1
            return n
        return self.json({"ok": True, "deleted": await self._run(work)})


class AppItemView(_Base):
    url = API + "/app/{kind}/{item_id}"
    name = "api:artificial_intelligence:p_app:item"

    def _file(self, kind, item_id):
        folder = {"chat": "chats", "knowledge": "knowledge"}.get(kind)
        iid = _safe_id(item_id)
        return os.path.join(self.app_root, folder, iid + ".json") if folder and iid else None

    async def put(self, request, kind, item_id):
        f = self._file(kind, item_id)
        if not f:
            return self.json_message("Unknown kind", 404)
        body = await request.json()
        if not isinstance(body, dict):
            return self.json_message("Wrong data type", 400)

        def work():
            body["id"] = _safe_id(item_id)
            _atomic_write(f, json.dumps(body, ensure_ascii=False))
            return _mtime_ms(f)
        return self.json({"ok": True, "ts": await self._run(work)})

    async def delete(self, request, kind, item_id):
        f = self._file(kind, item_id)
        if not f:
            return self.json_message("Unknown kind", 404)

        def work():
            if os.path.isfile(f):
                os.remove(f)
        await self._run(work)
        return self.json({"ok": True})


# ------------------------------------------------ sandboxed files for the AI
class _FsError(Exception):
    pass


def _fs_resolve(root: str, rel: str):
    """Map a virtual path to (full path, allowed base, project folder or None).

    Virtual layout: "" (root) lists projects and _workspace.  The AI may use
    _workspace/** and <Project>/sources/**.  Nothing else on disk is reachable.
    """
    rel = str(rel or "").replace("\\", "/").strip().strip("/")
    parts = [p for p in rel.split("/") if p and p != "."]
    for part in parts:
        if part == ".." or part.startswith(".") or "\x00" in part or len(part) > 120:
            raise _FsError("That path is not accessible")
    real_root = os.path.realpath(root)
    if not parts:
        return real_root, None, None
    if parts[0] == WORKSPACE:
        base = _workspace_path(root)
        project = None
        sub = parts[1:]
    else:
        pdir = _pdir(root, parts[0])
        if not pdir or not os.path.isfile(os.path.join(pdir, DATA_FILE)):
            raise _FsError(f"Unknown folder '{parts[0]}'. Use fs_list with an empty path to see what exists.")
        if len(parts) > 1 and parts[1] != "sources":
            raise _FsError("Only the 'sources' folder inside a project is accessible")
        base = os.path.join(pdir, "sources")
        project = pdir
        sub = parts[2:]
    full = os.path.realpath(os.path.join(base, *sub)) if (parts[0] == WORKSPACE or len(parts) > 1) else os.path.realpath(os.path.join(real_root, parts[0]))
    if len(parts) > 1 or parts[0] == WORKSPACE:
        rb = os.path.realpath(base)
        if os.path.commonpath([full, rb]) != rb:
            raise _FsError("That path is not accessible")
    return full, os.path.realpath(base), project


def _fs_entry(path: str) -> dict:
    isdir = os.path.isdir(path)
    return {"name": os.path.basename(path), "type": "dir" if isdir else "file",
            "size": None if isdir else os.path.getsize(path), "modified": _mtime_ms(path)}


def _fs_list(root, rel):
    full, base, project = _fs_resolve(root, rel)
    parts = [p for p in str(rel or "").replace("\\", "/").split("/") if p]
    if not parts:
        out = [{"name": WORKSPACE, "type": "dir", "size": None, "modified": 0}]
        if os.path.isdir(root):
            for n in sorted(os.listdir(root), key=str.lower):
                p = _pdir(root, n)
                if p and os.path.isfile(os.path.join(p, DATA_FILE)):
                    out.append({"name": n, "type": "dir", "size": None, "modified": _mtime_ms(p)})
        return out
    if project and len(parts) == 1:
        os.makedirs(os.path.join(project, "sources"), exist_ok=True)
        return [{"name": "sources", "type": "dir", "size": None, "modified": 0}]
    if not os.path.isdir(full):
        if parts[0] == WORKSPACE and len(parts) == 1:
            os.makedirs(full, exist_ok=True)
        else:
            raise _FsError("Folder not found")
    return [_fs_entry(os.path.join(full, n)) for n in sorted(os.listdir(full), key=str.lower) if not n.startswith(".")]


def _fs_read(root, rel, offset, max_chars):
    full, base, project = _fs_resolve(root, rel)
    if not os.path.isfile(full):
        raise _FsError("File not found")
    name = os.path.basename(full)
    ext = os.path.splitext(name)[1].lower()
    if project and os.path.dirname(full) == os.path.realpath(base) and ext in INDEXED_EXT | TEXT_EXT:
        text, state = _source_text(project, name)  # PDFs and HTML are read through the extracted text
        if state == "pending":
            raise _FsError("This file is still being indexed. Try again in a minute.")
        if state == "empty":
            raise _FsError("This file contains no readable text (for example a scanned PDF).")
        text = text or ""
    elif ext in FS_TEXT_EXT or not ext:
        with open(full, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    else:
        raise _FsError(f"'{name}' is not a text file, so it cannot be read")
    total = len(text)
    max_chars = max(1000, min(FS_MAX_READ, int(max_chars or FS_MAX_READ)))
    chunk = text[offset: offset + max_chars]
    return {"path": rel, "content": chunk, "offset": offset, "total_chars": total,
            "truncated": offset + len(chunk) < total}


def _fs_write(root, rel, content, mode):
    full, base, project = _fs_resolve(root, rel)
    parts = [p for p in str(rel).replace("\\", "/").split("/") if p]
    if base is None or (project and len(parts) < 3) or (not project and len(parts) < 2):
        raise _FsError("Give a file path, for example _workspace/notes.txt")
    name = os.path.basename(full)
    ext = os.path.splitext(name)[1].lower()
    if ext not in FS_TEXT_EXT:
        raise _FsError(f"Only text files can be written (allowed: {', '.join(sorted(FS_TEXT_EXT))})")
    if name == DATA_FILE or os.path.isdir(full):
        raise _FsError("That path is not writable")
    if len(content) > FS_MAX_WRITE:
        raise _FsError("Content is too large (1,000,000 characters maximum)")
    existed = os.path.isfile(full)
    if mode == "create" and existed:
        raise _FsError("File already exists. Use mode 'overwrite' or 'append'.")
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "a" if mode == "append" else "w", encoding="utf-8") as fh:
        fh.write(content)
    if project and ext in INDEXED_EXT:
        idx = os.path.join(project, "index", name + ".txt")
        if os.path.isfile(idx):
            os.remove(idx)
    return {"ok": True, "path": rel, "bytes": os.path.getsize(full), "created": not existed}


def _fs_mkdir(root, rel):
    full, base, project = _fs_resolve(root, rel)
    parts = [p for p in str(rel).replace("\\", "/").split("/") if p]
    if base is None or (project and len(parts) < 3) or (not project and len(parts) < 2):
        raise _FsError("Give a folder path, for example _workspace/reports")
    os.makedirs(full, exist_ok=True)
    return {"ok": True, "path": rel}


def _fs_delete(root, rel):
    full, base, project = _fs_resolve(root, rel)
    parts = [p for p in str(rel).replace("\\", "/").split("/") if p]
    if base is None or (project and len(parts) < 3) or (not project and len(parts) < 2):
        raise _FsError("Only files and folders inside _workspace or <Project>/sources can be deleted")
    if os.path.isfile(full):
        os.remove(full)
        if project:
            idx = os.path.join(project, "index", os.path.basename(full) + ".txt")
            if os.path.isfile(idx):
                os.remove(idx)
            stem, ext = os.path.splitext(full)
            if ext.lower() == ".html" and os.path.isfile(stem + ".txt"):
                os.remove(stem + ".txt")
    elif os.path.isdir(full):
        if os.listdir(full):
            raise _FsError("Folder is not empty. Delete its files first.")
        os.rmdir(full)
    else:
        raise _FsError("Not found")
    return {"ok": True, "path": rel}


class FsView(_Base):
    url = API + "/fs"
    name = "api:artificial_intelligence:p_fs"

    async def get(self, request):
        op = request.query.get("op", "list")
        path = request.query.get("path", "")

        def work():
            if op == "list":
                return {"path": path, "entries": _fs_list(self.root, path)}
            if op == "read":
                return _fs_read(self.root, path, max(0, int(request.query.get("offset", 0) or 0)), request.query.get("max_chars"))
            raise _FsError("Unknown operation")
        try:
            return self.json(await self._run(work))
        except _FsError as err:
            return self.json_message(str(err), 400)
        except (OSError, ValueError) as err:
            return self.json_message("File operation failed: " + str(err)[:150], 400)

    async def post(self, request):
        body = await request.json()
        op, path = str(body.get("op", "")), body.get("path", "")
        stop = await self.rt.access.check(request, "fs_" + op, "projects/" + str(path).lstrip("/"), f"{op} projects/{str(path).lstrip('/')}",
                                          str(body.get("content", ""))[:1500] if op == "write" else "")
        if stop is not None:
            return stop

        def work():
            if op == "write":
                mode = body.get("mode", "create")
                if mode not in ("create", "overwrite", "append"):
                    raise _FsError("mode must be create, overwrite or append")
                return _fs_write(self.root, path, str(body.get("content", "")), mode)
            if op == "mkdir":
                return _fs_mkdir(self.root, path)
            if op == "delete":
                return _fs_delete(self.root, path)
            raise _FsError("Unknown operation")
        try:
            return self.json(await self._run(work))
        except _FsError as err:
            return self.json_message(str(err), 400)
        except (OSError, ValueError) as err:
            return self.json_message("File operation failed: " + str(err)[:150], 400)



def setup_projects(hass: HomeAssistant, rt: Runtime) -> None:
    """Register the project, app-data and file views and index any PDFs that were never indexed."""
    set_workspace(rt.paths.workspace)
    for view in (ProjectsView, ProjectView, AuthView, FlagsView, SourcesView, SourceView, ContextView, ChatView,
                 ShareView, ProjectShareView, UpdateView, AppAllView, AppKindView, AppItemView, FsView):
        hass.http.register_view(view(hass, rt))

    async def _index_existing() -> None:
        for proj_path, fname in await hass.async_add_executor_job(_missing_indexes, rt.paths.projects):
            await _bg_index(rt, proj_path, fname)

    hass.async_create_task(_index_existing())
