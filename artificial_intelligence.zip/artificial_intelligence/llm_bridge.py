"""Shared pieces for the agents: Home Assistant chat logs to API messages, agent settings, and Boss AI hand-offs."""
from __future__ import annotations

import base64
import json
import logging
from pathlib import Path
from typing import Any

from homeassistant.components import conversation
from homeassistant.core import Context, HomeAssistant
from homeassistant.helpers import llm

from .const import (
    BUILTIN_HA_AGENT, CONF_HA_AGENT, CONF_MAX_HOPS, CONF_MAX_TOKENS, CONF_PRIMARY, CONF_PROMPT, CONF_REASONING, CONF_SECONDARY,
    CONF_SECONDARY_PROMPT, CONF_TALK_BACK, CONF_TEMPERATURE, CONF_TOP_P,
)
from .providers import ProviderError

_LOGGER = logging.getLogger(__name__)
MAX_TOOL_ROUNDS = 10


def agent_params(data: dict, reasoning: Any = None) -> dict:
    p: dict[str, Any] = {}
    for key, out in ((CONF_TEMPERATURE, "temperature"), (CONF_TOP_P, "top_p"), (CONF_MAX_TOKENS, "max_tokens")):
        if data.get(key) not in (None, ""):
            p[out] = data[key]
    r = reasoning if reasoning not in (None, "auto") else data.get(CONF_REASONING)
    if r and r not in ("none", "off", False):
        p["reasoning"] = "medium" if r in (True, "on") else r
    return p


def format_tools(chat_log: conversation.ChatLog) -> list[dict] | None:
    api = chat_log.llm_api
    if not api:
        return None
    try:
        from voluptuous_openapi import convert  # noqa: PLC0415
    except ImportError:  # pragma: no cover
        return None
    out = []
    for tool in api.tools:
        try:
            params = convert(tool.parameters, custom_serializer=api.custom_serializer)
        except Exception:  # noqa: BLE001
            params = {"type": "object", "properties": {}}
        out.append({"type": "function", "function": {"name": tool.name, "description": tool.description or "", "parameters": params}})
    return out or None


def _read_attachment(path: Path) -> bytes | None:
    try:
        return Path(path).read_bytes()
    except OSError:
        return None


async def chatlog_messages(hass: HomeAssistant, chat_log: conversation.ChatLog, vision: bool, system_prefix: str = "") -> list[dict]:
    msgs: list[dict] = []
    for c in chat_log.content:
        if isinstance(c, conversation.SystemContent):
            text = (system_prefix + "\n\n" + c.content).strip() if system_prefix else c.content
            msgs.append({"role": "system", "content": text})
            system_prefix = ""
        elif isinstance(c, conversation.UserContent):
            parts: list[dict] = []
            for att in getattr(c, "attachments", None) or []:
                if not vision or not str(getattr(att, "mime_type", "")).startswith("image/"):
                    continue
                data = await hass.async_add_executor_job(_read_attachment, att.path)
                if data:
                    parts.append({"type": "image_url", "image_url": {"url": f"data:{att.mime_type};base64,{base64.b64encode(data).decode('ascii')}"}})
            msgs.append({"role": "user", "content": [{"type": "text", "text": c.content}, *parts] if parts else c.content})
        elif isinstance(c, conversation.AssistantContent):
            m: dict[str, Any] = {"role": "assistant", "content": c.content or ""}
            if c.tool_calls:
                m["tool_calls"] = [{"id": t.id, "type": "function", "function": {"name": t.tool_name, "arguments": json.dumps(t.tool_args)}} for t in c.tool_calls]
            msgs.append(m)
        elif isinstance(c, conversation.ToolResultContent):
            msgs.append({"role": "tool", "tool_call_id": c.tool_call_id, "content": json.dumps(c.tool_result, default=str)})
    if system_prefix:
        msgs.insert(0, {"role": "system", "content": system_prefix})
    return msgs


async def to_delta_stream(stream):
    """Provider pieces -> Home Assistant chat-log deltas."""
    yield {"role": "assistant"}
    async for piece in stream:
        if piece.get("content"):
            yield {"content": piece["content"]}
        if "tool_calls" in piece and piece["tool_calls"]:
            yield {"tool_calls": [llm.ToolInput(id=c["id"], tool_name=c["name"], tool_args=c["arguments"]) for c in piece["tool_calls"]]}


async def provide_llm_data(chat_log: conversation.ChatLog, user_input: conversation.ConversationInput, domain: str, apis: Any, prompt: str | None) -> None:
    """Works with both the newer (async_provide_llm_data) and older (async_update_llm_data) chat log API."""
    if hasattr(chat_log, "async_provide_llm_data"):
        await chat_log.async_provide_llm_data(user_input.as_llm_context(domain), apis or None, prompt, user_input.extra_system_prompt)
    else:  # pragma: no cover - older Home Assistant
        await chat_log.async_update_llm_data(domain, user_input, apis or None, prompt)


# ---------------------------------------------------------------------- Boss AI
ASK_HA_TOOL = {"type": "function", "function": {"name": "ask_home_assistant", "description": "Ask the Home Assistant agent to check or do something in the home, in plain words (for example 'turn on the kitchen light' or 'is the garage door open?'). It replies in plain words.",
                                                 "parameters": {"type": "object", "properties": {"request": {"type": "string"}}, "required": ["request"]}}}
ASK_SECONDARY_TOOL = {"type": "function", "function": {"name": "ask_secondary", "description": "Hand a task to your secondary model. It does the work, can ask the Home Assistant agent itself, and replies with the result. You can follow up with another call.",
                                                       "parameters": {"type": "object", "properties": {"task": {"type": "string", "description": "What you want done, in plain words"}}, "required": ["task"]}}}


async def boss_delegate(hass: HomeAssistant, rt, boss: dict, task: str, context: Context | None = None) -> tuple[str, list[str]]:
    """The secondary model works on a task; it may ask the Home Assistant agent; returns (answer, trace)."""
    sec = rt.resolve_agent(boss.get(CONF_SECONDARY))
    if not sec or not sec.client:
        raise ProviderError("The Boss AI's secondary agent is missing. Edit the Boss AI and pick another.")
    ha_id = boss.get(CONF_HA_AGENT) or BUILTIN_HA_AGENT
    ha_name = hass.states.get(ha_id).name if hass.states.get(ha_id) else "Home Assistant"
    max_hops = max(1, min(8, int(boss.get(CONF_MAX_HOPS) or 4)))
    system = "\n\n".join(x for x in (sec.data.get(CONF_PROMPT), boss.get(CONF_SECONDARY_PROMPT),
                                     f"You are working for another AI. Do the task, then reply with a short, factual result. Use ask_home_assistant ({ha_name}) for anything about devices or the home. Never claim something was done unless the Home Assistant agent confirmed it. Use UK English.") if x)
    msgs: list[dict] = [{"role": "system", "content": system}, {"role": "user", "content": task}]
    trace: list[str] = []
    conv_id: str | None = None
    seen: set[str] = set()
    for _hop in range(max_hops + 1):
        reply = await sec.client.complete(sec.data.get("model"), msgs, [ASK_HA_TOOL], agent_params(sec.data))
        if not reply["tool_calls"]:
            answer = reply["content"].strip() or "(no answer)"
            trace.append(f"{sec.name}: {answer}")
            return answer, trace
        msgs.append({"role": "assistant", "content": reply["content"] or "", "tool_calls": [{"id": c["id"], "type": "function", "function": {"name": c["name"], "arguments": json.dumps(c["arguments"])}} for c in reply["tool_calls"]]})
        for call in reply["tool_calls"]:
            request = str(call["arguments"].get("request") or call["arguments"].get("_raw") or "").strip()
            if not request or request.lower() in seen:
                result = "You already asked that. Use the answer you have."
            else:
                seen.add(request.lower())
                trace.append(f"{sec.name} asked {ha_name}: \"{request}\"")
                try:
                    res = await conversation.async_converse(hass, request, conv_id if boss.get(CONF_TALK_BACK, True) else None, context or Context(),
                                                            hass.config.language, agent_id=ha_id)
                    conv_id = res.conversation_id
                    result = res.response.speech.get("plain", {}).get("speech", "") or "(no reply)"
                except Exception as err:  # noqa: BLE001
                    result = f"Error: {err}"
                trace.append(f"{ha_name} answered: \"{result}\"")
            msgs.append({"role": "tool", "tool_call_id": call["id"], "content": result})
    trace.append(f"Stopped after {max_hops} hand-offs.")
    return "I ran out of hand-offs before finishing. Here is what happened:\n" + "\n".join(trace), trace


async def boss_primary(hass: HomeAssistant, rt, boss: dict, messages: list[dict], context: Context | None = None) -> tuple[str, list[str]]:
    """The primary model answers, handing work to the secondary as needed (used for voice; the page drives this itself)."""
    pri = rt.resolve_agent(boss.get(CONF_PRIMARY))
    if not pri or not pri.client:
        raise ProviderError("The Boss AI's primary agent is missing. Edit the Boss AI and pick another.")
    max_hops = max(1, min(8, int(boss.get(CONF_MAX_HOPS) or 4)))
    trace: list[str] = []
    msgs = list(messages)
    for _hop in range(max_hops + 1):
        reply = await pri.client.complete(pri.data.get("model"), msgs, [ASK_SECONDARY_TOOL], agent_params(pri.data))
        if not reply["tool_calls"]:
            return reply["content"].strip(), trace
        msgs.append({"role": "assistant", "content": reply["content"] or "", "tool_calls": [{"id": c["id"], "type": "function", "function": {"name": c["name"], "arguments": json.dumps(c["arguments"])}} for c in reply["tool_calls"]]})
        for call in reply["tool_calls"]:
            task = str(call["arguments"].get("task") or call["arguments"].get("_raw") or "")
            trace.append(f"{pri.name} asked the secondary: \"{task}\"")
            try:
                answer, sub = await boss_delegate(hass, rt, boss, task, context)
                trace += sub
            except ProviderError as err:
                answer = f"Error: {err}"
            msgs.append({"role": "tool", "tool_call_id": call["id"], "content": answer})
    return "I could not finish within the hand-off limit.", trace
