"""Event binary sensors: motion, line crossing, intrusion, tamper, video loss, alarm inputs."""
from __future__ import annotations

from homeassistant.components.binary_sensor import BinarySensorDeviceClass, BinarySensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.dispatcher import async_dispatcher_connect
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .hikvision.const import CHANNEL_KINDS
from .hikvision.hub import CaiHikvisionHub


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    from .entities import async_setup_extra  # noqa: PLC0415

    if await async_setup_extra(hass, entry, async_add_entities, 0):
        return
    hub: CaiHikvisionHub = entry.runtime_data
    entities: list[BinarySensorEntity] = [StreamConnectedSensor(hub)]
    for ch in hub.channels.values():
        for kind, (label, dclass, enabled) in CHANNEL_KINDS.items():
            entities.append(
                HikStateSensor(
                    hub, f"ch{ch.id}_{kind}", label, BinarySensorDeviceClass(dclass),
                    hub.channel_device_info(ch), enabled,
                )
            )
    for port, name in hub.io_inputs.items():
        entities.append(
            HikStateSensor(hub, f"io{port}", name, BinarySensorDeviceClass.SAFETY, hub.dvr_device_info(), True)
        )
    async_add_entities(entities)


class _HubSensor(BinarySensorEntity):
    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(self, hub: CaiHikvisionHub, key: str) -> None:
        self._hub = hub
        self._key = key
        self._attr_unique_id = f"{hub.uid}_{key}"

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(async_dispatcher_connect(self.hass, self._hub.signal_state, self._on_state))

    @callback
    def _on_state(self, key: str) -> None:
        if key == self._key:
            self.async_write_ha_state()


class HikStateSensor(_HubSensor):
    def __init__(
        self, hub: CaiHikvisionHub, key: str, name: str, dclass: BinarySensorDeviceClass,
        device: DeviceInfo, enabled: bool,
    ) -> None:
        super().__init__(hub, key)
        self._attr_name = name
        self._attr_device_class = dclass
        self._attr_device_info = device
        self._attr_entity_registry_enabled_default = enabled

    @property
    def is_on(self) -> bool:
        return self._hub.states.get(self._key, False)


class StreamConnectedSensor(_HubSensor):
    _attr_name = "CAI Hikvision event stream"
    _attr_device_class = BinarySensorDeviceClass.CONNECTIVITY
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, hub: CaiHikvisionHub) -> None:
        super().__init__(hub, "stream")
        self._attr_device_info = hub.dvr_device_info()

    @property
    def is_on(self) -> bool:
        return self._hub.stream_connected
