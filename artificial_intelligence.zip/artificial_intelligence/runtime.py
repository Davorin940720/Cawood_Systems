"""Shared runtime state for the integration (stored in hass.data[DOMAIN])."""
from __future__ import annotations

import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError

from homeassistant.helpers import entity_registry as er

from .const import (
    CONF_ENTRY_TYPE, DOMAIN, ENTRY_BACKEND, ENTRY_SERVICE, LEGACY_YAML_KEY, SUB_AI_TASK, SUB_BOSS, SUB_CONVERSATION,
)
from .core import Core
from .paths import Paths

if TYPE_CHECKING:  # pragma: no cover
    from .access import AccessManager
    from .agents import AgentHub
    from .hikvision.hub import CaiHikvisionHub
    from .hikvision.training import TrainingStore
    from .mcp import McpManager
    from .providers import ProviderClient

_LOGGER = logging.getLogger(__name__)


def normalise_smtp(conf: Any) -> dict | None:
    if not isinstance(conf, dict) or not conf.get("host"):
        return None
    out = dict(conf)
    out.setdefault("port", 587)
    out.setdefault("sender_name", "Cawood-AI")
    if not out.get("sender"):
        out["sender"] = out.get("username") or ""
    return out


@dataclass
class Runtime:
    hass: HomeAssistant
    core: Core
    paths: Paths
    yaml_conf: dict = field(default_factory=dict)
    busy: set = field(default_factory=set)                 # PDF/HTML files being indexed
    hubs: dict[str, "CaiHikvisionHub"] = field(default_factory=dict)
    training: "TrainingStore | None" = None
    relay_secret: str = field(default_factory=lambda: secrets.token_urlsafe(32))  # lets the server drive a machine agent
    providers: dict[str, "ProviderClient"] = field(default_factory=dict)  # service entry_id -> client
    access: "AccessManager | None" = None
    mcp: "McpManager | None" = None
    agents: "AgentHub | None" = None
    _smtp: tuple[float, dict | None] = (0.0, None)

    # ------------------------------------------------------------------ AI agents (subentries of service entries, Boss AIs)
    def backend_entry(self):
        return next((e for e in self.hass.config_entries.async_entries(DOMAIN) if e.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND) == ENTRY_BACKEND), None)

    def list_agents(self) -> list["AgentRef"]:
        reg = er.async_get(self.hass)
        out: list[AgentRef] = []
        for entry in self.hass.config_entries.async_entries(DOMAIN):
            kind = entry.data.get(CONF_ENTRY_TYPE, ENTRY_BACKEND)
            if kind not in (ENTRY_SERVICE, ENTRY_BACKEND):
                continue
            ents = er.async_entries_for_config_entry(reg, entry.entry_id)
            for sub in (entry.subentries or {}).values():
                if sub.subentry_type not in (SUB_CONVERSATION, SUB_AI_TASK, SUB_BOSS):
                    continue
                eid = next((e.entity_id for e in ents if e.config_subentry_id == sub.subentry_id and e.domain in ("conversation", "ai_task")), None)
                if not eid:
                    continue
                out.append(AgentRef(eid, sub.subentry_type, entry, sub, self.providers.get(entry.entry_id)))
        return out

    def resolve_agent(self, entity_id: str | None) -> "AgentRef | None":
        if not entity_id:
            return None
        entity_id = str(entity_id).removeprefix("ha:")
        return next((a for a in self.list_agents() if a.entity_id == entity_id), None)

    async def smtp(self) -> dict | None:
        """The smtp: block from configuration.yaml, under artificial_intelligence: or the old davai: key."""
        stamp, cached = self._smtp
        if time.monotonic() - stamp < 30:
            return cached
        from homeassistant import config as conf_util  # pylint: disable=import-outside-toplevel

        smtp: dict | None = None
        try:
            conf = await conf_util.async_hass_config_yaml(self.hass)
        except (HomeAssistantError, OSError, ValueError) as err:
            _LOGGER.warning("Could not read configuration.yaml: %s", err)
        else:
            for key in (DOMAIN, LEGACY_YAML_KEY):
                block = conf.get(key)
                if isinstance(block, dict) and block.get("smtp"):
                    smtp = normalise_smtp(block["smtp"])
                    if smtp:
                        break
        self._smtp = (time.monotonic(), smtp)
        return smtp


@dataclass
class AgentRef:
    """One agent: where it lives and how to call its model."""

    entity_id: str
    kind: str                 # conversation | ai_task | boss
    entry: Any
    subentry: Any
    client: "ProviderClient | None"

    @property
    def data(self) -> dict:
        return dict(self.subentry.data)

    @property
    def name(self) -> str:
        return self.subentry.title

    @property
    def service(self) -> str:
        return self.entry.title if self.kind != SUB_BOSS else "Boss AI"


def get_runtime(hass: HomeAssistant) -> Runtime:
    rt = hass.data.get(DOMAIN)
    if not isinstance(rt, Runtime):
        raise LookupError("Artificial Intelligence is not running")
    return rt
