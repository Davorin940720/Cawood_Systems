"""SMTP email using the smtp: settings from the davai: block in configuration.yaml."""
from __future__ import annotations

import html
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

GREEN = "#2fbf71"


def _wrap(title: str, body_html: str) -> str:
    return f"""<!doctype html><html><body style="margin:0;background:#0c1512;font-family:Segoe UI,Arial,sans-serif;color:#d9efe3">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 12px">
<table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;background:#13201b;border:1px solid #1f3a2e;border-radius:12px">
<tr><td style="padding:24px 28px;border-bottom:1px solid #1f3a2e">
<span style="display:inline-block;width:34px;height:34px;line-height:34px;text-align:center;border:2px solid {GREEN};border-radius:8px;color:{GREEN};font-weight:700">CAI</span>
<span style="font-size:18px;font-weight:600;margin-left:10px;color:#ffffff">Cawood Artificial Intelligence</span></td></tr>
<tr><td style="padding:28px;font-size:15px;line-height:1.6">
<h1 style="font-size:20px;margin:0 0 14px;color:#ffffff">{html.escape(title)}</h1>{body_html}</td></tr>
<tr><td style="padding:18px 28px;border-top:1px solid #1f3a2e;font-size:12px;color:#7fa391">
Cawood Systems&trade;, Copyright 2026<br>Cawood Artificial Intelligence<br>By Davorin Cawood, Davorin@Cawood94.co.za</td></tr>
</table></td></tr></table></body></html>"""


def welcome(name: str, email: str, url: str) -> tuple[str, str, str]:
    n = html.escape(name)
    body = (f"<p>Hi {n},</p><p>Your account is ready. You can log in any time with <b>{html.escape(email)}</b>.</p>"
            f'<p style="margin:24px 0"><a href="{html.escape(url)}" style="background:{GREEN};color:#06110c;padding:11px 20px;border-radius:8px;text-decoration:none;font-weight:600">Open Cawood AI</a></p>'
            "<p>Chat with Ollama Cloud models, attach files, save prompts and knowledge, take notes and talk by voice.</p>"
            "<p>If you didn't create this account, you can ignore this email.</p>")
    text = (f"Hi {name},\n\nYour account is ready. Log in with {email} at:\n{url}\n\n"
            "If you didn't create this account, you can ignore this email.\n\nCawood Systems, Copyright 2026")
    return "Welcome to Cawood Artificial Intelligence", _wrap(f"Welcome, {name}", body), text


def reset(name: str, code: str) -> tuple[str, str, str]:
    body = (f"<p>Hi {html.escape(name)},</p><p>Use this code to reset your password. It expires in 15 minutes.</p>"
            f'<p style="font-size:30px;letter-spacing:8px;font-weight:700;color:{GREEN};margin:20px 0">{code}</p>'
            "<p>If you didn't ask for this, ignore this email. Your password stays the same.</p>")
    text = f"Hi {name},\n\nYour password reset code is {code}. It expires in 15 minutes.\n\nIf you didn't ask for this, ignore this email."
    return "Your password reset code", _wrap("Reset your password", body), text


def send(smtp: dict, to: str, subject: str, html_body: str, text_body: str) -> None:
    """Blocking send. Raises RuntimeError with a readable message."""
    if not smtp or not smtp.get("host"):
        raise RuntimeError("No smtp: settings found under artificial_intelligence: in configuration.yaml.")
    sender = smtp.get("sender") or smtp.get("username")
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = formataddr((smtp.get("sender_name") or "Cawood-AI", sender))
    msg["To"] = to
    msg["Message-ID"] = make_msgid(domain=sender.split("@")[-1] if sender and "@" in sender else None)
    msg.set_content(text_body)
    msg.add_alternative(html_body, subtype="html")
    port = int(smtp.get("port", 587))
    try:
        if port == 465:
            with smtplib.SMTP_SSL(smtp["host"], port, context=ssl.create_default_context(), timeout=30) as s:
                if smtp.get("username"):
                    s.login(smtp["username"], smtp.get("password", ""))
                s.send_message(msg)
        else:
            with smtplib.SMTP(smtp["host"], port, timeout=30) as s:
                s.ehlo()
                if not s.has_extn("starttls"):
                    raise RuntimeError("The SMTP server doesn't offer TLS, so the email was not sent.")
                s.starttls(context=ssl.create_default_context())
                s.ehlo()
                if smtp.get("username"):
                    s.login(smtp["username"], smtp.get("password", ""))
                s.send_message(msg)
    except smtplib.SMTPAuthenticationError as err:
        raise RuntimeError("SMTP login was rejected. Check the smtp username and password.") from err
    except (OSError, smtplib.SMTPException) as err:
        raise RuntimeError(f"Email failed: {err}") from err
