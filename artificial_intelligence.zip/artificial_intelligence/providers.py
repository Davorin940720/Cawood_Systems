"""One client for every AI service.

Gemini, Groq, OpenRouter, Cerebras, Mistral, OpenAI, GitHub Models and most other APIs speak the OpenAI chat-completions
format, so a single client covers them all. Keys stay here on the server; the pages never see them.
"""
from __future__ import annotations

import base64
import json
import logging
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from urllib.parse import urlparse
from typing import Any

import aiohttp

from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.dispatcher import async_dispatcher_send
from homeassistant.util import dt as dt_util

from .const import CONF_API_KEY, CONF_BASE_URL, CONF_PRESET, CONF_VERIFY_SSL, PRESETS, SIGNAL_SERVICE_UPDATE

_LOGGER = logging.getLogger(__name__)
TIMEOUT = aiohttp.ClientTimeout(total=600, sock_connect=20, sock_read=240)


class ProviderError(Exception):
    """A failed call, with a message fit for the user."""

    def __init__(self, message: str, status: int = 0) -> None:
        super().__init__(message)
        self.status = status


def base_url_for(data: dict) -> str:
    url = str(data.get(CONF_BASE_URL) or "").strip() or PRESETS.get(str(data.get(CONF_PRESET) or ""), ("", ""))[1]
    return url.rstrip("/")


def image_part(b64: str) -> dict:
    """An OpenAI image part from base64 (with or without a data: prefix)."""
    if b64.startswith("data:"):
        return {"type": "image_url", "image_url": {"url": b64}}
    mime = "image/png" if b64.startswith("iVBOR") else "image/webp" if b64.startswith("UklGR") else "image/gif" if b64.startswith("R0lGOD") else "image/jpeg"
    return {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}}


def bytes_part(data: bytes, mime: str = "image/jpeg") -> dict:
    return {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{base64.b64encode(data).decode('ascii')}"}}


@dataclass
class Stats:
    day: str = ""
    requests: int = 0
    tokens: int = 0
    connected: bool | None = None
    last_error: str = ""
    last_ok: float = 0.0
    models: list[str] = field(default_factory=list)


class ProviderClient:
    """An AI service (one config entry)."""

    def __init__(self, hass: HomeAssistant, entry_id: str, title: str, data: dict) -> None:
        self.hass = hass
        self.entry_id = entry_id
        self.title = title
        self.preset = str(data.get(CONF_PRESET) or "custom")
        self.base = base_url_for(data)
        self.key = str(data.get(CONF_API_KEY) or "").strip()
        self.verify_ssl = bool(data.get(CONF_VERIFY_SSL, True))
        self.stats = Stats()

    # ------------------------------------------------------------------ helpers
    @property
    def session(self) -> aiohttp.ClientSession:
        return async_get_clientsession(self.hass, verify_ssl=self.verify_ssl)

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.key:
            h["Authorization"] = f"Bearer {self.key}"
        if self.preset == "openrouter":
            h["HTTP-Referer"] = "https://www.home-assistant.io"
            h["X-Title"] = "Cawood Artificial Intelligence"
        return h

    def _count(self, tokens: int = 0, ok: bool = True, error: str = "") -> None:
        today = dt_util.now().date().isoformat()
        if self.stats.day != today:
            self.stats.day, self.stats.requests, self.stats.tokens = today, 0, 0
        self.stats.requests += 1
        self.stats.tokens += max(0, int(tokens or 0))
        self.stats.connected = ok
        if ok:
            self.stats.last_ok = time.time()
            self.stats.last_error = ""
        else:
            self.stats.last_error = error[:300]
        async_dispatcher_send(self.hass, f"{SIGNAL_SERVICE_UPDATE}_{self.entry_id}")

    @staticmethod
    async def _error(resp: aiohttp.ClientResponse) -> str:
        return ProviderClient._error_text(await resp.text())

    @staticmethod
    def _error_text(text: str) -> str:
        msg = text[:300]
        try:
            data = json.loads(text)
            if isinstance(data, list) and data:
                data = data[0]
            err = data.get("error") if isinstance(data, dict) else None
            if isinstance(err, dict):
                msg = str(err.get("message") or err.get("code") or msg)
            elif isinstance(err, str):
                msg = err
            elif isinstance(data, dict) and data.get("message"):
                msg = str(data["message"])
        except ValueError:
            pass
        return msg

    def _friendly(self, status: int, msg: str) -> str:
        if status in (401, 403):
            return f"{self.title} rejected the API key ({status}). Update it in Home Assistant: Settings, Devices & services, Artificial Intelligence, {self.title}, Reconfigure."
        if status == 404:
            return f"{self.title}: not found ({msg}). Check the model name on the agent."
        if status == 429:
            return f"{self.title}: rate limit or free-tier quota reached. {msg}".strip()
        if status >= 500:
            return f"{self.title} had a server problem ({status}). {msg}".strip()
        return f"{self.title}: {msg}" if msg else f"{self.title}: request failed ({status})."

    # ------------------------------------------------------------------ API
    async def list_models(self) -> list[str]:
        if not self.base:
            raise ProviderError("No API address is set for this service.")
        try:
            async with self.session.get(self.base + "/models", headers=self._headers(), timeout=aiohttp.ClientTimeout(total=30)) as resp:
                raw = await resp.text()
                if resp.status >= 400:
                    self.stats.connected = False
                    self.stats.last_error = self._friendly(resp.status, self._error_text(raw))
                    raise ProviderError(self.stats.last_error, resp.status)
                try:
                    data = json.loads(raw)
                except ValueError as err:
                    self.stats.connected = False
                    host = urlparse(self.base).netloc or self.base
                    hint = " The address should end in /v1 (or the preset's path). Open it in a browser: a models API returns JSON, not a web page." if "<" in raw[:200] else ""
                    self.stats.last_error = f"{self.title}: {host} did not return JSON from {self.base}/models.{hint}"
                    raise ProviderError(self.stats.last_error) from err
        except aiohttp.ClientError as err:
            self.stats.connected = False
            self.stats.last_error = f"Cannot reach {self.base}: {err}"
            raise ProviderError(self.stats.last_error) from err
        except TimeoutError as err:
            raise ProviderError(f"{self.title} did not answer in time.") from err
        items = data.get("data") if isinstance(data, dict) else data
        out: list[str] = []
        for m in items or []:
            mid = m.get("id") if isinstance(m, dict) else str(m)
            if mid:
                out.append(str(mid).removeprefix("models/"))
        self.stats.models = sorted(set(out))
        self.stats.connected = True
        self.stats.last_error = ""
        async_dispatcher_send(self.hass, f"{SIGNAL_SERVICE_UPDATE}_{self.entry_id}")
        return self.stats.models

    def _payload(self, model: str, messages: list[dict], tools: list[dict] | None, params: dict | None, stream: bool) -> dict:
        body: dict[str, Any] = {"model": model, "messages": messages, "stream": stream}
        p = params or {}
        if p.get("temperature") is not None:
            body["temperature"] = float(p["temperature"])
        if p.get("top_p") is not None:
            body["top_p"] = float(p["top_p"])
        if p.get("max_tokens"):
            body["max_tokens"] = int(p["max_tokens"])
        if p.get("reasoning") and p["reasoning"] not in ("none", False):
            body["reasoning_effort"] = "medium" if p["reasoning"] is True else str(p["reasoning"])
        if p.get("json"):
            body["response_format"] = {"type": "json_object"}
        if p.get("stop"):
            body["stop"] = p["stop"]
        if tools:
            body["tools"] = tools
        return body

    async def _post(self, body: dict) -> aiohttp.ClientResponse:
        if not self.base:
            raise ProviderError("No API address is set for this service.")
        try:
            resp = await self.session.post(self.base + "/chat/completions", headers=self._headers(), json=body, timeout=TIMEOUT)
        except aiohttp.ClientError as err:
            self._count(ok=False, error=str(err))
            raise ProviderError(f"Cannot reach {self.title} ({self.base}): {err}") from err
        except TimeoutError as err:
            self._count(ok=False, error="timeout")
            raise ProviderError(f"{self.title} did not answer in time.") from err
        if resp.status >= 400:
            msg = await self._error(resp)
            resp.release()
            # some services reject optional fields; retry once without them
            if resp.status == 400 and any(k in body for k in ("reasoning_effort", "response_format")) and any(w in msg.lower() for w in ("reasoning", "response_format", "unsupported", "unknown", "not supported")):
                slim = {k: v for k, v in body.items() if k not in ("reasoning_effort", "response_format")}
                return await self._post(slim)
            friendly = self._friendly(resp.status, msg)
            self._count(ok=False, error=friendly)
            raise ProviderError(friendly, resp.status)
        return resp

    async def complete(self, model: str, messages: list[dict], tools: list[dict] | None = None, params: dict | None = None) -> dict:
        """One reply: {"content", "reasoning", "tool_calls": [{"id","name","arguments"}], "usage"}."""
        resp = await self._post(self._payload(model, messages, tools, params, False))
        try:
            data = await resp.json(content_type=None)
        finally:
            resp.release()
        choice = (data.get("choices") or [{}])[0]
        msg = choice.get("message") or {}
        calls = []
        for i, tc in enumerate(msg.get("tool_calls") or []):
            fn = tc.get("function") or {}
            calls.append({"id": tc.get("id") or f"call_{i}", "name": fn.get("name") or "", "arguments": _args(fn.get("arguments"))})
        usage = data.get("usage") or {}
        content = msg.get("content")
        if isinstance(content, list):
            content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
        self._count(usage.get("total_tokens") or _estimate(messages, content or ""))
        return {"content": content or "", "reasoning": msg.get("reasoning") or msg.get("reasoning_content") or "", "tool_calls": calls,
                "usage": usage, "finish_reason": choice.get("finish_reason")}

    async def stream(self, model: str, messages: list[dict], tools: list[dict] | None = None, params: dict | None = None) -> AsyncIterator[dict]:
        """Yield {"content"}, {"reasoning"} pieces, then one {"tool_calls": [...], "usage": {...}, "finish_reason"} at the end."""
        resp = await self._post(self._payload(model, messages, tools, params, True))
        calls: dict[int, dict] = {}
        usage: dict = {}
        finish = None
        text_len = 0
        buf = b""
        try:
            async for chunk in resp.content.iter_any():
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    line = line.strip()
                    if not line or line.startswith(b":") or not line.startswith(b"data:"):
                        continue
                    data = line[5:].strip()
                    if data == b"[DONE]":
                        continue
                    try:
                        obj = json.loads(data)
                    except ValueError:
                        continue
                    if obj.get("error"):
                        err = obj["error"]
                        raise ProviderError(self._friendly(0, err.get("message") if isinstance(err, dict) else str(err)))
                    if obj.get("usage"):
                        usage = obj["usage"]
                    for choice in obj.get("choices") or []:
                        delta = choice.get("delta") or {}
                        if choice.get("finish_reason"):
                            finish = choice["finish_reason"]
                        piece = delta.get("content")
                        if isinstance(piece, list):
                            piece = "".join(p.get("text", "") for p in piece if isinstance(p, dict))
                        if piece:
                            text_len += len(piece)
                            yield {"content": piece}
                        think = delta.get("reasoning") or delta.get("reasoning_content")
                        if isinstance(think, str) and think:
                            yield {"reasoning": think}
                        for tc in delta.get("tool_calls") or []:
                            idx = tc.get("index", len(calls))
                            slot = calls.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                            if tc.get("id"):
                                slot["id"] = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name"):
                                slot["name"] += fn["name"]
                            if fn.get("arguments") is not None:
                                slot["arguments"] += fn["arguments"] if isinstance(fn["arguments"], str) else json.dumps(fn["arguments"])
        except aiohttp.ClientError as err:
            self._count(ok=False, error=str(err))
            raise ProviderError(f"The connection to {self.title} dropped: {err}") from err
        finally:
            resp.release()
        out_calls = [{"id": c["id"] or f"call_{i}", "name": c["name"], "arguments": _args(c["arguments"])} for i, c in sorted(calls.items())]
        self._count(usage.get("total_tokens") or _estimate(messages, "x" * text_len))
        yield {"tool_calls": out_calls, "usage": usage, "finish_reason": finish}


def _args(raw: Any) -> dict:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    try:
        val = json.loads(raw)
        return val if isinstance(val, dict) else {"value": val}
    except ValueError:
        return {"_raw": str(raw)}


def _estimate(messages: list[dict], reply: str) -> int:
    size = len(reply)
    for m in messages:
        c = m.get("content")
        size += len(c) if isinstance(c, str) else sum(len(p.get("text", "")) for p in c or [] if isinstance(p, dict))
    return size // 4
