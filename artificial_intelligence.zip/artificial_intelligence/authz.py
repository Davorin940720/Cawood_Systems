"""One way to authenticate every API call: a Home Assistant token (or signed link) or an Artificial Intelligence login.

ai-cloud.html sends X-AI-Token (its own account session). ollama-chat.html, cai_hik_config.html and the machine agents
send a Home Assistant long-lived token. Both work on every endpoint that uses AuthedView.
"""
from __future__ import annotations

import functools
import logging
import secrets
from http import HTTPStatus
from typing import Any

from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant

from .const import ORIGIN_HEADER, RELAY_HEADER, TOKEN_HEADER, TOOL_HEADER
from .runtime import Runtime

_LOGGER = logging.getLogger(__name__)

try:  # these names are stable across recent Home Assistant releases; the literals are the fallback
    from homeassistant.components.http.const import KEY_AUTHENTICATED, KEY_HASS_USER
except ImportError:  # pragma: no cover
    KEY_AUTHENTICATED, KEY_HASS_USER = "ha_authenticated", "hass_user"

PRINCIPAL_KEY = "cai_principal"


class Principal:
    """Who is calling: a Home Assistant user or an Artificial Intelligence account."""

    __slots__ = ("kind", "name", "is_admin", "ai_user", "ha_user", "origin")

    def __init__(self, kind: str, name: str, is_admin: bool, ai_user: dict | None = None, ha_user: Any = None, origin: str = "user") -> None:
        self.kind = kind
        self.name = name
        self.is_admin = is_admin
        self.ai_user = ai_user
        self.ha_user = ha_user
        # who is really acting: "user" (a person), "page" (a model in a chat page), "voice" (a voice assistant), "mcp" (an MCP client)
        self.origin = origin

    @property
    def label(self) -> str:
        return f"{self.kind}:{self.name}"


async def authenticate(rt: Runtime, request) -> Principal | None:
    model = "page" if request.headers.get(TOOL_HEADER) else "user"
    relay = request.headers.get(RELAY_HEADER)
    if relay and secrets.compare_digest(relay, rt.relay_secret):
        # the voice assistant tools (llm_api.py) or the MCP server calling this integration from inside Home Assistant
        origin = request.headers.get(ORIGIN_HEADER) if request.headers.get(ORIGIN_HEADER) in ("voice", "mcp") else "voice"
        return Principal("ai", "MCP client" if origin == "mcp" else "Voice assistant", True, origin=origin)
    if request.get(KEY_AUTHENTICATED):
        user = request.get(KEY_HASS_USER)
        if user is not None:
            return Principal("ha", getattr(user, "name", None) or "Home Assistant", bool(getattr(user, "is_admin", False)), ha_user=user, origin=model)
        return Principal("ha", "Home Assistant", False, origin=model)
    token = request.headers.get(TOKEN_HEADER)
    if token:
        user = await rt.hass.async_add_executor_job(rt.core.user_for, token)
        if user:
            return Principal("ai", user.get("name") or user.get("email") or "user", user.get("role") == "admin", ai_user=user, origin=model)
    return None


def _guard(fn):
    @functools.wraps(fn)
    async def wrapper(self, request, *args, **kwargs):
        principal = await authenticate(self.rt, request)
        if principal is None:
            _LOGGER.warning("401 on %s %s (has X-AI-Token=%s, HA-auth=%s)", request.method, request.path,
                            bool(request.headers.get(TOKEN_HEADER)), bool(request.get(KEY_AUTHENTICATED)))
            return self.json({"error": "Authentication required. Log in, or send a Home Assistant token."}, status_code=HTTPStatus.UNAUTHORIZED)
        if self.need == "admin" and not principal.is_admin:
            return self.json({"error": "Only an administrator can do that."}, status_code=HTTPStatus.FORBIDDEN)
        request[PRINCIPAL_KEY] = principal
        return await fn(self, request, *args, **kwargs)

    wrapper._cai_guarded = True  # noqa: SLF001
    return wrapper


class AuthedView(HomeAssistantView):
    """Base class: every get/post/put/patch/delete handler defined on a subclass is wrapped with authentication."""

    requires_auth = False  # we authenticate ourselves so both kinds of caller are accepted
    cors_allowed = False
    need = "user"          # "user": any signed-in caller, "admin": Home Assistant admin or AI admin

    def __init__(self, hass: HomeAssistant, rt: Runtime) -> None:
        self.hass = hass
        self.rt = rt

    def __init_subclass__(cls, **kwargs) -> None:
        super().__init_subclass__(**kwargs)
        for method in ("get", "post", "put", "patch", "delete"):
            fn = cls.__dict__.get(method)
            if fn is not None and not getattr(fn, "_cai_guarded", False):
                setattr(cls, method, _guard(fn))

    def run(self, fn, *args):
        return self.hass.async_add_executor_job(fn, *args)

    @staticmethod
    def who(request) -> Principal:
        return request[PRINCIPAL_KEY]
