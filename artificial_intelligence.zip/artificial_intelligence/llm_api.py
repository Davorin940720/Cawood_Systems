"""Cawood AI Tools: every tool of this integration as a Home Assistant LLM API.

Once registered, "Cawood AI Tools" appears under "Control Home Assistant" on any conversation agent (Ollama, OpenAI, Google...),
so Assist (typed or spoken) can use the same tools the web pages use: cameras, Home Assistant, files, terminal, projects, email.

The tool list, descriptions and guide come from tools.py, the single registry the pages use too. Each tool runs by calling this
integration's own HTTP endpoints from inside Home Assistant, exactly as cai-tools.js does from the browser, so behaviour is identical.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

import aiohttp
import voluptuous as vol

from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers import llm
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.network import NoURLAvailableError, get_url

from .const import API, LLM_API_ID, ORIGIN_HEADER, RELAY_HEADER
from .runtime import Runtime
from .tools import _all_tools, build_context, build_guide

_LOGGER = logging.getLogger(__name__)
MAX_TEXT = 12000
VOICE_NOTE = (
    "\n\nHOW TO REPLY\nYour answer may be read aloud by a voice assistant, so keep it short and plain: no markdown, tables, "
    "code blocks or long lists unless the user asks for detail. Say what you did and what you found."
)


class _Raw:
    """A parameter whose JSON schema is passed to the model exactly as the registry defines it."""

    def __init__(self, schema: dict) -> None:
        self.schema = schema

    def __call__(self, value: Any) -> Any:  # voluptuous needs a callable; Home Assistant never validates tool arguments here
        return value


def _serializer(value: Any) -> Any:
    if isinstance(value, _Raw):
        return value.schema
    return llm.selector_serializer(value)


def _schema(parameters: dict) -> vol.Schema:
    props = parameters.get("properties") or {}
    required = set(parameters.get("required") or [])
    out: dict = {}
    for key, spec in props.items():
        desc = spec.get("description")
        raw = {k: v for k, v in spec.items() if k != "description"}
        marker = vol.Required(key, description=desc) if key in required else vol.Optional(key, description=desc)
        out[marker] = _Raw(raw or {"type": "string"})
    return vol.Schema(out)


def _origin(hass: HomeAssistant) -> str:
    try:
        return get_url(hass, prefer_external=True)
    except NoURLAvailableError:
        return ""


def _loopback(hass: HomeAssistant) -> str:
    api = hass.config.api
    if api is None:
        raise HomeAssistantError("The Home Assistant web server is not running yet.")
    return f"{'https' if api.use_ssl else 'http'}://127.0.0.1:{api.port}"


def build_request(route: dict, args: dict, origin: str) -> tuple[str, str, dict]:
    """Turn a registry route plus the model's arguments into (method, path, query-or-body). Mirrors CAI._build in cai-tools.js."""
    left: dict = dict(route.get("fixed") or {})
    for key, val in args.items():
        if val is not None and val != "":
            left[key] = val
    for key, val in (route.get("inject") or {}).items():
        left[key] = origin if val == "$origin" else val

    def sub(match: re.Match) -> str:
        val = left.pop(match.group(1), "")
        return quote("" if val is None else str(val), safe="")

    path = re.sub(r"\{(\w+)\}", sub, route["path"])
    method = route.get("method", "GET")
    if method == "GET":
        query = {}
        for key, val in left.items():
            if isinstance(val, list):
                query[key] = ",".join(str(v) for v in val)
            elif isinstance(val, dict):
                query[key] = json.dumps(val)
            elif isinstance(val, bool):
                query[key] = "true" if val else "false"
            else:
                query[key] = str(val)
        return "GET", path, query
    return method, path, left


async def _send(hass: HomeAssistant, rt: Runtime, method: str, path: str, params: dict, timeout: float, origin: str = "voice") -> tuple[int, Any]:
    """Call this integration's own endpoint from inside Home Assistant, authenticated with the per-run relay secret."""
    session = async_get_clientsession(hass)
    kwargs: dict = {"headers": {RELAY_HEADER: rt.relay_secret, ORIGIN_HEADER: origin}, "timeout": aiohttp.ClientTimeout(total=timeout), "ssl": False}
    if method == "GET":
        kwargs["params"] = params
    else:
        kwargs["json"] = params
    async with session.request(method, _loopback(hass) + path, **kwargs) as resp:
        text = await resp.text()
        try:
            data = json.loads(text) if text else {}
        except ValueError:
            data = {"error": text[:300]}
        return resp.status, data


def _clip(text: str, limit: int = MAX_TEXT) -> str:
    return text if len(text) <= limit else text[:limit] + "... (truncated)"


def format_result(name: str, tool: dict, data: dict) -> str:
    """Mirror CAI._format in cai-tools.js."""
    if tool["x-cai"].get("returns_image"):
        return f"Snapshot of {data.get('camera')} (channel {data.get('channel')}) was captured, but a voice assistant cannot look at pictures. Use camera_analyze to have the camera AI describe the scene."
    if name == "fs_read" and data.get("content") is not None:
        off, content = data.get("offset") or 0, data["content"]
        more = f", more: pass offset {off + len(content)}" if data.get("truncated") else ""
        return f"{data.get('path')} (characters {off}-{off + len(content)} of {data.get('total_chars')}{more})\n{content}"
    if name == "fs_list" and isinstance(data.get("entries"), list):
        lines = [("[dir] " if e.get("type") == "dir" else "") + str(e.get("name")) + (f" ({e['size']} bytes)" if e.get("size") is not None else "") for e in data["entries"]]
        return f"{data.get('path') or '(all locations)'}:\n" + "\n".join(lines)
    if name == "python_run":
        return f"Exit code: {data.get('exit_code')}{'' if data.get('ok') else ' (failed)'}\n{data.get('output') or '(no output)'}"
    if name == "python_hass":
        text = "OK" if data.get("ok") else "FAILED"
        if data.get("output"):
            text += "\nOutput:\n" + str(data["output"])
        if data.get("error"):
            text += "\nError:\n" + str(data["error"])
        if data.get("result") is not None:
            text += "\nResult: " + json.dumps(data["result"], default=str)[:8000]
        return text
    if name == "describe_capabilities":
        return str(data.get("text", ""))
    return _clip(json.dumps(data, default=str))


class CaiTool(llm.Tool):
    """One registry tool, executed through this integration's endpoints."""

    def __init__(self, rt: Runtime, spec: dict) -> None:
        fn = spec["function"]
        self.rt = rt
        self.spec = spec
        self.name = fn["name"]
        self.description = fn["description"]
        self.parameters = _schema(fn["parameters"])

    async def async_call(self, hass: HomeAssistant, tool_input: llm.ToolInput, llm_context: llm.LLMContext) -> dict:
        return await run_tool(hass, self.rt, self.spec, dict(tool_input.tool_args or {}), origin="voice")


async def run_tool(hass: HomeAssistant, rt: Runtime, spec: dict, args: dict, origin: str = "voice") -> dict:
    """Run one registry tool through this integration's endpoints. Used by the voice assistants and the MCP server."""
    name = spec["function"]["name"]
    required = spec["function"]["parameters"].get("required") or []
    missing = [k for k in required if args.get(k) in (None, "")]
    if missing:
        return {"error": f"{name} needs: {', '.join(missing)}. Parameters: {', '.join(spec['function']['parameters'].get('properties', {}))}."}
    route = spec.get("x-cai") or {}
    try:
        if route.get("special") == "run_command":
            return {"result": await _run_command(hass, rt, args, origin)}
        if route.get("special") == "browser":
            return {"result": await _browser(hass, rt, args, origin)}
        method, path, params = build_request(route, args, _origin(hass))
        status, data = await _send(hass, rt, method, path, params, 660, origin)
    except (aiohttp.ClientError, TimeoutError, HomeAssistantError) as err:
        _LOGGER.warning("Tool %s failed: %s", name, err)
        return {"error": f"{name} failed: {err}"}
    if status >= 400:
        return {"error": (data.get("error") or data.get("message") or f"HTTP {status}") if isinstance(data, dict) else f"HTTP {status}"}
    return {"result": format_result(name, spec, data if isinstance(data, dict) else {"data": data})}


async def _run_command(hass: HomeAssistant, rt: Runtime, a: dict, origin: str) -> str:
    machine = str(a.get("machine") or "ha").strip()
    body = {"command": a.get("command"), "cwd": a.get("cwd"), "timeout": a.get("timeout") or 120}
    is_ha = not machine or re.fullmatch(r"(ha|home ?assistant)", machine, re.I) is not None
    if is_ha:
        status, data = await _send(hass, rt, "POST", API + "/term", {"action": "run", **body}, 660, origin)
    else:
        status, data = await _send(hass, rt, "POST", f"{API}/agents/{quote(machine, safe='')}/term", body, 660, origin)
    if status >= 400:
        raise HomeAssistantError(str(data.get("error") or f"HTTP {status}"))
    return f"Machine: {'Home Assistant' if is_ha else machine}\nExit code: {data.get('code')}\n{(data.get('output') or '(no output)')[-8000:]}"


async def _browser(hass: HomeAssistant, rt: Runtime, a: dict, origin: str) -> str:
    machine = str(a.get("machine") or "").strip()
    if not machine or re.fullmatch(r"(ha|home ?assistant)", machine, re.I):
        raise HomeAssistantError("The browser needs an agent machine. Call list_machines and pass machine.")
    body = {k: v for k, v in a.items() if k != "machine"}
    status, data = await _send(hass, rt, "POST", f"{API}/agents/{quote(machine, safe='')}/browser", body, 660, origin)
    if status >= 400:
        raise HomeAssistantError(str(data.get("error") or f"HTTP {status}"))
    if data.get("image"):
        return f"Screenshot captured on {machine}, but a voice assistant cannot look at pictures."
    if data.get("result") is not None:
        return str(data["result"])[:MAX_TEXT]
    return f"Page: {data.get('title') or ''} ({data.get('url') or ''})\n{(data.get('text') or '')[:8000]}"


@dataclass(slots=True, kw_only=True)
class CaiAPI(llm.API):
    """The "Cawood AI Tools" LLM API."""

    rt: Runtime

    async def async_get_api_instance(self, llm_context: llm.LLMContext) -> llm.APIInstance:
        ctx = await build_context(self.rt)
        specs = _all_tools(ctx)
        return llm.APIInstance(
            api=self,
            api_prompt=build_guide(specs, ctx) + VOICE_NOTE,
            llm_context=llm_context,
            tools=[CaiTool(self.rt, spec) for spec in specs],
            custom_serializer=_serializer,
        )


def setup_llm_api(hass: HomeAssistant, rt: Runtime) -> None:
    try:
        llm.async_register_api(hass, CaiAPI(hass=hass, id=LLM_API_ID, name="Cawood AI Tools", rt=rt))
    except HomeAssistantError as err:  # already registered, for example after a reload
        _LOGGER.debug("LLM API not registered: %s", err)
    else:
        _LOGGER.info("Registered the 'Cawood AI Tools' LLM API for conversation agents")
