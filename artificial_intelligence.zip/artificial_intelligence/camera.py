"""Camera entities, one per recorder channel."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.camera import Camera, CameraEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.dispatcher import async_dispatcher_connect
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .hikvision.hub import CaiHikvisionHub
from .hikvision.isapi import Channel, IsapiError

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback) -> None:
    hub: CaiHikvisionHub = entry.runtime_data
    async_add_entities(HikChannelCamera(hub, ch) for ch in hub.channels.values())


class HikChannelCamera(Camera):
    _attr_has_entity_name = True
    _attr_name = None
    _attr_brand = "Hikvision"
    _attr_supported_features = CameraEntityFeature.STREAM

    def __init__(self, hub: CaiHikvisionHub, ch: Channel) -> None:
        super().__init__()
        self._hub = hub
        self._ch = ch
        self._attr_unique_id = f"{hub.uid}_ch{ch.id}_camera"
        self._attr_device_info = hub.channel_device_info(ch)
        self._attr_model = hub.device.model if hub.device else None

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(
            async_dispatcher_connect(self.hass, self._hub.signal_analysis, self._on_analysis)
        )

    @callback
    def _on_analysis(self, channel: int) -> None:
        if channel == self._ch.id:
            self.async_write_ha_state()

    async def async_camera_image(self, width: int | None = None, height: int | None = None) -> bytes | None:
        try:
            return await self._hub.isapi.snapshot(self._ch.stream_id)
        except IsapiError as err:
            _LOGGER.debug("%s snapshot failed: %s", self._ch.name, err)
            return None

    async def stream_source(self) -> str | None:
        return self._hub.isapi.rtsp_url(self._ch.stream_id, self._hub.rtsp_port)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        attrs: dict[str, Any] = {"channel": self._ch.id, "dvr": self._hub.name}
        if last := self._hub.last_analysis.get(self._ch.id):
            attrs.update(
                cai_hikvision_summary=last.get("summary"),
                cai_hikvision_threat_level=last.get("threat_level"),
                cai_hikvision_time=last.get("time"),
                cai_hikvision_recognised=[o["identity"] for o in last.get("objects", []) if o.get("identity")],
            )
        return attrs
